# HC Engineering Constitution v2.0

1. Correctness y business behaviour preceden a implementación y conveniencia.
2. No hay feature sin comportamiento verificable; los tests protegen el requerimiento.
3. El ciclo base es RED → GREEN → REFACTOR. Nunca se elimina o debilita un test válido para pasar.
4. Proyectos productivos usan Hexagonal Architecture y vertical slicing. Las dependencias apuntan
   hacia dentro; frameworks e infraestructura son detalles reemplazables.
5. SOLID es obligatorio, con SRP como criterio principal: alta cohesión, bajo acoplamiento y una
   razón clara de cambio.
6. Simple before clever. No tecnología sin razón, patrón sin beneficio, ni abstracción sin una
   responsabilidad o boundary real.
7. Todo fichero de código fuente authored por HC tiene como máximo 99 líneas físicas. La división
   debe crear unidades semánticas, nunca fragmentos artificiales.
8. Seguridad, privacidad y least privilege forman parte del diseño, no una revisión tardía.
9. Architecture rules deben ser ejecutables cuando sea posible. `hc gates` prueba una base;
   únicamente `hc verify` puede aportar evidencia de DONE. AI genera; engineering valida.
10. Nunca se corrige una violación arquitectónica o de calidad debilitando la regla que la detectó.
    Refactor the implementation, not the standard.
11. Cambios relevantes de arquitectura requieren autoridad humana y ADR explícito.
12. Documentación tiene una fuente de verdad. Se carga el mínimo contexto suficiente.
13. Cuanto menor sea la capacidad del agente, menor debe ser su espacio de decisión.
14. Todos los modelos obedecen los mismos lineamientos, gates y autoridad. Capacidad y costo sólo
    cambian el tamaño del slice, el contexto y cuándo se escala una decisión.
