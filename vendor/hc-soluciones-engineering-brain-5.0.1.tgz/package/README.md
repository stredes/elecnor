# HC Engineering Brain v5.0

Sistema operativo de ingeniería versionado de HC Development. Define reglas, skills, workflows,
profiles y gates consumibles por personas o agentes sin acoplarse a un proveedor de IA.

## Inicio rápido

Requiere Node.js 22–24. Se distribuye fijado como `@hc-soluciones/engineering-brain@5.0.1` y usa
Ajv para hacer ejecutables los schemas JSON 2020-12.

```bash
npm test
npm run gates
npm run verify
node bin/hc.mjs brain info
node bin/hc.mjs context
node bin/hc.mjs story validate templates/user-story/NP-0000.json
```

Para iniciar sólo la convención HC dentro de un proyecto existente:

```bash
node /ruta/al/brain/bin/hc.mjs init backend-nest my-api --target /ruta/al/proyecto
```

`init` no instala frameworks ni sobrescribe archivos. `gates` valida la base portable, el scope y la
ruta Git; `verify` añade pin/lock inequívocos, trazabilidad, evidencia TDD continua por test, reviews
atestiguadas mediante commits firmados y comandos
del profile antes de DONE. V5 además exige OpenAPI y migrations en Nest, límites ejecutables para
dashboard/app/desktop/VR y evidencia específica por runtime. Un verde demuestra contratos ejecutables,
no criterio humano universal.

`hc context` devuelve paths únicos y un presupuesto aproximado de bytes/tokens. Big Pickle, GPT
básicos y modelos frontera siguen las mismas reglas; se escala el tamaño/ambigüedad del trabajo, no el
estándar. Los perfiles son backend Nest, dashboard Next, app Expo, desktop Electron, VR Unity y Brain.

## Mapa

- `ENGINEERING_CONSTITUTION.md`: principios universales, siempre cargados.
- `standards/`: fuentes canónicas de reglas y criterios.
- `skills/`: instrucciones especializadas y pequeñas.
- `workflows/`: estados y evidencias de entrega.
- `profiles/`: arquitectura y gates por stack.
- `templates/`: artefactos listos para copiar o inicializar.
- `.hc/schemas/`: contratos machine-readable.
- `router/`: selección de contexto.
- `src/` y `bin/`: CLI y enforcement ejecutable; Ajv es la única dependencia runtime controlada.

Consulta `docs/adoption.md` para adopción y `docs/canonical-sources.md` para evitar contexto duplicado.
