# Self-validation v5.0

Ejecutada el 2026-08-29.

| Check | Evidence |
| --- | --- |
| Constitution/AGENTS pequeños | 23 y 16 líneas; una regla común para todos los modelos |
| Schemas ejecutables | JSON Schema 2020-12/Ajv estricto; Electron y comandos VR/package tipados |
| Skills enfocadas | 17 skills; validación estructural e integridad PASS |
| Profiles completos | backend, web, mobile, desktop, VR y Brain con descriptor/docs/gates |
| TDD observable | 7 ciclos NP-0004 RED/GREEN/REFACTOR; snapshot final de fuente y suite |
| Scope/authority | rama NP-0004 y diff sensible limitado por task/authority |
| 99 líneas | hard gate sin waivers; máximo authored observado: 89 líneas |
| Backend Nest | OpenAPI, DTOs, migrations, synchronize false, bootstrap e2e y controller thin |
| Dashboard/App | límites server-client/BFF/Query/UI, Router/features/native ports/storage seguro |
| Desktop | herencia web, main/preload/renderer, sandbox, IPC y packaging separados |
| VR | Core/Domain/Application sin engine; build/Edit/Play/device/performance separados |
| Model policy | Big Pickle, GPT básicos y frontera comparten gates; sólo cambia slice/autoridad |
| Token economy | 20 paths únicos, 27.844 bytes, estimación provider-independent de 6.961 tokens |
| Dogfooding | 41 archivos y 69 casos declarados; suite completa y `hc verify` verdes |
| Distribución | dry-run: 169 archivos, ≈78 kB comprimidos / ≈243 kB unpacked; audit limpio |

El contexto activo de la tarea más amplia de esta release representa 11,5% del package unpacked y
queda bajo el contrato de 8.000 tokens estimados. La reproducción final mantiene completamente verde
`hc-back-test` con Brain v4 y sus comandos PostgreSQL, mientras los gates v5 detectan 10 brechas hard
de OpenAPI, migrations, bootstrap y controller. `hc_dashboard` no presenta hallazgos runtime web; v5
hace visible deuda deliberadamente más estricta en backend/app sin modificar consumidores. Los límites
restantes están en `docs/roadmap.md`; el paquete se crea localmente y no se publica.
