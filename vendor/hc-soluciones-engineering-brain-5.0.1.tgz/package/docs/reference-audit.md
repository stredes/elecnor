# Auditoría de referencias — Phase 0

## Conservado

- `main` estable, `Development` como integración y una rama `NP-XXXX` compartida entre repos.
- Commit como unidad lógica verificable y categorías visibles.
- Vertical slicing por dominio con `domain`, `application` e `infrastructure`.
- Casos de uso, policies, DTO/adapters, tests unitarios, e2e y tests arquitectónicos en CI.

## Refinado

- Los ports de dependencias externas se unifican en `application/ports`; el dominio expone modelos
  y comportamiento, no repositorios tecnológicos.
- Los tests por regex del backend pasan a contratos configurables por profile y análisis de imports.
- El límite previo permitía 100 líneas, baselines y excepciones authored. v1 aplica 99 como hard gate
  sin waivers para código HC; sólo clasifica generated/vendor/data fuera de scope.
- Coverage global rígido se reemplaza por cobertura de comportamiento y mayor exigencia según riesgo.
- Se formalizan Release PR, SemVer cuando aplica, hotfix con regression test y sincronización.
- `shared/common` deja de ser destino por conveniencia y exige una abstracción transversal estable.

## Riesgos observados

- La proliferación de carpetas y pequeños archivos puede volverse fragmentación si no hay semántica.
- Regex aisladas pueden omitir imports dinámicos o aliases; cada proyecto TS debe complementar el gate
  portable con ESLint/dependency-cruiser según el profile.
- Los adapters y pruebas de infraestructura deben graduarse por riesgo, no perseguir 100% ciego.
