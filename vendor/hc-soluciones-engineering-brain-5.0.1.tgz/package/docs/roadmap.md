# Límites v5 y siguientes

## Límites conocidos v5

- Los gates arquitectónicos son léxicos y conservadores; compiler, tests y review siguen siendo señales
  distintas. No prueban atomicidad DB, autorización efectiva, confort VR ni seguridad total.
- OpenAPI reconoce decorators Nest convencionales y decorators compuestos terminados en Docs o
  Documentation; metaprogramación propia necesita una futura extensión declarativa.
- Los detectores Query/Zustand/SecureStore observan patrones de alto valor, no el flujo completo de datos.
- Electron valida BrowserWindow, preload, IPC y navegación en fuente; firma, fuses, CSP final y updater
  requieren checks del artefacto instalado declarados por el consumidor.
- Unity exige comandos build/EditMode/PlayMode/device/performance, pero sus runners y attestation viven
  en cada proyecto. El gate no puede automatizar ergonomía o confort humano.
- Reviews aceptadas se atan a commits Git firmados; otras plataformas de attestation quedan pendientes.
- TDD captura continuidad individual por TEST; trabajo legacy sólo admite migración/review explícita.
- El gate Git valida refs locales o `origin`, no estado del PR ni protecciones del servidor.
- `hc init` crea manifest/layout, no instala frameworks ni genera una aplicación productiva completa.
- Los repositorios de referencia no se migraron; v5 hará visible deuda previamente tolerada.

## Siguientes incrementos

1. Añadir extensiones AST/configurables para decorators, adapters y aliases propios por repositorio.
2. Firmar evidencia de dispositivo/build VR y desktop mediante un manifest reproducible.
3. Integrar identidad del aprobador con GitHub Checks/CODEOWNERS además de Git firmado.
4. Añadir release manifest multi-repo y compatibilidad OpenAPI automatizada entre backend/clientes.
