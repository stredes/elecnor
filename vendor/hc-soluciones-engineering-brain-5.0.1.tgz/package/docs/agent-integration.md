# Integración con agentes

## OpenCode

OpenCode lee `AGENTS.md`. Conserva allí sólo el bootstrap y referencia el Brain fijado. Expón las
skills por symlink en `.agents/skills/` o mediante un source configurado si la versión instalada lo
soporta; el directorio canónico sigue siendo `skills/`. Ejecuta `hc context` al inicio de cada tarea:
ese comando valida project, task y story antes de enrutar. Carga una sola vez los paths resultantes,
no todos los standards. El router incluye la `story_path` activa y la memoria si existe; omitir
cualquiera de esos archivos no es una optimización válida.

## Otros agentes

Todo agente capaz de leer archivos puede seguir `AGENTS.md`, manifests JSON y workflows. Si reconoce
Agent Skills, registra cada carpeta con `SKILL.md`; si no, usa la salida del router como lista de
contexto. No depende de prompts propietarios, nombres de modelos ni herramientas de OpenCode.

La plataforma puede mapear sus modelos a tiers `high-reasoning`, `implementation` o `mechanical`,
pero el Brain limita autoridad y scope mediante el diff, no sólo mediante instrucciones; nunca
selecciona proveedor. Big Pickle, GPT básicos y modelos frontera reciben exactamente los mismos
lineamientos y gates; sólo varían el slice, contexto y decisiones abiertas.

El bootstrap exige una transición breve `estado → herramienta → resultado`, readback después de
escrituras y continuidad sin prompts humanos cuando el trabajo ya está autorizado. Estas reglas
reducen bucles, pero el Brain no puede reanudar por sí solo un turno terminado por el proveedor. Un
watchdog pertenece al adapter del orquestador y debe medirse por separado del benchmark del modelo.
El protocolo reproducible y sus eventos mínimos están en `docs/benchmarking.md`.

El bootstrap también expone desde el inicio `[TYPE]: Imperative, scoped message`. La evidencia marca
el HEAD preexistente como `UNMANAGED_INITIAL`; tras cada REFACTOR, el próximo RED exige producción
confirmada y un commit gestionado con formato HC.
