# Adopción en proyectos

1. Fija `@hc-soluciones/engineering-brain@5.0.1` o un tarball local `.tgz` y conserva un solo lockfile.
2. Ejecuta `hc init <profile> <name> --target <repo>` o `hc migrate --to 2` para un proyecto v1.
3. Completa `.hc/project.json`, el bootstrap `AGENTS.md` y la memoria breve.
4. Crea cada HU en `.hc/stories/NP-XXXX.json` y valida antes de Development.
5. Crea `.hc/task.json` al empezar trabajo; bórralo al cerrar o cambiar de tarea.
6. Usa la rama `NP-XXXX` desde `Development`, commits HC y argv no mutantes; ejecuta `hc verify` en CI.
7. Añade tests arquitectónicos nativos indicados por el profile.

V1 no se interpreta silenciosamente: dry-run, proposal y apply limpio evitan inventar riesgos o AC.
No mezcles `package-lock.json`, `pnpm-lock.yaml`, `yarn.lock` o shrinkwrap. El specifier del lock debe
coincidir con `package.json`. Sólo un `file:...tgz` cuyo SHA-512 coincida con `integrity` puede sustituir
temporalmente el pin de registry; directorios `file:`/`link:` siguen rechazados.
Un proyecto sólo sube su pin tras leer release notes y resolver cambios incompatibles.

Al migrar de v4 a v5, backend debe resolver OpenAPI, migrations y bootstrap e2e; web/mobile/desktop
declaran lint, typecheck, unit, audit, build y e2e según el área; VR declara build/EditMode y añade
PlayMode/device/performance cuando toca adapters o presentation. Es deuda visible, no configuración
opcional para conservar un verde anterior.

Una review `accepted` usa el email del firmante y un commit alcanzable desde HEAD, firmado con
`git commit -S`, que incluya `HC-Task: NP-XXXX` y `HC-Review: <fingerprint>` en su mensaje.
