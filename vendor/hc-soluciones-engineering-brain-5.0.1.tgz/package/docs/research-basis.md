# Base técnica consultada

Verificada el 2026-08-29. Estas fuentes sustentan decisiones de adapters; no sustituyen los estándares
HC versionados.

- [ESLint no-restricted-imports](https://eslint.org/docs/latest/rules/no-restricted-imports): útil para
  prohibiciones directas; no cubre imports dinámicos por sí solo.
- [dependency-cruiser rules](https://github.com/sverweij/dependency-cruiser/blob/main/doc/rules-reference.md):
  ciclos y dependencias transitivas en TypeScript.
- [NestJS controllers](https://docs.nestjs.com/controllers): controller como boundary HTTP.
- [NestJS OpenAPI](https://docs.nestjs.com/openapi/introduction): dependency, document generation y
  bootstrap de Swagger desde la aplicación real.
- [TypeORM migrations](https://typeorm.io/docs/migrations/setup/): `synchronize: false` y carga
  explícita de migrations.
- [Next Server/Client Components](https://nextjs.org/docs/app/getting-started/server-and-client-components):
  separación de runtimes y prevención de environment poisoning.
- [Next mutations](https://nextjs.org/docs/app/getting-started/mutating-data): Server Functions son
  endpoints alcanzables y deben autorizar cada mutación.
- [Expo SecureStore](https://docs.expo.dev/versions/latest/sdk/securestore/): almacenamiento cifrado,
  limitaciones de plataforma y persistencia.
- [Electron security](https://www.electronjs.org/docs/latest/tutorial/security) y
  [context isolation](https://www.electronjs.org/docs/latest/tutorial/context-isolation): sandbox,
  navegación acotada, Node deshabilitado y bridge por mensaje en vez de IPC crudo.
- [Unity assembly definitions](https://docs.unity.cn/Manual/ScriptCompilationAssemblyDefinitionFiles.html)
  y [Edit/Play Mode](https://docs.unity.cn/Packages/com.unity.test-framework%402.0/manual/edit-mode-vs-play-mode-tests.html):
  assemblies explícitos, `No Engine References` y señales de prueba separadas.
- [Unity XR Interaction Toolkit](https://docs.unity3d.com/ja/6000.0/Manual/com.unity.xr.interaction.toolkit.html)
  y [Meta Quest performance](https://developers.meta.com/horizon/documentation/unity/unity-perf/):
  adapters XR y profiling sobre dispositivo.
- [OpenCode rules](https://opencode.ai/docs/rules) y
  [Agent Skills](https://opencode.ai/docs/skills): `AGENTS.md` y carga on-demand de `SKILL.md`.
