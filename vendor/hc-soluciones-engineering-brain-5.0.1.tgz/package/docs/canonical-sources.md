# Fuentes canónicas

| Tema | Fuente |
| --- | --- |
| Principios universales | `ENGINEERING_CONSTITUTION.md` |
| Arquitectura base y ports | `standards/architecture/` |
| HU, DoR y trazabilidad | `standards/requirements/` |
| TDD y cobertura | `standards/testing/testing-strategy.md` |
| Métricas y DoD | `standards/quality/` |
| Seguridad | `standards/security/security-standard.md` |
| Git, commits y releases | `standards/git/` |
| Autoridad y contexto IA | `standards/ai/` |
| Secuencias de trabajo | `workflows/` |
| Reglas específicas del stack | `profiles/<profile>/` |
| Procedimiento del agente | `skills/<skill>/SKILL.md` |
| Contratos de datos | `.hc/schemas/` |

`README.md` orienta; `AGENTS.md` enruta; profiles especializan; skills enseñan ejecución. Ninguno
debe duplicar el contenido normativo de las fuentes anteriores.
