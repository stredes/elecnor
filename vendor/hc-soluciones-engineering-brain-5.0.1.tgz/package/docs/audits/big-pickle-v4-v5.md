# Auditoría Big Pickle — `hc-back-test` frente a Brain v4/v5

Fecha: 2026-08-29. Alcance: HU NP-0001 “Registrar usuario”. El consumidor y los repositorios de
referencia se inspeccionaron en lectura; no se modificaron.

## Resultado ejecutivo

La HU es funcional y bastante buena como implementación guiada por Big Pickle, pero no está lista como
baseline productiva HC. La valoración global es **6,2/10**. El comportamiento principal alcanza **8,0/10**;
la preparación arquitectónica/operacional baja la nota por ausencia total de Swagger/OpenAPI,
migrations y paridad bootstrap-e2e. Brain v4 dio un falso verde porque verificaba evidencia de riesgo,
pero aún no hacía ejecutables esos contratos.

Ponderación explícita: TDD, diseño interno y datos pesan 20% cada uno; HTTP, operación 15% cada uno;
OpenAPI 10%. El resultado 6,15 se redondea a una decimal.

| Dimensión | Peso | Nota | Evidencia |
| --- | ---: | ---: | --- |
| Trazabilidad y TDD | 20% | 8,5 | 12 tests trazados, ciclos completos y 5 reviews |
| Dominio/application | 20% | 8,0 | ports y use case puros; hashing fuera del dominio |
| Persistencia/concurrencia | 20% | 7,5 | PostgreSQL y constraint real; sin migrations |
| Contrato HTTP | 15% | 5,0 | DTO/pipe productivo; controller ramifica y responde `unknown` |
| Swagger/OpenAPI | 10% | 0,0 | sin dependencia, bootstrap, decorators ni response schema |
| Operación/configuración | 15% | 4,0 | `synchronize` variable, bootstrap e2e divergente, README starter |

## Lo que Big Pickle resolvió bien

- Slice vertical `auth` con Domain, Application ports e Infrastructure.
- Email normalizado, contraseña hasheada con scrypt asíncrono y credencial fuera de la respuesta.
- Constraint único TypeORM y carrera real con `Promise.all`; una operación gana y una falla.
- Tests unitarios, integración PostgreSQL y e2e que cubren éxito, duplicado, input y error interno.
- Los comandos lint/format/typecheck/unit/integration/e2e/audit/build terminaron verdes bajo v4.

## Brechas confirmadas por v5

La evaluación estática v5 sobre la misma fuente produce diez fallos hard:

1. No existe configuración Swagger/OpenAPI invocada desde `main`.
2. El controller carece de `@ApiTags` y `@ApiOperation`.
3. No hay respuesta exitosa OpenAPI tipada ni DTO público explícito.
4. `RegisterRequestDto` no publica metadata OpenAPI.
5. TypeORM no posee ningún artefacto de migration.
6. El runtime no carga migrations explícitamente.
7. `synchronize: NODE_ENV !== 'production'` permite mutar esquema fuera de migrations.
8. Las apps e2e no reutilizan el `ValidationPipe`/bootstrap productivo.
9. El controller contiene branching de errores de negocio.
10. El README sigue siendo el starter de Nest y no documenta contrato u operación del servicio.

Hay además dos contradicciones de requerimiento que un gate no debe decidir silenciosamente: AC-04
declara mínimo ocho caracteres, una letra y un número, pero TEST-08 exige además mayúscula, minúscula y
carácter especial; NFR-04 prohíbe nombre/email en respuesta pública mientras AC-01 ordena devolverlos.
Debe corregirse la HU mediante decisión humana antes de endurecer o relajar implementación.

## Lectura de la capacidad del modelo

Big Pickle fue certero cuando recibió comportamiento observable, ports y verificación determinista. Sus
omisiones aparecen en decisiones transversales que la HU no convirtió en gates: contrato OpenAPI,
evolución de esquema, bootstrap común y controller thin. La respuesta correcta no es enviar todo el repo
a un modelo frontera: v5 codifica esas decisiones una vez y entrega al modelo económico sólo HU, profile,
paths y comando. Un modelo frontera se reserva para resolver contradicciones o trade-offs nuevos.

## Uso de los repositorios de referencia

`hc_dashboard` pasa sin hallazgos los nuevos boundaries runtime web; su separación BFF/sesión/Query/UI
es la base canónica. De `hc-app` se conserva la forma Router + core + features, pero v5 endurece deuda
existente: imports directos de adapters desde presentation y APIs nativas en application ahora fallan.
De `hc-backend` se adoptan bootstrap compartido, Swagger tipado, migrations y composición; sus ports
legacy ubicados en domain siguen chocando con la política v4 de ports de salida en application. Los
repositorios de referencia no se modificaron ni se declararon perfectos por definición.

Conclusión: Big Pickle y GPT básicos son aptos como implementers acotados bajo v5. Todos los modelos
siguen exactamente los mismos lineamientos; sólo cambia el tamaño del slice y la autoridad de decisión.
