# Agent benchmark harness

Start one run per model, model version and selected TEST:

```sh
hc benchmark start BENCH-BP-FREE-001 --model big-pickle --model-version free-2026-09 --test TEST-01
```

The artifact under `.hc/benchmarks/` snapshots the Brain version, task, bounded context capsule,
context digest, estimated context tokens, start time and initial TDD journal sequence. An existing run
is immutable at start: the command never replaces it.

## Orchestrator adapter contract

The orchestrator adapter must emit one event per tool call. It emits an additional `EDIT_FAILED`
event when a write did not apply, and `HUMAN_INTERVENTION` whenever human input was required to resume
or choose a path. Send only the tool name or a short outcome plus input/output character counts:

```sh
hc benchmark event BENCH-BP-FREE-001 --type TOOL_CALL --detail apply_patch \
  --input-characters 420 --output-characters 80
```

The harness timestamps, sequences and hash-chains these events. It estimates tokens as `ceil(chars/4)`
and does not store full transcripts, prompts, tool payloads or secrets. The Brain cannot observe calls
that the adapter does not emit and never fabricates missing provider telemetry.

Finish with `COMPLETED`, `STALLED` or `FAILED`:

```sh
hc benchmark finish BENCH-BP-FREE-001 --result COMPLETED
hc benchmark report BENCH-BP-FREE-001
```

Finish derives cycle outcomes only from TDD events recorded after start and aggregates elapsed time,
estimated tokens, tool calls, failed edits and human interventions. Every CLI response is one compact
JSON object so adapters can persist exit status and output without parsing narration.
