# ADR-009 — Recuperación revisada de secuencias TDD legacy

- Status: Accepted
- Date: 2026-10-14
- Authority: explicit user authorization for NP-0009 to recover NP-0003 without rewriting evidence

## Context

NP-0003 has adjacent completed cycles whose original records show both a production digest change and
the next RED predating the previous REFACTOR. Brain v5 correctly rejects both. Changing either phase
or inventing a timestamp would falsify the audit trail.

## Decision

Evidence v2 may append a `sequence_recoveries` entry for one exact adjacent cycle pair. It binds hashes
of the original REFACTOR and RED, a canonical recovery fingerprint, an accepted review, and a later
recording timestamp. The signed review commit must be reachable and bound to the evidence task and
fingerprint. Validation suppresses only the two matching legacy sequence errors for that pair. The
original phases remain untouched; all other sequence, phase, snapshot, and signature checks still run.

## Consequences

Legacy v2 evidence without recoveries is unchanged. A recovery without a matching accepted signed
review is invalid. Consumers must review and commit the recovery record before `hc verify` can pass.
The feature remains local until its own review and release gates pass.
