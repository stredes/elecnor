# ADR-004 — Contexto multidimensional y evidencia observada

- Status: accepted
- Date: 2026-08-29
- Authority: explicit human approval of Brain v2 refactor

## Context

Una única `layer` no representaba vertical slices. Una feature de auth declarada application omitió
security aunque cambió HTTP, persistence, configuration y credentials. AC IDs tampoco enlazaban HU,
tests o un RED observado con contexto Git.

## Decision

Task v2 declara múltiples `change_areas`, `risk_tags`, story canónica y AC seleccionados. NFR conectan
riesgos a tests/reviews. El router une todas las dimensiones. `hc tdd` registra digests RED/GREEN y
`hc verify` cruza story, tags, evidence, metadata Git, review signals y comandos de profile.

## Consequences

La metadata aumenta, pero cada dato gobierna contexto o enforcement. Los findings demostrables son
hard; heurísticas quedan como review signals que sólo una justificación humana puede aceptar.
Trabajo legacy no recibe evidencia RED fabricada.
