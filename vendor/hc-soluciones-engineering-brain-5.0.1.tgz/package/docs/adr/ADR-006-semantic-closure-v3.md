# ADR-006 — Cierre semántico para Brain v3

- Status: accepted
- Date: 2026-08-29
- Authority: NP-0002 and explicit human approval to refine Brain to v3

## Context

La segunda generación de Big Pickle pasó Brain v2 pero aceptó input Nest inválido, permitió una
carrera de unicidad, omitió un riesgo NFR y presentó tests modificados después de su REFACTOR. La
evidencia también permitía escribir una identidad humana sin demostrar su intervención.

## Decision

Brain v3 cierra risks en ambas direcciones, infiere concurrency/persistence desde contratos de
unicidad, verifica el digest actual de cada TEST y exige e2e por AC HTTP. Backend Nest requiere DTOs
con validación runtime acotada, ValidationPipe estricto, TypeScript strict, lint sin warnings y crypto
asíncrono. Una aceptación se vincula a un commit firmado; un `.tgz` local sólo vale con lock e integrity.

El package pasa a `3.0.0`, mientras los documentos conservan `schema_version: 2.0` para evitar una
migración sin beneficio semántico. V2 queda preservada en el tag local `v2.0.0`.

## Consequences

Modelos de menor capacidad reciben menos falsos verdes y mensajes accionables. Los nuevos gates son
deliberadamente conservadores: pueden requerir adaptar DTOs, scripts y evidencia existentes antes de
migrar. No se publica ni se empuja v3 como parte de esta decisión.
