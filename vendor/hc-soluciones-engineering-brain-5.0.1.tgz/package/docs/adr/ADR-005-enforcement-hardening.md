# ADR-005 — Enforcement para agentes de menor capacidad

- Status: accepted
- Date: 2026-08-29
- Authority: NP-0001 and explicit human approval to harden Brain v2

## Context

Un backend generado con un modelo gratuito obtuvo `hc verify` verde aunque omitió contexto canónico,
alteró la continuidad TDD y dejó ambigüedades de scope, seguridad, lockfile y Git. Las reglas escritas
eran correctas, pero dependían demasiado del razonamiento y la disciplina del agente.

## Decision

Brain v2 convierte esos contratos demostrables en gates: story y bootstrap obligatorios, evidencia TDD
continua con snapshot final, scope/authority sobre el diff, controles backend de alta confianza, una
resolución de paquete inequívoca, reviews aceptadas para riesgos sensibles y workflow Git verificable.
Schemas, perfiles, reglas, skills y workflows cuentan como fuente del propio Brain.

## Consequences

Los agentes reciben menos decisiones abiertas y fallan antes con mensajes concretos. Las señales
heurísticas siguen siendo review, y la identidad real del aprobador todavía depende de la plataforma.
V1 queda preservada en el tag local `v1.0.0`; `2.0.0` es la línea endurecida y no se publica sin review.
