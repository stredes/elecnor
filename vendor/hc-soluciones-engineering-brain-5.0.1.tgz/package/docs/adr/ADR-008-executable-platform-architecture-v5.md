# ADR-008 — Arquitectura ejecutable multiplataforma en v5

- Status: Accepted
- Date: 2026-08-29
- Authority: NP-0004 y solicitud humana explícita

## Contexto

Brain v4 validó completamente una HU de Big Pickle que tenía persistencia/concurrencia real, pero no
Swagger/OpenAPI, migrations ni bootstrap e2e equivalente. Los repositorios `hc-backend`, `hc-app` y
`hc_dashboard` ya contienen límites maduros que eran narrativa local. Desktop y VR requieren además
boundaries de runtime que Hexagonal genérica no expresa por sí sola.

## Decisión

Brain 5.0.0 convierte esos límites en perfiles, gates y contratos de verificación:

- Nest: OpenAPI ejecutable, DTOs tipados, controllers thin, bootstrap compartido y migrations únicas.
- Dashboard: capas app/application/core/domain/infrastructure/presentation, BFF y sesión server-only;
  Query posee remote state y Zustand sólo UI.
- Expo: `app` como router, slices en `src/features`, capacidades nativas tras ports y storage seguro.
- Electron: hereda web-next; main/preload/renderer separados, bridge allowlisted y sandbox obligatorio.
- Unity: assemblies por capa, inner layers sin engine, platform ports y señales separadas de build,
  EditMode, PlayMode, dispositivo, performance y validación humana.

Todos los modelos obedecen la misma Constitución. El router mide contexto, elimina duplicados y carga
reglas heredadas una vez. Agentes económicos reciben slices cerrados; frontera resuelve únicamente
ambigüedad o riesgo que los gates no puedan decidir.

## Consecuencias

Es un cambio mayor: consumidores v4 no pasan v5 hasta declarar comandos y resolver deuda real. Los gates
léxicos son conservadores y complementan compiladores/tests nativos; no prueban semántica total. No se
agrega dependencia runtime. `schema_version` continúa en 2.0 y el package cambia a 5.0.0.

## Evidencia técnica VR

Unity documenta asmdef y `noEngineReferences`, además de la separación Edit/Play Mode. XR Interaction
Toolkit provee el framework de interacción; Meta exige perfilar en dispositivo y recomienda métricas
específicas de Quest. Fuentes: [asmdefs](https://docs.unity.cn/Manual/assembly-definition-file-format.html),
[tests](https://docs.unity.cn/Packages/com.unity.test-framework%402.0/manual/edit-mode-vs-play-mode-tests.html),
[XRIT](https://docs.unity3d.com/ja/6000.0/Manual/com.unity.xr.interaction.toolkit.html) y
[Quest performance](https://developers.meta.com/horizon/documentation/unity/unity-perf/).
