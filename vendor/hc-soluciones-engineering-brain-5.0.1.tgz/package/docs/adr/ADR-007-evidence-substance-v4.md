# ADR-007 — Evidencia sustantiva y contexto único en v4

- Status: accepted
- Date: 2026-08-29
- Authority: NP-0003 and explicit human approval to create Brain v4

## Context

`hc-back-test` pasó v3 con input, TDD y comandos correctos, pero aceptó dos altas simultáneas con el
mismo correo. La story omitió riesgos sensibles, el adapter `memory-user-repository` evitó un regex
`in-memory` y una prueba secuencial contó como integración sólo por su ruta.

## Decision

V4 infiere material de acceso e identidad desde el contrato, exige review para concurrencia, rechaza
persistencia productiva en memoria bajo ese riesgo y comprueba que integración backend use un adapter
real. Evidencia concurrente debe ejercer operaciones solapadas. `hc context` valida los tres manifests
antes de enrutar y el bootstrap deja de ordenar una lectura previa duplicada.

## Consequences

El consumer adversarial deja de ser verde. Proyectos backend con adapters propios deben usar un driver
reconocible y pruebas solapadas; el análisis sigue siendo conservador y no demuestra atomicidad
universal. `schema_version` permanece en 2.0 y el package cambia a 4.0.0.
