# ADR-001 — Brain modular y declarativo

- Status: accepted
- Date: 2026-08-29

## Context

El Brain debe servir a stacks y agentes distintos con poco contexto y reglas verificables.

## Decision

Separar Constitution, standards canónicos, skills, workflows, profiles, templates y gates. Un router
declarativo selecciona contexto; una CLI Node sin dependencias ejecuta validación común.

## Rationale

La separación distingue Rule/Skill/Gate, permite evolución independiente y evita mega-prompts.

## Consequences

Cada proyecto fija versión y añade tooling nativo de profile. Cambios coordinados al catálogo, router
y gates necesitan tests de integridad.
