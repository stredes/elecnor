# ADR-002 — Manifests JSON y runtime sin dependencias

- Status: superseded by ADR-003 for runtime validation; JSON manifests remain accepted
- Date: 2026-08-29

## Context

Project/task/HU requieren validación machine-readable. YAML necesitaría parser externo o un subset
frágil; JSON puede validarse de forma determinista con Node estándar.

## Decision

Usar `.hc/project.json`, `.hc/task.json` y HU JSON, acompañados de JSON Schema 2020-12. La CLI v1 aplica
validaciones semánticas críticas sin instalar packages.

## Rationale

Reduce bootstrap, supply-chain y divergencias de parser. Sigue siendo legible, portable y estructurado.

## Consequences

JSON no admite comentarios. v1.1 puede integrar un validator JSON Schema completo si se distribuye de
forma controlada; los schemas siguen siendo la interfaz canónica.
