# ADR-003 — Schemas ejecutables y paquete versionado

- Status: accepted
- Date: 2026-08-29
- Authority: explicit human approval of Brain v2 refactor

## Context

V1 publicaba JSON Schemas canónicos, pero la CLI duplicaba un subconjunto manual y `brain_version`
no demostraba qué ejecutable corría. Proyectos podían recibir gates verdes con contratos incompletos.

## Decision

Publicar `@hc-soluciones/engineering-brain@2.0.0` en GitHub Packages, fijado exactamente y con lockfile.
Ajv 8 ejecuta schemas 2020-12; validadores semánticos sólo mantienen relaciones entre documentos.
`hc doctor` compara manifest, paquete ejecutado, dependency y resolución del lockfile.

## Consequences

Se sustituye el runtime sin dependencias de ADR-002. La dependencia queda exacta, auditada y cubierta
por CI/package dry-run. V1 requiere migración explícita y nunca se interpreta parcialmente como v2.
