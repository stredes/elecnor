import { copyFileSync, existsSync, mkdirSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { readJson } from '../shared/fs.mjs';
import { validateSchema } from '../validation/schema.mjs';
import { validateProjectDocument } from '../validation/project.mjs';
import { validateDelivery } from '../validation/delivery.mjs';
import { checkVerificationConfig } from '../validation/verification-config.mjs';
import { brainVersion, packageName } from '../config/metadata.mjs';
import { runDeclaredCommand } from '../verification/command-runner.mjs';
import { ensureAgentBootstrap } from '../init/init-project.mjs';
import { convertProject, convertTask } from './v1-convert.mjs';

function proposalPaths(root) {
  const base = join(root, '.hc/migration-v2');
  return { base, project: join(base, 'project.json'), task: join(base, 'task.json') };
}

function writeJson(path, document) {
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, `${JSON.stringify(document, null, 2)}\n`);
}

function blockers(root, project, task) {
  const taskErrors = validateSchema('task', task);
  const errors = [...validateProjectDocument(project, root, { requireBootstrap: false }), ...taskErrors];
  if (!taskErrors.length) errors.push(...validateDelivery(root, task), ...checkVerificationConfig(root, project, task));
  const pkgPath = join(root, 'package.json');
  const declared = existsSync(pkgPath) ? readJson(pkgPath).devDependencies?.[packageName] : null;
  if (declared !== brainVersion) errors.push(`pin ${packageName} exactly to ${brainVersion}`);
  const typecheck = project.verification.commands.typecheck?.argv[2];
  const script = existsSync(pkgPath) ? readJson(pkgPath).scripts?.[typecheck] ?? '' : '';
  if (/tsconfig\.build/.test(script)) errors.push('typecheck command appears to exclude tests');
  return errors;
}

async function cleanGit(root) {
  const result = await runDeclaredCommand(root, { argv: ['git', '-C', root, 'status', '--porcelain'], timeout_seconds: 30 });
  return result.exitCode === 0 && result.output.trim() === '';
}

function applyProposals(root, paths) {
  const projectTarget = join(root, '.hc/project.json');
  const taskTarget = join(root, '.hc/task.json');
  const projectBackup = join(paths.base, 'project.v1.json');
  const taskBackup = join(paths.base, 'task.v1.json');
  copyFileSync(projectTarget, projectBackup);
  copyFileSync(taskTarget, taskBackup);
  copyFileSync(paths.project, `${projectTarget}.v2.tmp`);
  copyFileSync(paths.task, `${taskTarget}.v2.tmp`);
  try {
    renameSync(`${projectTarget}.v2.tmp`, projectTarget);
    renameSync(`${taskTarget}.v2.tmp`, taskTarget);
  } catch (error) {
    copyFileSync(projectBackup, projectTarget);
    copyFileSync(taskBackup, taskTarget);
    throw error;
  }
}

export async function migrateV2(root, mode = 'dry-run', isClean = cleanGit) {
  const currentProject = readJson(join(root, '.hc/project.json'));
  if (currentProject.schema_version !== '1.0') return { errors: ['migration requires a v1 project'], notes: [] };
  const currentTaskPath = join(root, '.hc/task.json');
  if (!existsSync(currentTaskPath)) return { errors: ['migration requires .hc/task.json'], notes: [] };
  let project = convertProject(root, currentProject);
  let task = convertTask(readJson(currentTaskPath));
  const paths = proposalPaths(root);
  if (mode === 'prepare') {
    writeJson(paths.project, project);
    writeJson(paths.task, task);
  }
  const errors = [];
  if (mode === 'apply') {
    if (!existsSync(paths.project) || !existsSync(paths.task)) errors.push('run migrate --prepare first');
    else {
      project = readJson(paths.project);
      task = readJson(paths.task);
    }
    if (!await isClean(root)) errors.push('migration apply requires a clean Git worktree');
    errors.push(...blockers(root, project, task));
    if (!errors.length) {
      applyProposals(root, paths);
      ensureAgentBootstrap(root);
    }
  } else {
    errors.push(...blockers(root, project, task));
  }
  return { errors, notes: [`mode=${mode}`, `proposal=${paths.base}`, 'risk_tags and story content require human completion'] };
}
