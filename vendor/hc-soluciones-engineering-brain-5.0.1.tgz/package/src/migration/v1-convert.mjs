import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { readJson } from '../shared/fs.mjs';
import { brainVersion } from '../config/metadata.mjs';

const scriptNames = {
  lint: ['lint:check', 'lint'], format_check: ['format:check'], typecheck: ['typecheck', 'type-check'],
  unit: ['test'], integration: ['test:integration'], e2e: ['test:e2e'], build: ['build'],
};
const timeouts = { lint: 120, format_check: 120, typecheck: 180, unit: 300, integration: 600, e2e: 600, dependency_audit: 300, build: 600 };

function detectedCommands(root) {
  const path = join(root, 'package.json');
  if (!existsSync(path)) return {};
  const scripts = readJson(path).scripts ?? {};
  const commands = {};
  for (const [slot, candidates] of Object.entries(scriptNames)) {
    const script = candidates.find((name) => scripts[name]);
    if (script && !(['lint', 'format_check'].includes(slot) && /--(?:fix|write)/.test(scripts[script]))) {
      const argv = ['npm', 'run', script];
      if (slot === 'lint' && /(?:^|\s)eslint(?:\s|$)/.test(scripts[script]) && !/--max-warnings(?:=|\s+)0/.test(scripts[script])) {
        argv.push('--', '--max-warnings=0');
      }
      commands[slot] = { argv, timeout_seconds: timeouts[slot] };
    }
  }
  commands.dependency_audit = { argv: ['npm', 'audit', '--audit-level=high'], timeout_seconds: timeouts.dependency_audit };
  return commands;
}

export function convertProject(root, source) {
  const roots = source.quality.source_roots;
  const testRoots = roots.filter((path) => /(^|\/)(tests?|__tests__)(\/|$)/i.test(path));
  const sourceRoots = roots.filter((path) => !testRoots.includes(path));
  const quality = { source_roots: sourceRoots, test_roots: testRoots, generated_roots: source.quality.generated_roots };
  if (source.project.language === 'typescript') quality.tsconfig = 'tsconfig.json';
  return { schema_version: '2.0', brain_version: brainVersion, project: source.project, quality, verification: { commands: detectedCommands(root) } };
}

export function convertTask(source) {
  const id = source.task.id.replace(/^HOTFIX-/, '');
  const area = source.task.layer === 'ui' ? 'presentation' : source.task.layer;
  const allowed = ['domain', 'application', 'presentation', 'infrastructure'];
  return {
    schema_version: '2.0',
    task: { id: source.task.id, type: source.task.type, story_path: `.hc/stories/${id}.json`, acceptance_criteria: source.task.acceptance_criteria, change_areas: allowed.includes(area) ? [area] : ['delivery'], risk_tags: [] },
    scope: { ...source.scope, related_paths: source.scope.related_paths ?? [] },
    constraints: source.constraints ?? [], authority: source.authority,
  };
}
