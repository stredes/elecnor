import { resolve } from 'node:path';
import { readText, relativeUnix } from '../shared/fs.mjs';

function splitFiles(root, manifest, files) {
  const roots = manifest.quality.source_roots.map((path) => resolve(root, path));
  const production = files.filter((path) => roots.some((sourceRoot) =>
    path === sourceRoot || path.startsWith(`${sourceRoot}/`)));
  return { production, tests: files.filter((path) => !production.includes(path)) };
}

function synchronizeIsFalse(expression, source) {
  const value = expression.trim();
  if (value === 'false') return true;
  const helper = value.match(/^(\w*Synchronize)\s*\(\s*\)$/i)?.[1];
  if (!helper) return false;
  const start = source.search(new RegExp(`\\b${helper}\\s*(?:=|\\()`));
  if (start < 0) return false;
  const implementation = source.slice(start, start + 1600);
  return /\breturn\s+false\b/.test(implementation) && !/\breturn\s+true\b/.test(implementation);
}

function persistenceErrors(root, files) {
  const contents = files.map((path) => readText(path));
  if (!contents.some((content) => /from\s+['"](?:typeorm|@nestjs\/typeorm)['"]/.test(content))) return [];
  const errors = [];
  const migrations = files.filter((path) => /(?:^|\/)migrations?(?:\/|$)/i.test(path));
  if (!migrations.some((path) => /MigrationInterface|\basync\s+up\s*\(/.test(readText(path)))) {
    errors.push('TypeORM schema requires a migration artifact');
  }
  if (!contents.some((content) => /\bmigrations\s*:/.test(content))) {
    errors.push('TypeORM runtime must load migrations explicitly');
  }
  const source = contents.join('\n');
  for (const path of files) {
    const content = readText(path);
    for (const match of content.matchAll(/\bsynchronize\s*:\s*([^,}\n]+)/g)) {
      if (synchronizeIsFalse(match[1], source)) continue;
      errors.push(`${relativeUnix(root, path)}: synchronize must resolve to false`);
    }
  }
  return errors;
}

function bootstrapErrors(production, tests) {
  const mainPath = production.find((path) => /(?:^|\/)main\.[cm]?[jt]s$/.test(path));
  if (!mainPath) return [];
  const main = readText(mainPath);
  const sharedCall = main.match(/\b((?:apply|configure|setup)\w*(?:App|Http)\w*)\s*\(\s*app\b/i)?.[1];
  const hasHttpConfig = /useGlobalPipes|setGlobalPrefix|enableCors|useGlobalFilters/.test(main) || sharedCall;
  const e2eApps = tests.filter((path) => /e2e/i.test(path) && /createNestApplication\s*\(/.test(readText(path)));
  if (!hasHttpConfig || !e2eApps.length) return [];
  if (sharedCall && e2eApps.every((path) => readText(path).includes(`${sharedCall}(app`))) return [];
  return ['e2e Nest applications must apply shared HTTP configuration'];
}

function controllerErrors(root, files) {
  const errors = [];
  for (const path of files) {
    const content = readText(path);
    if (!/@Controller\s*\(/.test(content)) continue;
    const location = relativeUnix(root, path);
    if (/from\s+['"](?:typeorm|@nestjs\/typeorm|[^'"]*\/persistence(?:\/|['"]))/i.test(content)) {
      errors.push(`${location}: controller cannot import persistence technology`);
    }
    if (/\b(?:if|for|while|switch)\s*\(|\.(?:map|filter|reduce|some|every)\s*\(/m.test(content)) {
      errors.push(`${location}: controller contains business control flow`);
    }
  }
  return errors;
}

export function checkBackendRuntime(root, manifest, files) {
  if (manifest.project.profile !== 'backend-nest') return [];
  const { production, tests } = splitFiles(root, manifest, files);
  return [
    ...persistenceErrors(root, production),
    ...bootstrapErrors(production, tests),
    ...controllerErrors(root, production),
  ];
}
