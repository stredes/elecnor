import { matchingDelimiter, topLevelPositions } from './source-balance.mjs';

const skipSpace = (source, start) => {
  let index = start;
  while (/\s/.test(source[index] ?? '')) index += 1;
  return index;
};

export function nestBodyTypes(content) {
  const types = [];
  const marker = /@Body\b/g;
  for (const match of content.matchAll(marker)) {
    let cursor = skipSpace(content, match.index + match[0].length);
    if (content[cursor] === '(') {
      const end = matchingDelimiter(content, cursor);
      if (end < 0) continue;
      cursor = skipSpace(content, end + 1);
    }
    const parameter = /^(?:readonly\s+)?\w+\s*:\s*([A-Za-z_$][\w$]*)/.exec(content.slice(cursor));
    if (parameter) types.push(parameter[1]);
  }
  return types;
}

export function nestClassBody(content, type) {
  const declaration = new RegExp(`\\bclass\\s+${type}\\b[^\\{]*\\{`).exec(content);
  if (!declaration) return null;
  const open = declaration.index + declaration[0].length - 1;
  const close = matchingDelimiter(content, open);
  return close < 0 ? null : content.slice(open + 1, close);
}

function decoratorRanges(body, topLevel) {
  const ranges = [];
  for (const match of body.matchAll(/@[A-Za-z_$][\w$.]*/g)) {
    if (!topLevel.has(match.index)) continue;
    let end = skipSpace(body, match.index + match[0].length);
    if (body[end] === '(') {
      const close = matchingDelimiter(body, end);
      if (close < 0) continue;
      end = close + 1;
    }
    ranges.push({ start: match.index, end });
  }
  return ranges;
}

function decoratorsBefore(body, propertyStart, ranges) {
  let cursor = propertyStart;
  const selected = [];
  for (const range of ranges.toReversed()) {
    if (range.end > cursor) continue;
    if (body.slice(range.end, cursor).trim()) break;
    selected.unshift(body.slice(range.start, range.end));
    cursor = range.start;
  }
  return selected.join('\n');
}

export function nestProperties(body) {
  const topLevel = topLevelPositions(body);
  const ranges = decoratorRanges(body, topLevel);
  const pattern = /(?:readonly\s+)?(\w+)([!?]?)\s*:\s*([^;\n=}]+)(?:[;=]|\n|$)/g;
  return [...body.matchAll(pattern)].filter((match) => {
    const nameAt = match.index + match[0].indexOf(match[1]);
    return topLevel.has(nameAt);
  }).map((match) => ({
    decorators: decoratorsBefore(body, match.index, ranges),
    name: match[1], optional: match[2], valueType: match[3].trim(),
  }));
}

export function validationPipeOptions(contents) {
  for (const content of contents) {
    for (const match of content.matchAll(/useGlobalPipes\b/g)) {
      const callOpen = content.indexOf('(', match.index + match[0].length);
      const callClose = matchingDelimiter(content, callOpen);
      if (callClose < 0) continue;
      const call = content.slice(callOpen + 1, callClose);
      const pipe = /new\s+ValidationPipe\b/.exec(call);
      if (!pipe) continue;
      const pipeOpen = call.indexOf('(', pipe.index + pipe[0].length);
      const pipeClose = matchingDelimiter(call, pipeOpen);
      if (pipeClose < 0) continue;
      const objectOpen = skipSpace(call, pipeOpen + 1);
      if (call[objectOpen] !== '{') continue;
      const objectClose = matchingDelimiter(call, objectOpen);
      if (objectClose > 0 && objectClose < pipeClose) return call.slice(objectOpen + 1, objectClose);
    }
  }
  return null;
}

export function hasStrictPipeOption(options, name) {
  const topLevel = topLevelPositions(options);
  const pattern = new RegExp(`\\b${name}\\s*:\\s*true\\b`, 'g');
  return [...options.matchAll(pattern)].some((match) => topLevel.has(match.index));
}
