import { checkWebConventions } from './web-conventions.mjs';
import { checkMobileConventions } from './mobile-conventions.mjs';
import { checkElectronConventions } from './electron-conventions.mjs';
import { checkUnityConventions } from './unity-conventions.mjs';

export function checkProfileConventions(root, manifest, files) {
  return [
    ...checkWebConventions(root, manifest, files),
    ...checkMobileConventions(root, manifest, files),
    ...checkElectronConventions(root, manifest, files),
    ...checkUnityConventions(root, manifest, files),
  ];
}
