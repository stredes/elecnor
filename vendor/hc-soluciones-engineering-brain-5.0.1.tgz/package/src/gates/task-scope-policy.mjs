const unix = (value) => value.replaceAll('\\', '/').replace(/^\.\//, '').replace(/\/$/, '');
const isUnder = (path, root) => path === root || path.startsWith(`${root}/`);

function pathLike(value) {
  return !/\s/.test(value) && (value.includes('/') || /\.[a-z0-9]+$/i.test(value));
}

function allowedRoots(task) {
  const declared = [
    ...task.scope.related_paths,
    ...task.scope.include.filter(pathLike),
    task.task.story_path,
    `.hc/evidence/${task.task.id}.json`,
    '.hc/task.json',
  ];
  return [...new Set(declared.map(unix))];
}

function hasAuthority(task, pattern) {
  return task.authority.allowed.some((item) => pattern.test(item));
}

export function validateTaskChanges(task, changedFiles, options = {}) {
  const files = changedFiles.map(unix);
  const roots = allowedRoots(task);
  const errors = [];
  for (const path of files) {
    if (!roots.some((root) => isUnder(path, root))) errors.push(`${path}: outside declared task scope`);
  }
  const risks = new Set(task.task.risk_tags);
  if (options.dependencyChanged) {
    if (!hasAuthority(task, /dependenc|package/i)) errors.push('dependency change requires explicit dependency authority');
    if (!risks.has('dependency')) errors.push('dependency change requires dependency risk tag');
  }
  const databasePaths = files.filter((path) => /(?:^|\/)(?:database|persistence|migrations)(?:\/|$)/i.test(path));
  const database = databasePaths.length > 0;
  if (database && !hasAuthority(task, /database|\bdb\b|migration|persistence/i)) {
    errors.push('database change requires explicit database authority');
  }
  const structure = databasePaths.some((path) => /(?:migration|schema)/i.test(path));
  if (structure && !risks.has('migration')) errors.push('database structure change requires migration risk tag');
  if (structure && !risks.has('persistence')) errors.push('database structure change requires persistence risk tag');
  const governance = files.some((path) => /(?:^|\/)(?:gates|\.github\/workflows)(?:\/|$)/.test(path));
  if (governance && !hasAuthority(task, /gate|ci|workflow/i)) errors.push('gate or CI change requires explicit authority');
  return errors;
}
