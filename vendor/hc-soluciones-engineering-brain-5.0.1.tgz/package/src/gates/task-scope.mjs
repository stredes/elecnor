import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { readJson } from '../shared/fs.mjs';
import { runDeclaredCommand } from '../verification/command-runner.mjs';
import { validateTaskChanges } from './task-scope-policy.mjs';

export { validateTaskChanges } from './task-scope-policy.mjs';

const baseBranch = (task) => task.task.type === 'hotfix' ? 'main' : 'Development';

function statusPaths(output) {
  return output.split('\n').filter(Boolean).map((line) => {
    const path = line.slice(3);
    return path.includes(' -> ') ? path.split(' -> ').at(-1) : path;
  });
}

async function changedPaths(root, task, execute) {
  const base = baseBranch(task);
  const committed = await execute(root, {
    argv: ['git', 'diff', '--name-only', `${base}...HEAD`], timeout_seconds: 30,
  });
  const working = await execute(root, {
    argv: ['git', 'status', '--porcelain=v1', '--untracked-files=all'], timeout_seconds: 30,
  });
  const paths = committed.exitCode === 0 ? committed.output.trim().split('\n').filter(Boolean) : [];
  if (working.exitCode === 0) paths.push(...statusPaths(working.output));
  return [...new Set(paths)];
}

const ordered = (value) => JSON.stringify(Object.fromEntries(Object.entries(value ?? {}).sort()));

async function dependencyChanged(root, task, paths, execute) {
  if (!paths.includes('package.json') || !existsSync(join(root, 'package.json'))) return false;
  const base = await execute(root, {
    argv: ['git', 'show', `${baseBranch(task)}:package.json`], timeout_seconds: 30,
  });
  if (base.exitCode !== 0) return false;
  try {
    const before = JSON.parse(base.output);
    const current = readJson(join(root, 'package.json'));
    return ordered(before.dependencies) !== ordered(current.dependencies)
      || ordered(before.devDependencies) !== ordered(current.devDependencies);
  } catch {
    return true;
  }
}

export async function checkTaskScope(root, task, execute = runDeclaredCommand) {
  const paths = await changedPaths(root, task, execute);
  const changedDependencies = await dependencyChanged(root, task, paths, execute);
  return validateTaskChanges(task, paths, { dependencyChanged: changedDependencies });
}
