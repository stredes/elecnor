const pairs = { '(': ')', '[': ']', '{': '}' };
const opening = new Set(Object.keys(pairs));
const closing = new Set(Object.values(pairs));

function quotedEnd(source, start, quote) {
  for (let index = start + 1; index < source.length; index += 1) {
    if (source[index] === '\\') index += 1;
    else if (source[index] === quote) return index;
  }
  return source.length - 1;
}

function regexEnd(source, start) {
  let characterClass = false;
  for (let index = start + 1; index < source.length; index += 1) {
    if (source[index] === '\\') index += 1;
    else if (source[index] === '[') characterClass = true;
    else if (source[index] === ']') characterClass = false;
    else if (source[index] === '/' && !characterClass) {
      while (/[a-z]/i.test(source[index + 1] ?? '')) index += 1;
      return index;
    }
  }
  return start;
}

function previousCodeCharacter(source, index) {
  while (index >= 0 && /\s/.test(source[index])) index -= 1;
  return source[index];
}

function skippedEnd(source, index) {
  const char = source[index];
  if (['\'', '"', '`'].includes(char)) return quotedEnd(source, index, char);
  if (source.slice(index, index + 2) === '//') {
    const end = source.indexOf('\n', index + 2);
    return end < 0 ? source.length - 1 : end;
  }
  if (source.slice(index, index + 2) === '/*') {
    const end = source.indexOf('*/', index + 2);
    return end < 0 ? source.length - 1 : end + 1;
  }
  if (char === '/' && /[(:,=[!&|?{};]/.test(previousCodeCharacter(source, index - 1) ?? ':')) {
    return regexEnd(source, index);
  }
  return index;
}

export function matchingDelimiter(source, start) {
  if (!opening.has(source[start])) return -1;
  const stack = [source[start]];
  for (let index = start + 1; index < source.length; index += 1) {
    const skipped = skippedEnd(source, index);
    if (skipped !== index) { index = skipped; continue; }
    if (opening.has(source[index])) stack.push(source[index]);
    else if (closing.has(source[index])) {
      if (pairs[stack.at(-1)] !== source[index]) return -1;
      stack.pop();
      if (!stack.length) return index;
    }
  }
  return -1;
}

export function topLevelPositions(source) {
  const positions = new Set();
  const stack = [];
  for (let index = 0; index < source.length; index += 1) {
    if (!stack.length) positions.add(index);
    const skipped = skippedEnd(source, index);
    if (skipped !== index) { index = skipped; continue; }
    if (opening.has(source[index])) stack.push(source[index]);
    else if (closing.has(source[index]) && pairs[stack.at(-1)] === source[index]) stack.pop();
  }
  return positions;
}
