import { relative, resolve } from 'node:path';
import { readText } from '../shared/fs.mjs';
import { validateNestInput } from './nest-input.mjs';
import { checkBackendOpenApi } from './backend-openapi.mjs';
import { checkBackendRuntime } from './backend-runtime.mjs';
import { checkBackendTestInfrastructure } from './backend-test-infrastructure.mjs';

const unix = (value) => value.replaceAll('\\', '/');

function location(root, path) {
  return unix(relative(root, path));
}

function secretErrors(root, files) {
  const errors = [];
  const fallback = /(?:JWT_SECRET|\bsecret\s*:)[^\n]*(?:\?\?|\|\|)\s*['"][^'"]+['"]/;
  for (const path of files) if (fallback.test(readText(path))) errors.push(`${location(root, path)}: literal secret fallback`);
  return errors;
}

function portErrors(root, files) {
  const errors = [];
  for (const path of files) {
    const name = location(root, path);
    const content = readText(path);
    if (/\/domain\/.*\.repository\.tsx?$/.test(name)) errors.push(`${name}: outbound repository ports belong in application/ports`);
    if (/\/infrastructure\//.test(name) && /from\s+['"][^'"]*\/domain\/[^'"]*repository['"]/.test(content)) {
      errors.push(`${name}: adapter implements a repository port from domain`);
    }
    if (/\/application\/ports\//.test(name) && !/\.port\.tsx?$/.test(name)) errors.push(`${name}: application port must use *.port.ts`);
  }
  return errors;
}

function reviewSignals(root, files) {
  const reviews = [];
  for (const path of files) {
    const name = location(root, path);
    const content = readText(path);
    if (/(?:\/dto\/|\.dto\.tsx?$)/.test(name) && /@IsString[\s\S]{0,160}\bname\s*[!?]?:\s*string/.test(content) && !/@(?:IsNotEmpty|MinLength)/.test(content)) {
      reviews.push(`${name}: string name accepts empty input`);
    }
    if (/(?:\/dto\/|\.dto\.tsx?$)/.test(name)) {
      for (const match of content.matchAll(/(@IsString\(\)[\s\S]{0,160}?\b(password|email|name)\s*[!?]?:\s*string)/g)) {
        if (!/@MaxLength\s*\(/.test(match[1])) reviews.push(`${name}: ${match[2]} external string lacks @MaxLength`);
      }
    }
    const typeImport = content.match(/import\s+type\s+\{\s*(\w+)\s*\}/)?.[1];
    if (typeImport && new RegExp(`@ApiProperty\\([^)]*\\)[\\s\\S]{0,80}:\\s*${typeImport}\\b`).test(content)) {
      reviews.push(`${name}: Swagger property uses an erased type-only contract`);
    }
  }
  return reviews;
}

function concurrencyErrors(root, manifest, files, task) {
  if (!task?.task.risk_tags.includes('concurrency')) return [];
  const roots = manifest.quality.source_roots.map((path) => resolve(root, path));
  const production = files.filter((path) =>
    roots.some((sourceRoot) => path === sourceRoot || path.startsWith(`${sourceRoot}/`)),
  );
  const memoryName = /(?:in[-_ ]?memory|memory.*(?:repository|store|adapter))/i;
  const memoryContent = /\bnew\s+Map\s*(?:<|\()/;
  return production
    .filter((path) => /(?:^|\/)persistence(?:\/|$)/i.test(path))
    .filter((path) => memoryName.test(path) || memoryContent.test(readText(path)))
    .map((path) => `${location(root, path)}: in-memory persistence cannot satisfy concurrency`);
}

export function checkNestConventions(root, manifest, files, task) {
  if (manifest.project.profile !== 'backend-nest') return { errors: [], reviews: [] };
  const errors = [
    ...secretErrors(root, files), ...portErrors(root, files),
    ...validateNestInput(root, manifest, files), ...concurrencyErrors(root, manifest, files, task),
    ...checkBackendOpenApi(root, manifest, files), ...checkBackendRuntime(root, manifest, files),
    ...checkBackendTestInfrastructure(root, manifest, files),
  ];
  const reviews = reviewSignals(root, files);
  return { errors, reviews };
}
