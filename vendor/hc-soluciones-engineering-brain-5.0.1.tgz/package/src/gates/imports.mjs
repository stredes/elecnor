const javascriptPatterns = [
  /(?:import|export)\s+(?:[\s\S]*?\s+from\s+)?['"]([^'"]+)['"]/g,
  /import\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
  /require\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
];

export function collectImports(path, content) {
  const imports = new Set();
  if (path.endsWith('.cs')) {
    for (const match of content.matchAll(/^\s*using\s+(?:static\s+)?([\w.]+)\s*;/gm)) imports.add(match[1]);
    return [...imports];
  }
  for (const pattern of javascriptPatterns) {
    for (const match of content.matchAll(pattern)) imports.add(match[1]);
  }
  return [...imports];
}
