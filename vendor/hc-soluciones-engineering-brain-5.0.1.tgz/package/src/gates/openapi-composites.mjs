import { readText } from '../shared/fs.mjs';

const exportedComposite = /export\s+(?:const|function)\s+(Api[A-Za-z0-9_$]+)/g;
const successDecorator = /Api(?:Ok|Created|Accepted|NoContent)Response\s*\(|ApiResponse\s*\(\s*\{[\s\S]{0,500}?status\s*:\s*20\d/;

export function openApiComposites(files) {
  const operations = new Set();
  const successes = new Set();
  for (const path of files) {
    const content = readText(path);
    if (!/\bapplyDecorators\s*\(/.test(content)) continue;
    const names = [...content.matchAll(exportedComposite)].map((match) => match[1]);
    if (/\bApiOperation\s*\(/.test(content)) for (const name of names) operations.add(name);
    if (successDecorator.test(content)) for (const name of names) successes.add(name);
  }
  return { operations, successes };
}

export function compositeCount(content, names) {
  let total = 0;
  for (const name of names) total += [...content.matchAll(new RegExp(`@${name}\\s*\\(`, 'g'))].length;
  return total;
}
