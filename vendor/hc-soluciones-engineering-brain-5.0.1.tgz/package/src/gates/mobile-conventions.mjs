import { resolve } from 'node:path';
import { readText, relativeUnix } from '../shared/fs.mjs';

const infrastructureImport = /from\s+['"][^'"]*\/infrastructure(?:\/|['"])/;
const nativeImport = /from\s+['"](?:expo(?:-[^'"]+|\/[^'"]+)?|react-native(?:\/[^'"]+)?|@react-native[^'"]*)['"]/;
const sensitiveNames = /\b(?:token|session|auth|credential|refresh)\w*\b/i;
const remoteNames = /\b(?:users|professionals|bookings|services|messages|payments|availability)\b/i;

function productionFiles(root, manifest, files) {
  const roots = manifest.quality.source_roots.map((path) => resolve(root, path));
  return files.filter((path) => roots.some((sourceRoot) =>
    path === sourceRoot || path.startsWith(`${sourceRoot}/`)));
}

function boundaryErrors(root, path, content) {
  const relative = relativeUnix(root, path);
  const errors = [];
  if (/^(?:app|src\/app)\//.test(relative) && infrastructureImport.test(content)) {
    errors.push(`${relative}: route module imports feature infrastructure directly`);
  }
  if (/\/presentation\//.test(relative) && infrastructureImport.test(content)) {
    errors.push(`${relative}: presentation imports infrastructure directly`);
  }
  if (/\/(?:domain|application)\//.test(relative) && nativeImport.test(content)) {
    errors.push(`${relative}: native API must stay behind infrastructure`);
  }
  return errors;
}

function storageErrors(root, path, content) {
  const relative = relativeUnix(root, path);
  const errors = [];
  const asyncStorageWrite = /\bAsyncStorage\.(?:setItem|multiSet)\s*\([\s\S]{0,300}/.exec(content)?.[0] ?? '';
  if (sensitiveNames.test(asyncStorageWrite)) {
    errors.push(`${relative}: sensitive session data uses AsyncStorage`);
  }
  if (/\bpersist\s*\(/.test(content)) {
    const slice = content.match(/\bpartialize\s*:[\s\S]{0,900}/)?.[0] ?? content;
    if (sensitiveNames.test(slice) || remoteNames.test(slice)) {
      errors.push(`${relative}: persisted UI state contains remote or sensitive data`);
    }
  }
  return errors;
}

export function checkMobileConventions(root, manifest, files) {
  if (manifest.project.profile !== 'mobile-expo') return [];
  const errors = [];
  for (const path of productionFiles(root, manifest, files)) {
    const content = readText(path);
    errors.push(...boundaryErrors(root, path, content));
    errors.push(...storageErrors(root, path, content));
  }
  return errors;
}
