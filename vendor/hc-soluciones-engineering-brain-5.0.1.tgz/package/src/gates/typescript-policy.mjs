import { createRequire } from 'node:module';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { readJson } from '../shared/fs.mjs';

const strictFlags = [
  'noImplicitAny', 'strictNullChecks', 'strictFunctionTypes', 'strictBindCallApply',
  'strictPropertyInitialization', 'noImplicitThis', 'useUnknownInCatchVariables',
];

function configPath(root, parentPath, specifier) {
  if (isAbsolute(specifier)) return specifier;
  if (specifier.startsWith('.')) {
    const path = resolve(dirname(parentPath), specifier);
    return path.endsWith('.json') ? path : `${path}.json`;
  }
  const require = createRequire(join(root, 'package.json'));
  return require.resolve(specifier);
}

function effectiveOptions(root, path, visited = new Set()) {
  const absolute = resolve(root, path);
  if (visited.has(absolute)) throw new Error(`circular tsconfig extends at ${absolute}`);
  visited.add(absolute);
  const config = readJson(absolute);
  const inherited = config.extends
    ? effectiveOptions(root, configPath(root, absolute, config.extends), visited)
    : {};
  return { ...inherited, ...(config.compilerOptions ?? {}) };
}

export function checkTypeScriptPolicy(root, path) {
  let options;
  try { options = effectiveOptions(root, path); } catch (error) { return [`cannot inspect strict TypeScript config: ${error.message}`]; }
  const errors = [];
  if (options.strict !== true) errors.push('TypeScript compilerOptions.strict must be true');
  for (const flag of strictFlags) {
    if (options[flag] === false) errors.push(`${flag} cannot disable strict mode`);
  }
  return errors;
}
