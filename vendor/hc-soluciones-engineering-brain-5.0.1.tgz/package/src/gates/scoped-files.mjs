import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { walkFiles, hasExtension, relativeUnix } from '../shared/fs.mjs';

const isUnder = (path, root) => path === root || path.startsWith(`${root}/`);

export function scopedFilesForRoots(projectRoot, roots, generatedRoots, policy) {
  const excluded = new Set(policy.always_excluded_segments);
  const generated = generatedRoots.map((path) => path.replaceAll('\\', '/').replace(/\/$/, ''));
  const files = [];
  const missing = [];
  for (const sourceRoot of roots) {
    const absolute = resolve(projectRoot, sourceRoot);
    if (!existsSync(absolute)) {
      missing.push(`${sourceRoot}: source root is missing`);
      continue;
    }
    const walked = walkFiles(absolute, excluded);
    for (const path of walked) {
      const relative = relativeUnix(projectRoot, path);
      if (!hasExtension(path, policy.extensions)) continue;
      if (generated.some((root) => isUnder(relative, root))) continue;
      files.push(path);
    }
  }
  return { files: [...new Set(files)], missing };
}

export function scopedSourceFiles(projectRoot, manifest, policy) {
  const roots = [...manifest.quality.source_roots, ...manifest.quality.test_roots];
  return scopedFilesForRoots(projectRoot, roots, manifest.quality.generated_roots, policy);
}
