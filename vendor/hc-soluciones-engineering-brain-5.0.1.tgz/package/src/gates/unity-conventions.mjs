import { readJson, readText, relativeUnix } from '../shared/fs.mjs';

const engineState = /UnityEngine\.(?:Time|Input|Physics|PlayerPrefs|Resources)|\bSceneManager\s*\.|\b(?:DateTime\.(?:Now|UtcNow)|Guid\.NewGuid|new\s+Random\s*\()/;

function layer(path) {
  return path.match(/(?:^|\/)(Core|Domain|Application|Infrastructure|Presentation|Bootstrap)(?:\/|$)/i)?.[1]?.toLowerCase();
}

function asmdefErrors(root, files) {
  const errors = [];
  const definitions = files.filter((path) => path.endsWith('.asmdef'));
  for (const path of definitions) {
    const currentLayer = layer(path);
    if (!['core', 'domain', 'application'].includes(currentLayer)) continue;
    let definition;
    try { definition = readJson(path); } catch (error) {
      errors.push(`${relativeUnix(root, path)}: invalid asmdef JSON: ${error.message}`);
      continue;
    }
    const name = currentLayer[0].toUpperCase() + currentLayer.slice(1);
    if (definition.noEngineReferences !== true) {
      errors.push(`${relativeUnix(root, path)}: ${name} asmdef must enable No Engine References`);
    }
    const outwardPattern = currentLayer === 'core'
      ? /(?:Domain|Application|Infrastructure|Presentation|Adapter|XR|Training)/i
      : currentLayer === 'domain'
        ? /(?:Application|Infrastructure|Presentation|Adapter|XR)/i
      : /(?:Infrastructure|Presentation|Adapter|XR)/i;
    const outward = (definition.references ?? []).find((reference) => outwardPattern.test(reference));
    if (outward) errors.push(`${relativeUnix(root, path)}: ${name} asmdef references an outward assembly ${outward}`);
  }
  for (const required of ['core', 'domain', 'application']) {
    const hasCode = files.some((path) => path.endsWith('.cs') && layer(path) === required);
    const hasDefinition = definitions.some((path) => layer(path) === required);
    if (hasCode && !hasDefinition) errors.push(`${required} C# code requires its own asmdef`);
  }
  return errors;
}

function sourceErrors(root, files) {
  const errors = [];
  for (const path of files.filter((item) => item.endsWith('.cs'))) {
    const currentLayer = layer(path);
    const content = readText(path);
    if (['core', 'domain', 'application'].includes(currentLayer) && engineState.test(content)) {
      errors.push(`${relativeUnix(root, path)}: engine time, input, scene and storage APIs require ports`);
    }
    if (currentLayer === 'presentation'
      && /using\s+(?:System\.IO|System\.Net\.Http)|\bPlayerPrefs\s*\./.test(content)) {
      errors.push(`${relativeUnix(root, path)}: presentation cannot perform persistence or network I/O`);
    }
    if (!['infrastructure', 'presentation', 'bootstrap'].includes(currentLayer) && /\bMonoBehaviour\b/.test(content)) {
      errors.push(`${relativeUnix(root, path)}: MonoBehaviour belongs in an outer adapter`);
    }
  }
  return errors;
}

export function checkUnityConventions(root, manifest, files) {
  if (manifest.project.profile !== 'vr-unity') return [];
  return [...asmdefErrors(root, files), ...sourceErrors(root, files)];
}
