import { createRequire } from 'node:module';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { runDeclaredCommand } from '../verification/command-runner.mjs';

function compilerBin(root) {
  const require = createRequire(join(root, 'package.json'));
  const packagePath = require.resolve('typescript/package.json');
  const metadata = require(packagePath);
  return resolve(dirname(packagePath), metadata.bin.tsc);
}

export async function projectDiagnostics(root, configPath, files) {
  let bin;
  try { bin = compilerBin(root); } catch { return ['project TypeScript is not installed']; }
  const temporary = mkdtempSync(join(tmpdir(), 'hc-tsconfig-'));
  const path = join(temporary, 'tsconfig.json');
  const config = {
    extends: resolve(root, configPath),
    compilerOptions: { noEmit: true, incremental: false, composite: false },
    files,
    include: [],
    exclude: [],
  };
  writeFileSync(path, JSON.stringify(config));
  try {
    const result = await runDeclaredCommand(root, { argv: [process.execPath, bin, '--project', path, '--pretty', 'false'], timeout_seconds: 120 });
    return result.exitCode === 0 ? [] : result.output.trim().split('\n');
  } finally {
    rmSync(temporary, { recursive: true, force: true });
  }
}
