import { resolve } from 'node:path';
import { readText, relativeUnix } from '../shared/fs.mjs';

const clientDirective = /^\s*['"]use client['"];?/m;
const serverApi = /from\s+['"](?:next\/(?:headers|cache)|server-only|node:[^'"]+)['"]|\bprocess\.env\.(?!(?:NEXT_PUBLIC_|NODE_ENV\b))/;
const backendAdapter = /from\s+['"][^'"]*(?:\/infrastructure\/[^'"]*(?:http|backend|repository)|@\/infrastructure\/|\/core\/backend|@\/core\/backend)[^'"]*['"]/i;
const sessionMaterial = /\bdocument\.cookie\b|\bSESSION_COOKIE\b|hc_dashboard_token/;
const remoteState = /\b(?:token|session|users|professionals|bookings|services|messages|payments)\b/i;

function productionFiles(root, manifest, files) {
  const roots = manifest.quality.source_roots.map((path) => resolve(root, path));
  return files.filter((path) => roots.some((sourceRoot) =>
    path === sourceRoot || path.startsWith(`${sourceRoot}/`)));
}

function clientErrors(root, path, content) {
  if (!clientDirective.test(content)) return [];
  const location = relativeUnix(root, path);
  const errors = [];
  if (serverApi.test(content)) errors.push(`${location}: client module imports server-only API`);
  if (backendAdapter.test(content)) errors.push(`${location}: client module imports backend adapter`);
  if (sessionMaterial.test(content)) errors.push(`${location}: client module reads session material`);
  return errors;
}

function stateErrors(root, path, content) {
  if (!/\bpersist\s*\(/.test(content)) return [];
  const persisted = content.match(/\bpartialize\s*:[\s\S]{0,900}/)?.[0] ?? content;
  if (!remoteState.test(persisted)) return [];
  return [`${relativeUnix(root, path)}: persisted UI state contains remote or sensitive data`];
}

function routeErrors(root, path, content) {
  const relative = relativeUnix(root, path);
  if (!/^src\/app\/api\/dashboard\/.+\/route\.[jt]s$/.test(relative)) return [];
  if (!/export\s+(?:const|async\s+function)\s+(?:GET|POST|PUT|PATCH|DELETE)\b/.test(content)) return [];
  const sessionBoundary = /handle\w*Api|with\w*Session|require\w*Session|\bcookies\s*\(/i;
  return sessionBoundary.test(content) ? [] : [`${relative}: dashboard API route lacks a server session boundary`];
}

export function checkWebConventions(root, manifest, files) {
  if (!['web-next', 'desktop-electron'].includes(manifest.project.profile)) return [];
  const errors = [];
  for (const path of productionFiles(root, manifest, files)) {
    const content = readText(path);
    errors.push(...clientErrors(root, path, content));
    errors.push(...stateErrors(root, path, content));
    if (manifest.project.profile === 'web-next') errors.push(...routeErrors(root, path, content));
  }
  return errors;
}
