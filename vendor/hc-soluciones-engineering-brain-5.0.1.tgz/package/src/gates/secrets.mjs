import { existsSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { readText, relativeUnix, walkFiles } from '../shared/fs.mjs';
import { runDeclaredCommand } from '../verification/command-runner.mjs';

const patterns = [
  ['private key', /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
  ['AWS access key', /AKIA[0-9A-Z]{16}/],
  ['GitHub token', /gh[pousr]_[A-Za-z0-9]{36,255}/],
  ['live secret key', /sk_live_[A-Za-z0-9]{16,}/],
  ['credential-bearing database URL', /(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?):\/\/[^:\s/'"]+:[^@\s/'"]+@/],
];
const excluded = new Set(['.git', 'node_modules', 'vendor', 'dist', 'build', 'coverage', '.next', 'Library']);

async function candidateFiles(root) {
  const command = {
    argv: ['git', '-C', root, 'ls-files', '--cached', '--others', '--exclude-standard', '-z'],
    timeout_seconds: 30,
  };
  const result = await runDeclaredCommand(root, command);
  return result.exitCode === 0
    ? result.output.split('\0').filter(Boolean).map((path) => join(root, path))
    : walkFiles(root, excluded);
}

export async function checkSecrets(root) {
  const errors = [];
  for (const path of await candidateFiles(root)) {
    if (!existsSync(path) || statSync(path).size > 1_000_000) continue;
    let content;
    try {
      content = readText(path);
    } catch {
      continue;
    }
    if (content.includes('\0')) continue;
    for (const [label, pattern] of patterns) {
      if (pattern.test(content)) errors.push(`${relativeUnix(root, path)}: possible ${label}`);
    }
  }
  return errors;
}
