import { fromBrain } from '../config/brain-paths.mjs';
import { readJson, readText, relativeUnix } from '../shared/fs.mjs';
import { loadProject } from '../validation/project.mjs';
import { scopedSourceFiles } from './scoped-files.mjs';
import { collectImports } from './imports.mjs';
import { findCycles } from './cycles.mjs';

function ruleErrors(root, files, rule) {
  const errors = [];
  const from = new RegExp(rule.from);
  for (const path of files) {
    const relative = relativeUnix(root, path);
    if (!from.test(relative)) continue;
    const content = readText(path);
    for (const imported of collectImports(path, content)) {
      const forbidden = rule.forbidden_imports.find((pattern) => new RegExp(pattern).test(imported));
      if (forbidden) errors.push(`${rule.id} ${relative}: forbidden import ${imported}`);
    }
    for (const pattern of rule.forbidden_content ?? []) {
      if (new RegExp(pattern).test(content)) {
        errors.push(`${rule.id} ${relative}: ${rule.message ?? `forbidden content ${pattern}`}`);
      }
    }
  }
  return errors;
}

function profileRules(profile, seen = new Set()) {
  if (seen.has(profile)) throw new Error(`circular profile inheritance at ${profile}`);
  seen.add(profile);
  const config = readJson(fromBrain(`gates/profiles/${profile}.json`));
  const inherited = config.extends ? profileRules(config.extends, seen) : [];
  return [...inherited, ...config.rules];
}

export function checkArchitecture(projectRoot) {
  const manifest = loadProject(projectRoot);
  const policy = readJson(fromBrain('gates/core/file-policy.json'));
  const { files, missing } = scopedSourceFiles(projectRoot, manifest, policy);
  const errors = [...missing];
  for (const rule of profileRules(manifest.project.profile)) {
    errors.push(...ruleErrors(projectRoot, files, rule));
  }
  if (manifest.project.language !== 'typescript') {
    for (const cycle of findCycles(projectRoot, files)) errors.push(`dependency cycle: ${cycle}`);
  }
  return errors;
}
