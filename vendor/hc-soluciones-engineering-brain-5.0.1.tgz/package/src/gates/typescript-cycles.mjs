import { existsSync } from 'node:fs';
import { dirname, extname, relative, resolve } from 'node:path';
import { collectImports } from './imports.mjs';
import { readText } from '../shared/fs.mjs';

const extensions = ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs'];
const unix = (value) => value.replaceAll('\\', '/');

function candidates(base) {
  return extname(base) ? [base] : [...extensions.map((ext) => `${base}${ext}`), ...extensions.map((ext) => resolve(base, `index${ext}`))];
}

function pathTarget(root, specifier, options) {
  for (const [pattern, targets] of Object.entries(options.paths ?? {})) {
    const expression = new RegExp(`^${pattern.replace('*', '(.+)')}$`);
    const match = specifier.match(expression);
    if (!match) continue;
    const target = targets[0].replace('*', match[1] ?? '');
    return resolve(root, options.baseUrl ?? '.', target);
  }
  return null;
}

function resolveImport(root, from, specifier, known, options) {
  const base = specifier.startsWith('.') ? resolve(dirname(from), specifier) : pathTarget(root, specifier, options);
  if (!base) return null;
  return candidates(base).map((path) => resolve(path)).find((path) => existsSync(path) && known.has(path)) ?? null;
}

export function typescriptCycles(root, files, compilerOptions = {}) {
  const known = new Set(files.map((path) => resolve(path)));
  const graph = new Map(files.map((path) => [resolve(path), []]));
  for (const file of files) {
    const targets = collectImports(file, readText(file)).map((item) => resolveImport(root, file, item, known, compilerOptions)).filter(Boolean);
    graph.set(resolve(file), targets);
  }
  const visiting = new Set(), visited = new Set(), found = new Set();
  const visit = (node, trail) => {
    if (visiting.has(node)) {
      const start = trail.indexOf(node);
      found.add(trail.slice(start).concat(node).map((path) => unix(relative(root, path))).join(' -> '));
      return;
    }
    if (visited.has(node)) return;
    visiting.add(node);
    for (const target of graph.get(node) ?? []) visit(target, [...trail, node]);
    visiting.delete(node); visited.add(node);
  };
  for (const node of graph.keys()) visit(node, []);
  return [...found];
}
