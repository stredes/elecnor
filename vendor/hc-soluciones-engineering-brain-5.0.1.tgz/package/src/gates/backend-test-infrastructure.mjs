import { resolve } from 'node:path';
import { readText, relativeUnix, walkFiles } from '../shared/fs.mjs';

const excluded = new Set(['.git', 'node_modules', 'vendor', 'dist', 'build', 'coverage', '.next']);
const composeName = /(?:^|\/)(?:docker-)?compose[^/]*\.ya?ml$/i;
const testName = /(?:^|[./_-])(?:test|e2e|integration)(?:[./_-]|$)/i;
const credentialFallback = /\b((?:DB|DATABASE|POSTGRES|MYSQL|MARIADB|MONGODB)_(?:PASSWORD|USER|USERNAME|URL))\b[^\n]{0,120}?(?:\?\?|\|\|)\s*(['"`])[^'"`\n]+\2/g;
const containerName = /^\s*container_name\s*:/m;
const fixedShortPort = /^\s*-\s*['"]?(?:[\d.]+:)?(?:\d{1,5}|\$\{[^}\n]+:-\d{1,5}\}):\d{1,5}(?:\/tcp)?['"]?\s*$/m;
const fixedLongPort = /^\s*published\s*:\s*['"]?(?:\d{1,5}|\$\{[^}\n]+:-\d{1,5}\})['"]?\s*$/m;
const durableData = /^\s*-\s*['"]?[^:'"\s][^:'"]*:\/(?:(?:var\/lib\/(?:postgresql\/data|mysql))|data\/db)(?:['"\s]|$)/m;

const isUnder = (path, root) => path === root || path.startsWith(`${root}/`);

function productionFiles(root, manifest, files) {
  const roots = manifest.quality.source_roots.map((path) => resolve(root, path));
  return files.filter((path) => roots.some((sourceRoot) => isUnder(path, sourceRoot)));
}

function credentialErrors(root, manifest, files) {
  const errors = [];
  for (const path of productionFiles(root, manifest, files)) {
    for (const match of readText(path).matchAll(credentialFallback)) {
      errors.push(`${relativeUnix(root, path)}: ${match[1]} has a literal fallback`);
    }
  }
  return errors;
}

function testComposeFiles(root) {
  return walkFiles(root, excluded).filter((path) => {
    const relative = relativeUnix(root, path);
    return composeName.test(relative) && testName.test(relative);
  });
}

function composeErrors(root) {
  const errors = [];
  for (const path of testComposeFiles(root)) {
    const relative = relativeUnix(root, path);
    const content = readText(path);
    if (containerName.test(content)) errors.push(`${relative}: container_name prevents parallel test runs`);
    if (fixedShortPort.test(content) || fixedLongPort.test(content)) {
      errors.push(`${relative}: fixed host port prevents parallel test runs`);
    }
    if (durableData.test(content)) errors.push(`${relative}: durable DB data mount leaks test state`);
  }
  return errors;
}

export function checkBackendTestInfrastructure(root, manifest, files) {
  if (manifest.project.profile !== 'backend-nest') return [];
  return [...credentialErrors(root, manifest, files), ...composeErrors(root)];
}
