import { fromBrain } from '../config/brain-paths.mjs';
import { readJson, readText, physicalLines, relativeUnix } from '../shared/fs.mjs';
import { loadProject } from '../validation/project.mjs';
import { scopedSourceFiles } from './scoped-files.mjs';

export function checkFileLines(projectRoot) {
  const manifest = loadProject(projectRoot);
  const policy = readJson(fromBrain('gates/core/file-policy.json'));
  const { files, missing } = scopedSourceFiles(projectRoot, manifest, policy);
  const errors = [...missing];
  for (const path of files) {
    const lines = physicalLines(readText(path));
    if (lines > policy.max_physical_lines) {
      errors.push(`${relativeUnix(projectRoot, path)}: ${lines} physical lines; maximum is 99`);
    }
  }
  return errors;
}
