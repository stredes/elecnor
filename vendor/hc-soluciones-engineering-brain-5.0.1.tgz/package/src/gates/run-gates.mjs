import { failed, hasFailures } from '../shared/result.mjs';
import { validateAll } from '../validation/all.mjs';
import { checkArchitecture } from './architecture.mjs';
import { checkFileLines } from './file-lines.mjs';
import { checkSecrets } from './secrets.mjs';
import { analyzeTypeScript } from './typescript.mjs';
import { checkNestConventions } from './nest-conventions.mjs';
import { scopedSourceFiles } from './scoped-files.mjs';
import { fromBrain } from '../config/brain-paths.mjs';
import { readJson } from '../shared/fs.mjs';
import { loadProject } from '../validation/project.mjs';
import { loadTask } from '../validation/task.mjs';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { checkVerificationConfig } from '../validation/verification-config.mjs';
import { checkTaskScope } from './task-scope.mjs';
import { checkGitDelivery } from './git-delivery.mjs';
import { checkProfileConventions } from './profile-conventions.mjs';

export async function runGates(projectRoot) {
  const validation = validateAll(projectRoot);
  if (hasFailures(validation)) return validation;
  const manifest = loadProject(projectRoot);
  const taskPath = join(projectRoot, '.hc/task.json');
  const task = existsSync(taskPath) ? loadTask(taskPath) : null;
  const policy = readJson(fromBrain('gates/core/file-policy.json'));
  const { files } = scopedSourceFiles(projectRoot, manifest, policy);
  const typescript = await analyzeTypeScript(projectRoot, manifest);
  const nest = checkNestConventions(projectRoot, manifest, files, task);
  const taskScope = task ? await checkTaskScope(projectRoot, task) : [];
  const gitDelivery = task ? await checkGitDelivery(projectRoot, task) : [];
  return [
    ...validation,
    failed('verification contract', checkVerificationConfig(projectRoot, manifest, task)),
    failed('task scope and authority', taskScope),
    failed('Git delivery workflow', gitDelivery),
    failed('authored source ≤ 99 lines', checkFileLines(projectRoot)),
    failed('architecture boundaries and cycles', checkArchitecture(projectRoot)),
    failed('profile runtime boundaries', checkProfileConventions(projectRoot, manifest, files)),
    failed('TypeScript project diagnostics', [...typescript.errors, ...typescript.cycles.map((cycle) => `dependency cycle: ${cycle}`)]),
    failed('Nest architecture and security', nest.errors, nest.reviews),
    failed('high-confidence secret patterns', await checkSecrets(projectRoot)),
  ];
}
