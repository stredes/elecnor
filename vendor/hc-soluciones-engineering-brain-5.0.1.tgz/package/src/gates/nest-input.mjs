import { relative, resolve } from 'node:path';
import { readText } from '../shared/fs.mjs';
import {
  hasStrictPipeOption, nestBodyTypes, nestClassBody, nestProperties, validationPipeOptions,
} from './nest-source-reader.mjs';

const validatorPattern = /@(Is(?:String|Email|Int|Number|Boolean|Array|Enum|UUID|DateString|Object)|ValidateNested|Array(?:MinSize|MaxSize|NotEmpty|Unique))\b/;

const unix = (value) => value.replaceAll('\\', '/');
const location = (root, path) => unix(relative(root, path));

function propertyErrors(path, type, properties) {
  const errors = [];
  if (!properties.length) return [`${path}: ${type} has no runtime-validated properties`];
  for (const { decorators, name, optional, valueType } of properties) {
    const property = `${path}: ${type}.${name}`;
    if (valueType === 'string' && !/@IsString\b/.test(decorators)) errors.push(`${property} requires @IsString`);
    if (name.toLowerCase().includes('email') && !/@IsEmail\b/.test(decorators)) errors.push(`${property} requires @IsEmail`);
    if (!validatorPattern.test(decorators)) errors.push(`${property} requires a runtime validator`);
    if (valueType === 'string' && !/@MaxLength\s*\(/.test(decorators)) errors.push(`${property} requires @MaxLength`);
    if (valueType === 'string' && optional !== '?' && !/@(?:IsNotEmpty|MinLength)\s*\(/.test(decorators)) {
      errors.push(`${property} requires @IsNotEmpty or @MinLength`);
    }
    if (/(?:\[\]|\bArray\s*<)/.test(valueType) && !/@ArrayMaxSize\s*\(/.test(decorators)) errors.push(`${property} requires @ArrayMaxSize`);
    if (valueType === 'number' && !/@Max\s*\(/.test(decorators)) errors.push(`${property} requires @Max`);
  }
  return errors;
}

function pipeErrors(contents) {
  const joined = contents.join('\n');
  if (!/@Body(?:\(|\s)/.test(joined)) return [];
  const options = validationPipeOptions(contents);
  if (options === null) return ['Nest @Body input requires a global ValidationPipe with explicit options'];
  const errors = [];
  for (const option of ['transform', 'whitelist', 'forbidNonWhitelisted']) {
    if (!hasStrictPipeOption(options, option)) errors.push(`global ValidationPipe requires ${option}: true`);
  }
  return errors;
}

export function validateNestInput(root, manifest, files) {
  const roots = manifest.quality.source_roots.map((path) => resolve(root, path));
  const production = files.filter((path) => roots.some((sourceRoot) => path === sourceRoot || path.startsWith(`${sourceRoot}/`)));
  const sources = production.map((path) => ({ path, content: readText(path) }));
  const types = new Set(sources.flatMap(({ content }) => nestBodyTypes(content)));
  const errors = [...pipeErrors(sources.map(({ content }) => content))];
  for (const type of types) {
    const source = sources.find(({ content }) => nestClassBody(content, type) !== null);
    if (!source) {
      errors.push(`Nest @Body type ${type} must be a runtime DTO class`);
      continue;
    }
    errors.push(...propertyErrors(location(root, source.path), type, nestProperties(nestClassBody(source.content, type))));
  }
  return errors;
}
