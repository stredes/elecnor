import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { readJson, readText, relativeUnix } from '../shared/fs.mjs';
import { compositeCount, openApiComposites } from './openapi-composites.mjs';

const controllerMarker = /@Controller\s*\(/;
const operationMarker = /@(Get|Post|Put|Patch|Delete)\s*\(/;
const typedSuccess = /@Api(?:Ok|Created|Accepted)Response\s*\(\s*\{[\s\S]{0,500}?\btype\s*:|@ApiNoContentResponse\s*\(|@ApiResponse\s*\(\s*\{(?=[\s\S]{0,500}?\bstatus\s*:\s*20\d)(?=[\s\S]{0,500}?\btype\s*:)/;

const count = (content, pattern) => [...content.matchAll(new RegExp(pattern.source, 'g'))].length;

function productionFiles(root, manifest, files) {
  const roots = manifest.quality.source_roots.map((path) => resolve(root, path));
  return files.filter((path) => roots.some((sourceRoot) =>
    path === sourceRoot || path.startsWith(`${sourceRoot}/`)));
}

function hasSwaggerBootstrap(root, files) {
  const packagePath = resolve(root, 'package.json');
  const packageJson = existsSync(packagePath) ? readJson(packagePath) : {};
  const dependencies = { ...packageJson.dependencies, ...packageJson.devDependencies };
  const contents = files.map((path) => readText(path));
  const main = files.find((path) => /(?:^|\/)main\.[cm]?[jt]s$/.test(path));
  return Boolean(dependencies['@nestjs/swagger'])
    && contents.some((content) => /SwaggerModule\.createDocument\s*\(/.test(content))
    && contents.some((content) => /SwaggerModule\.setup\s*\(/.test(content))
    && Boolean(main && /(?:setup|configure|apply)\w*Swagger\s*\(|SwaggerModule\.setup\s*\(/i.test(readText(main)));
}

function usesSwaggerPlugin(root) {
  const path = resolve(root, 'nest-cli.json');
  if (!existsSync(path)) return false;
  try { return JSON.stringify(readJson(path)).includes('@nestjs/swagger'); } catch { return false; }
}

function controllerErrors(root, path, content, composites) {
  if (!controllerMarker.test(content)) return [];
  const location = relativeUnix(root, path);
  const errors = [];
  const operations = count(content, operationMarker);
  if (!/@ApiTags\s*\(/.test(content)) errors.push(`${location}: missing @ApiTags`);
  if (operations > count(content, /@ApiOperation\s*\(/) + compositeCount(content, composites.operations)) {
    errors.push(`${location}: missing @ApiOperation`);
  }
  if (operations > count(content, typedSuccess) + compositeCount(content, composites.successes)) {
    errors.push(`${location}: missing typed OpenAPI success response`);
  }
  return errors;
}

function dtoErrors(root, path, content, inferred) {
  if (!/from\s+['"]class-validator['"]/.test(content)) return [];
  const name = content.match(/export\s+class\s+(\w+)/)?.[1] ?? 'request DTO';
  if (inferred) return [];
  const propertyPattern = /\b[A-Za-z_$][\w$]*[!?]?\s*:[^;{}\n]+;/g;
  const sanitized = content.replace(/'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|`(?:\\.|[^`\\])*`/g, '');
  const properties = [...sanitized.matchAll(propertyPattern)].length;
  const documented = count(content, /@ApiProperty(?:Optional)?\s*\(/);
  if (!properties || documented >= properties) return [];
  if (documented) {
    return [`${relativeUnix(root, path)}: ${name}: OpenAPI metadata covers ${documented}/${properties} properties`];
  }
  return [`${relativeUnix(root, path)}: ${name}: missing OpenAPI property metadata`];
}

export function checkBackendOpenApi(root, manifest, files) {
  if (manifest.project.profile !== 'backend-nest') return [];
  const production = productionFiles(root, manifest, files);
  const controllers = production.filter((path) => controllerMarker.test(readText(path)));
  if (!controllers.length) return [];
  const errors = [];
  if (!hasSwaggerBootstrap(root, production)) {
    errors.push('backend HTTP must configure Swagger/OpenAPI and invoke it from main');
  }
  const composites = openApiComposites(production);
  for (const path of controllers) errors.push(...controllerErrors(root, path, readText(path), composites));
  const inferred = usesSwaggerPlugin(root);
  for (const path of production) errors.push(...dtoErrors(root, path, readText(path), inferred));
  return errors;
}
