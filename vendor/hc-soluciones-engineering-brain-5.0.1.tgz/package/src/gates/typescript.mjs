import { resolve } from 'node:path';
import { fromBrain } from '../config/brain-paths.mjs';
import { readJson } from '../shared/fs.mjs';
import { scopedSourceFiles } from './scoped-files.mjs';
import { projectDiagnostics } from './typescript-diagnostics.mjs';
import { typescriptCycles } from './typescript-cycles.mjs';
import { checkTypeScriptPolicy } from './typescript-policy.mjs';

export async function analyzeTypeScript(root, manifest) {
  if (manifest.project.language !== 'typescript') return { errors: [], cycles: [] };
  const policy = readJson(fromBrain('gates/core/file-policy.json'));
  const scoped = scopedSourceFiles(root, manifest, policy);
  const files = scoped.files.filter((path) => /\.tsx?$/.test(path));
  const config = readJson(resolve(root, manifest.quality.tsconfig));
  return {
    errors: [
      ...scoped.missing,
      ...checkTypeScriptPolicy(root, manifest.quality.tsconfig),
      ...await projectDiagnostics(root, manifest.quality.tsconfig, files),
    ],
    cycles: typescriptCycles(root, files, config.compilerOptions),
  };
}
