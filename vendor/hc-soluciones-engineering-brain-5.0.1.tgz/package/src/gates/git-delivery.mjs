import { runDeclaredCommand } from '../verification/command-runner.mjs';

const commitPattern = /^\[(?:FEATURE|FIX|REFACTOR|TEST|DOCS|CONFIG|CI\/CD|CHORE)\]: [A-Z][^\n]+$/;
const baseName = (task) => task.task.type === 'hotfix' ? 'main' : 'Development';

export const isValidCommitMessage = (message) => commitPattern.test(message);

export function validateGitDelivery(task, state) {
  const errors = [];
  const expectedBranch = task.task.id;
  const expectedBase = baseName(task);
  if (state.branch !== expectedBranch) errors.push(`delivery branch must be ${expectedBranch}; found ${state.branch}`);
  if (!state.baseExists) errors.push(`base branch ${expectedBase} is missing`);
  else if (!state.baseIsAncestor) errors.push(`base branch ${expectedBase} is not an ancestor of HEAD`);
  for (const message of state.commits) {
    if (!isValidCommitMessage(message)) errors.push(`invalid HC commit message: ${message}`);
  }
  return errors;
}

async function runGit(root, argv, execute) {
  return execute(root, { argv: ['git', ...argv], timeout_seconds: 30 });
}

async function findBase(root, name, execute) {
  for (const ref of [`refs/heads/${name}`, `refs/remotes/origin/${name}`]) {
    const result = await runGit(root, ['show-ref', '--verify', '--quiet', ref], execute);
    if (result.exitCode === 0) return ref;
  }
  return null;
}

export async function checkGitDelivery(root, task, execute = runDeclaredCommand) {
  const branchResult = await runGit(root, ['branch', '--show-current'], execute);
  const base = await findBase(root, baseName(task), execute);
  let ancestor = { exitCode: 1 };
  let log = { exitCode: 0, output: '' };
  if (base) {
    [ancestor, log] = await Promise.all([
      runGit(root, ['merge-base', '--is-ancestor', base, 'HEAD'], execute),
      runGit(root, ['log', '--format=%s', `${base}..HEAD`], execute),
    ]);
  }
  return validateGitDelivery(task, {
    branch: branchResult.output.trim(),
    baseExists: Boolean(base),
    baseIsAncestor: ancestor.exitCode === 0,
    commits: log.exitCode === 0 ? log.output.trim().split('\n').filter(Boolean) : [],
  });
}
