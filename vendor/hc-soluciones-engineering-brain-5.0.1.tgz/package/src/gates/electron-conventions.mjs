import { resolve } from 'node:path';
import { readText, relativeUnix } from '../shared/fs.mjs';

function productionFiles(root, manifest, files) {
  const roots = manifest.quality.source_roots.map((path) => resolve(root, path));
  return files.filter((path) => roots.some((sourceRoot) =>
    path === sourceRoot || path.startsWith(`${sourceRoot}/`)));
}

function windowErrors(root, path, content) {
  if (!/\bnew\s+BrowserWindow\s*\(/.test(content)) return [];
  const location = relativeUnix(root, path);
  const errors = [];
  if (!/\bcontextIsolation\s*:\s*true\b/.test(content)) {
    errors.push(`${location}: Electron BrowserWindow must enable contextIsolation`);
  }
  if (!/\bnodeIntegration\s*:\s*false\b/.test(content)) {
    errors.push(`${location}: Electron BrowserWindow must disable nodeIntegration`);
  }
  if (!/\bsandbox\s*:\s*true\b/.test(content)) {
    errors.push(`${location}: Electron BrowserWindow must enable sandbox`);
  }
  if (!/\bpreload\s*:/.test(content)) {
    errors.push(`${location}: Electron BrowserWindow must configure preload`);
  }
  if (/\b(?:webSecurity\s*:\s*false|allowRunningInsecureContent\s*:\s*true)\b/.test(content)) {
    errors.push(`${location}: Electron cannot weaken web security`);
  }
  return errors;
}

function preloadErrors(root, path, content) {
  if (!/(?:^|\/)preload(?:\/|\.)/.test(path)) return [];
  const location = relativeUnix(root, path);
  const errors = [];
  if (!/contextBridge\.exposeInMainWorld\s*\(/.test(content)) {
    errors.push(`${location}: preload must expose a narrow contextBridge API`);
  }
  if (/exposeInMainWorld\s*\([\s\S]{0,800}(?:\{\s*ipcRenderer\s*[,}]|:\s*ipcRenderer(?:\.\w+)?\b)/.test(content)) {
    errors.push(`${location}: preload cannot expose ipcRenderer directly`);
  }
  return errors;
}

function ipcErrors(root, path, content) {
  const errors = [];
  for (const match of content.matchAll(/\bipc(?:Main|Renderer)\.(?:handle|on|once|send|sendSync|invoke)\s*\(\s*([^,\n)]+)/g)) {
    const channel = match[1].trim();
    if (/^['"`]/.test(channel) || /^[A-Z][A-Z0-9_.]*$/.test(channel)) continue;
    errors.push(`${relativeUnix(root, path)}: IPC channel must be a literal or allowlisted constant`);
  }
  return errors;
}

export function checkElectronConventions(root, manifest, files) {
  if (manifest.project.profile !== 'desktop-electron') return [];
  const production = productionFiles(root, manifest, files);
  const errors = [];
  for (const path of production) {
    const content = readText(path);
    errors.push(...windowErrors(root, path, content));
    errors.push(...preloadErrors(root, path, content));
    errors.push(...ipcErrors(root, path, content));
  }
  if (!production.some((path) => /(?:^|\/)preload(?:\/|\.)/.test(path))) {
    errors.push('desktop-electron requires an explicit preload boundary');
  }
  if (production.some((path) => /\bnew\s+BrowserWindow\s*\(/.test(readText(path)))
    && !production.some((path) => /setWindowOpenHandler|will-navigate/.test(readText(path)))) {
    errors.push('desktop-electron must restrict new windows and external navigation');
  }
  return errors;
}
