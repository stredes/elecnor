import { existsSync } from 'node:fs';
import { dirname, extname, resolve } from 'node:path';
import { collectImports } from './imports.mjs';
import { readText, relativeUnix } from '../shared/fs.mjs';

const extensions = ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs'];

function resolveLocal(from, specifier, known) {
  if (!specifier.startsWith('.')) return null;
  const base = resolve(dirname(from), specifier);
  const candidates = extname(base)
    ? [base]
    : [...extensions.map((extension) => `${base}${extension}`), ...extensions.map((extension) => resolve(base, `index${extension}`))];
  return candidates.find((path) => existsSync(path) && known.has(path)) ?? null;
}

export function findCycles(root, files) {
  const jsFiles = files.filter((path) => extensions.includes(extname(path)));
  const known = new Set(jsFiles.map((path) => resolve(path)));
  const graph = new Map(jsFiles.map((path) => [resolve(path), []]));
  for (const file of jsFiles) {
    const imports = collectImports(file, readText(file));
    graph.set(resolve(file), imports.map((item) => resolveLocal(file, item, known)).filter(Boolean));
  }
  const visiting = new Set();
  const visited = new Set();
  const cycles = new Set();
  const visit = (node, trail) => {
    if (visiting.has(node)) {
      const start = trail.indexOf(node);
      cycles.add(trail.slice(start).concat(node).map((path) => relativeUnix(root, path)).join(' -> '));
      return;
    }
    if (visited.has(node)) return;
    visiting.add(node);
    for (const target of graph.get(node) ?? []) visit(target, [...trail, node]);
    visiting.delete(node);
    visited.add(node);
  };
  for (const node of graph.keys()) visit(node, []);
  return [...cycles];
}
