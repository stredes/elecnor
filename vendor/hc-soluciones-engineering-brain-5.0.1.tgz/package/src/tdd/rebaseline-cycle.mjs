import { findTestTag } from '../trace/trace-tags.mjs';
import { deliveryPaths } from '../validation/delivery.mjs';
import { loadProject } from '../validation/project.mjs';
import { loadTask } from '../validation/task.mjs';
import { runDeclaredCommand } from '../verification/command-runner.mjs';
import { effectiveRefactor, finalSnapshot } from './evidence-state.mjs';
import { gitSnapshot } from './git-snapshot.mjs';
import { productionDigest, testSuiteDigest } from './snapshots.mjs';
import { loadEvidence, phaseRecord, writeEvidence } from './tdd-document.mjs';
import { appendEvent } from './tdd-journal.mjs';
import { blocked, observed } from './tdd-outcome.mjs';
import { recordFailure } from './tdd-recorder.mjs';

export async function rebaselineTddCycle(
  root, testId, reason, execute = runDeclaredCommand, observeGit = gitSnapshot,
) {
  if (!reason?.trim()) {
    return blocked('REASON_REQUIRED', 'rebaseline requires --reason', 'Explain the maintenance change');
  }
  const manifest = loadProject(root);
  const task = loadTask(`${root}/.hc/task.json`);
  const { evidencePath } = deliveryPaths(root, task);
  const evidence = loadEvidence(evidencePath, task.task.id);
  let git;
  try { git = await observeGit(root); } catch (error) {
    return blocked('GIT_UNAVAILABLE', `Git metadata unavailable: ${error.message}`, 'Restore readable Git metadata');
  }
  const context = { testId, git };
  if (git.branch !== task.task.id) {
    const message = `TDD must run on branch ${task.task.id}; current branch is ${git.branch}`;
    return blocked('WRONG_BRANCH', message, `Switch to ${task.task.id}`);
  }
  const cycle = evidence.cycles.find((item) => item.test_id === testId);
  if (!cycle?.refactor || evidence.cycles.at(-1) !== cycle) {
    const outcome = blocked('LATEST_REFACTOR_REQUIRED', `${testId} is not the latest completed cycle`, 'Select the latest completed TEST');
    return recordFailure(evidencePath, evidence, outcome, context);
  }
  const tag = findTestTag(root, manifest, task.task.id, testId);
  if (tag.digest !== cycle.refactor.test_digest) {
    const outcome = blocked('TEST_CHANGED_AFTER_REFACTOR', `${testId} changed after REFACTOR`, 'Restore the original test');
    return recordFailure(evidencePath, evidence, outcome, context);
  }
  const sourceDigest = productionDigest(root, manifest);
  const baseline = effectiveRefactor(cycle);
  if (sourceDigest === baseline.source_digest) {
    const outcome = blocked('NO_PRODUCTION_CHANGE', `${testId} has no production change`, 'Inspect the production diff');
    return recordFailure(evidencePath, evidence, outcome, context);
  }
  const command = manifest.verification.commands[baseline.check];
  const result = await execute(root, command, baseline.args);
  if (result.exitCode !== 0) {
    const outcome = observed(false, 'REBASELINE_COMMAND_FAILED', [`${testId} rebaseline command failed`], 'Restore the green suite');
    return recordFailure(evidencePath, evidence, outcome, context);
  }
  const observation = phaseRecord(
    baseline.check, baseline.args, result, sourceDigest, tag.digest, git,
  );
  cycle.rebaselines ??= [];
  cycle.rebaselines.push(observation);
  evidence.final = finalSnapshot(sourceDigest, testSuiteDigest(root, manifest), git);
  appendEvent(evidence, {
    type: 'REBASELINED', testId, reason: reason.trim(), executed: true,
    code: 'REBASELINED', git, observation,
  });
  writeEvidence(evidencePath, evidence);
  return observed(true, 'REBASELINED', [], 'Start the next RED');
}
