export function blocked(code, message, nextAction) {
  return {
    ok: false,
    executed: false,
    code,
    errors: [message],
    next_action: nextAction,
  };
}

export function observed(ok, code, errors = [], nextAction = null) {
  return { ok, executed: true, code, errors, next_action: nextAction };
}

export function transitioned(code, nextAction) {
  return { ok: true, executed: false, code, errors: [], next_action: nextAction };
}

export function blockedErrors(code, errors, nextAction) {
  return { ok: false, executed: false, code, errors, next_action: nextAction };
}
