import { runDeclaredCommand } from '../verification/command-runner.mjs';
import { gitSnapshot } from './git-snapshot.mjs';
import { finalSnapshot } from './evidence-state.mjs';
import { productionDigest, testSuiteDigest } from './snapshots.mjs';
import { observed, blocked } from './tdd-outcome.mjs';
import { tddPreflight } from './tdd-preflight.mjs';
import { initialGitBaseline, phaseRecord } from './tdd-document.mjs';
import { recordFailure, recordPhase } from './tdd-recorder.mjs';
import { checkTaskScope } from '../gates/task-scope.mjs';
import { scopePreflight } from './tdd-scope-preflight.mjs';
import { prepareTdd } from './tdd-setup.mjs';
import { resolvePlannedInvocation } from './planned-tdd.mjs';
import { readHeadCommitSubject, tddCommitPreflight } from './tdd-commit-preflight.mjs';

export async function runTddOutcome(
  root, phase, testId, check, extraArgs, expectedReason, execute = runDeclaredCommand,
  observeGit = gitSnapshot, inspectScope = checkTaskScope, inspectCommit = readHeadCommitSubject,
) {
  const setup = prepareTdd(root, testId, check);
  if (setup.outcome) return setup.outcome;
  const { manifest, task, evidencePath, acIds, tag, command, evidence, plan } = setup;
  let cycle = evidence.cycles.find((item) => item.test_id === testId);
  const sourceDigest = productionDigest(root, manifest);
  const suiteDigest = testSuiteDigest(root, manifest);
  let git;
  try { git = await observeGit(root); } catch (error) {
    return blocked('GIT_UNAVAILABLE', `Git metadata unavailable: ${error.message}`, 'Restore readable Git metadata');
  }
  if (git.branch !== task.task.id) {
    return blocked(
      'WRONG_BRANCH', `TDD must run on branch ${task.task.id}; current branch is ${git.branch}`,
      `Switch to ${task.task.id}`,
    );
  }
  const preflight = tddPreflight({
    phase, testId, cycle, evidence, sourceDigest, tagDigest: tag.digest,
    check, args: extraArgs, expectedReason, plan,
  });
  const eventContext = { testId, git };
  if (preflight) return recordFailure(evidencePath, evidence, preflight, eventContext);
  const commit = await tddCommitPreflight(
    root, { phase, evidence, git, manifest }, inspectCommit,
  );
  if (commit) return recordFailure(evidencePath, evidence, commit, eventContext);
  if (phase === 'refactor') {
    const scope = await scopePreflight(root, task, inspectScope);
    if (scope) return recordFailure(evidencePath, evidence, scope, eventContext);
  }
  const result = await execute(root, command, extraArgs);
  if (phase === 'red') {
    if (result.exitCode === 0) {
      return recordFailure(evidencePath, evidence, observed(
        false, 'BORN_GREEN', [`${testId} was born green`],
        'Inspect the test assertion and existing behaviour',
      ), eventContext);
    }
    if (!result.output.includes(expectedReason)) {
      return recordFailure(evidencePath, evidence, observed(
        false, 'RED_REASON_MISMATCH', ['RED output does not contain --expect text'],
        'Correct the expected RED reason',
      ), eventContext);
    }
    evidence.git_baseline ??= initialGitBaseline(git);
    delete evidence.final;
    cycle = { test_id: testId, ac_ids: acIds, red: phaseRecord(check, extraArgs, result, sourceDigest, tag.digest, git, expectedReason) };
    evidence.cycles.push(cycle);
  } else {
    if (result.exitCode !== 0) {
      const upperPhase = phase.toUpperCase();
      return recordFailure(evidencePath, evidence, observed(
        false, `${upperPhase}_COMMAND_FAILED`, [`${testId} ${upperPhase} command failed`],
        `Fix ${testId} before recording ${upperPhase}`,
      ), eventContext);
    }
    cycle[phase] = phaseRecord(check, extraArgs, result, sourceDigest, tag.digest, git);
    if (phase === 'refactor') evidence.final = finalSnapshot(sourceDigest, suiteDigest, git);
  }
  recordPhase(evidencePath, evidence, phase, eventContext, cycle[phase]);
  return observed(true, `${phase.toUpperCase()}_RECORDED`, [], phase === 'red' ? 'Implement the minimum GREEN' : null);
}

export async function runTdd(...args) {
  const [root, phase, testId, check] = args;
  if (check) return (await runTddOutcome(...args)).errors;
  return (await runPlannedTddOutcome(root, phase, testId)).errors;
}

export async function runPlannedTddOutcome(
  root, phase, testId, execute = runDeclaredCommand,
  observeGit = gitSnapshot, inspectScope = checkTaskScope, inspectCommit = readHeadCommitSubject,
) {
  const invocation = resolvePlannedInvocation(root, phase, testId);
  if (invocation.outcome) return invocation.outcome;
  return runTddOutcome(
    root, phase, testId, invocation.check, invocation.args, invocation.expectedReason,
    execute, observeGit, inspectScope, inspectCommit,
  );
}
