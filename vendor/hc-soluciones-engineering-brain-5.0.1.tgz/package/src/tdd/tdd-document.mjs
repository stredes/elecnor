import { existsSync, mkdirSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { digestText } from '../shared/digest.mjs';
import { readJson } from '../shared/fs.mjs';
import { ensureJournal } from './tdd-journal.mjs';

export function writeEvidence(path, document) {
  mkdirSync(dirname(path), { recursive: true });
  const temporary = `${path}.tmp`;
  writeFileSync(temporary, `${JSON.stringify(document, null, 2)}\n`);
  renameSync(temporary, path);
}

export function loadEvidence(path, taskId) {
  const document = existsSync(path)
    ? readJson(path)
    : { schema_version: '2.0', task_id: taskId, cycles: [], reviews: [], events: [] };
  const evidence = ensureJournal(document);
  if (!evidence.git_baseline && evidence.cycles[0]?.red?.git) {
    evidence.git_baseline = initialGitBaseline(evidence.cycles[0].red.git);
  }
  return evidence;
}

export function testMapping(story, selectedAc, testId) {
  return story.story.acceptance_criteria
    .filter((ac) => selectedAc.includes(ac.id) && ac.test_ids.includes(testId))
    .map((ac) => ac.id);
}

export function initialGitBaseline(git) {
  return { kind: 'UNMANAGED_INITIAL', head: git.head, branch: git.branch };
}

export function phaseRecord(check, args, result, sourceDigest, testDigest, git, expectedReason) {
  const record = {
    check, args, exit_code: result.exitCode, output_digest: digestText(result.output),
    source_digest: sourceDigest, test_digest: testDigest, recorded_at: new Date().toISOString(),
    git: { head: git.head, branch: git.branch, dirty: git.dirty },
  };
  if (expectedReason) record.expected_reason = expectedReason;
  return record;
}
