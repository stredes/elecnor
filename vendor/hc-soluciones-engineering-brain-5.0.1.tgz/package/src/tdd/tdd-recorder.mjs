import { appendEvent, recordedEventType } from './tdd-journal.mjs';
import { writeEvidence } from './tdd-document.mjs';

export function recordFailure(path, evidence, outcome, context) {
  appendEvent(evidence, {
    type: 'ATTEMPT_FAILED', testId: context.testId, reason: outcome.errors.join('; '),
    executed: outcome.executed, code: outcome.code, git: context.git,
  });
  writeEvidence(path, evidence);
  return outcome;
}

export function recordPhase(path, evidence, phase, context, observation) {
  appendEvent(evidence, {
    type: recordedEventType(phase), testId: context.testId,
    reason: observation.expected_reason ?? `${phase.toUpperCase()} command passed`,
    executed: true, code: `${phase.toUpperCase()}_RECORDED`, git: context.git,
    observation,
  });
  writeEvidence(path, evidence);
}
