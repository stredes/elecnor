import { readJson } from '../shared/fs.mjs';
import { findTestTag } from '../trace/trace-tags.mjs';
import { deliveryPaths } from '../validation/delivery.mjs';
import { loadProject } from '../validation/project.mjs';
import { loadTask } from '../validation/task.mjs';
import { blocked } from './tdd-outcome.mjs';
import { loadEvidence, testMapping } from './tdd-document.mjs';

export function prepareTdd(root, testId, check) {
  const manifest = loadProject(root);
  const task = loadTask(`${root}/.hc/task.json`);
  const { storyPath, evidencePath } = deliveryPaths(root, task);
  const story = readJson(storyPath);
  const acIds = testMapping(story, task.task.acceptance_criteria, testId);
  if (!acIds.length) {
    return { outcome: blocked(
      'TEST_NOT_MAPPED', `${testId} is not mapped by the selected acceptance criteria`,
      'Select a mapped TEST',
    ) };
  }
  const tag = findTestTag(root, manifest, task.task.id, testId);
  if ([...acIds].sort().join() !== [...tag.acIds].sort().join()) {
    return { outcome: blocked(
      'TEST_TAG_MISMATCH', `${testId} tag does not match its story mapping`,
      'Correct the test trace tag',
    ) };
  }
  const command = manifest.verification.commands[check];
  if (!command) {
    return { outcome: blocked(
      'CHECK_NOT_DECLARED', `verification command ${check} is not declared`,
      'Select a declared check',
    ) };
  }
  const evidence = loadEvidence(evidencePath, task.task.id);
  const plan = task.task.test_plan?.find((item) => item.test_id === testId);
  return { manifest, task, evidencePath, acIds, tag, command, evidence, plan };
}
