import { deliveryPaths } from '../validation/delivery.mjs';
import { loadTask } from '../validation/task.mjs';
import { gitSnapshot } from './git-snapshot.mjs';
import { appendEvent } from './tdd-journal.mjs';
import { loadEvidence, writeEvidence } from './tdd-document.mjs';
import { blocked, transitioned } from './tdd-outcome.mjs';

export { rebaselineTddCycle } from './rebaseline-cycle.mjs';

export async function restartTddCycle(root, testId, reason, observeGit = gitSnapshot) {
  if (!reason?.trim()) {
    return blocked('REASON_REQUIRED', 'restart requires --reason', 'Explain why the attempt is invalid');
  }
  const task = loadTask(`${root}/.hc/task.json`);
  const { evidencePath } = deliveryPaths(root, task);
  const evidence = loadEvidence(evidencePath, task.task.id);
  let git;
  try { git = await observeGit(root); } catch (error) {
    return blocked('GIT_UNAVAILABLE', `Git metadata unavailable: ${error.message}`, 'Restore readable Git metadata');
  }
  if (git.branch !== task.task.id) {
    return blocked(
      'WRONG_BRANCH', `TDD must run on branch ${task.task.id}; current branch is ${git.branch}`,
      `Switch to ${task.task.id}`,
    );
  }
  const index = evidence.cycles.findIndex((cycle) => cycle.test_id === testId);
  if (index < 0) return blocked('CYCLE_NOT_FOUND', `${testId} has no attempt`, 'Record RED first');
  if (evidence.cycles[index].refactor) {
    return blocked('CYCLE_COMPLETE', `${testId} is complete`, 'Use rebaseline for a completed cycle');
  }
  appendEvent(evidence, {
    type: 'CYCLE_RESTARTED', testId, reason: reason.trim(), executed: false, git,
  });
  evidence.cycles.splice(index, 1);
  writeEvidence(evidencePath, evidence);
  return transitioned('CYCLE_RESTARTED', 'Write the corrected test and record RED');
}
