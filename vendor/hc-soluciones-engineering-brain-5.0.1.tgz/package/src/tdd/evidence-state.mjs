export const effectiveRefactor = (cycle) => cycle.rebaselines?.at(-1) ?? cycle.refactor;

export function beginCycleErrors(evidence, sourceDigest) {
  const previous = evidence.cycles.at(-1);
  if (!previous) return [];
  if (!previous.refactor) return [`${previous.test_id} must record REFACTOR before the next RED`];
  if (effectiveRefactor(previous).source_digest !== sourceDigest) {
    return ['production changed before next RED; record the change through REFACTOR'];
  }
  return [];
}

export function finalSnapshot(sourceDigest, testSuiteDigest, git) {
  return {
    source_digest: sourceDigest,
    test_suite_digest: testSuiteDigest,
    recorded_at: new Date().toISOString(),
    git: { head: git.head, branch: git.branch, dirty: git.dirty },
  };
}
