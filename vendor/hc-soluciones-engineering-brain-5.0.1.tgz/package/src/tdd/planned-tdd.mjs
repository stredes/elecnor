import { loadTask } from '../validation/task.mjs';
import { blocked } from './tdd-outcome.mjs';

export function resolvePlannedInvocation(root, phase, testId) {
  const task = loadTask(`${root}/.hc/task.json`);
  const plan = task.task.test_plan?.find((item) => item.test_id === testId);
  if (!plan) {
    return { outcome: blocked(
      'TEST_PLAN_REQUIRED', `${testId} has no executable plan`,
      'Declare test_plan or provide --check and --expect explicitly',
    ) };
  }
  const command = phase === 'refactor' ? plan.regression : plan;
  return {
    check: command.check,
    args: command.args,
    expectedReason: phase === 'red' ? plan.expected_failure : undefined,
  };
}
