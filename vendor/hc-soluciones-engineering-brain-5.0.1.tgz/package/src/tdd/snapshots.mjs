import { fromBrain } from '../config/brain-paths.mjs';
import { scopedFilesForRoots } from '../gates/scoped-files.mjs';
import { digestFiles } from '../shared/digest.mjs';
import { readJson } from '../shared/fs.mjs';

function scopedDigest(root, roots, generatedRoots) {
  const policy = readJson(fromBrain('gates/core/file-policy.json'));
  const scoped = scopedFilesForRoots(root, roots, generatedRoots, policy);
  if (scoped.missing.length) throw new Error(scoped.missing.join('; '));
  return digestFiles(root, scoped.files);
}

export const productionDigest = (root, manifest) =>
  scopedDigest(root, manifest.quality.source_roots, manifest.quality.generated_roots);

export const testSuiteDigest = (root, manifest) =>
  scopedDigest(root, manifest.quality.test_roots, []);
