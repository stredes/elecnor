import { existsSync } from 'node:fs';
import { readJson } from '../shared/fs.mjs';
import { findTestTag } from '../trace/trace-tags.mjs';
import { deliveryPaths } from '../validation/delivery.mjs';
import { loadProject } from '../validation/project.mjs';
import { loadTask } from '../validation/task.mjs';
import { effectiveRefactor } from './evidence-state.mjs';
import { productionDigest } from './snapshots.mjs';

function selectedTests(story, task) {
  const selected = new Set(task.task.acceptance_criteria);
  return [...new Set(story.story.acceptance_criteria
    .filter((criterion) => selected.has(criterion.id))
    .flatMap((criterion) => criterion.test_ids))];
}

function nextPhase(cycle) {
  if (!cycle?.red) return 'RED';
  if (!cycle.green) return 'GREEN';
  if (!cycle.refactor) return 'REFACTOR';
  return 'DONE';
}

function digestBlocker(root, manifest, taskId, testId, cycle, phase, sourceDigest) {
  let tag;
  try { tag = findTestTag(root, manifest, taskId, testId); } catch {
    return 'TEST_NOT_FOUND';
  }
  if (phase === 'GREEN') {
    if (tag.digest !== cycle.red.test_digest) return 'TEST_CHANGED_AFTER_RED';
    if (sourceDigest === cycle.red.source_digest) return 'NO_PRODUCTION_CHANGE';
  }
  if (phase === 'REFACTOR' && tag.digest !== cycle.green.test_digest) {
    return 'TEST_CHANGED_DURING_REFACTOR';
  }
  return null;
}

function redBlocker(cycles, sourceDigest) {
  const previous = cycles.at(-1);
  if (!previous) return null;
  if (!previous.refactor) return 'PREVIOUS_REFACTOR_REQUIRED';
  return effectiveRefactor(previous).source_digest === sourceDigest
    ? null
    : 'SOURCE_CHANGED_AFTER_REFACTOR';
}

export function tddStatus(root, requestedTestId) {
  const manifest = loadProject(root);
  const task = loadTask(`${root}/.hc/task.json`);
  const { storyPath, evidencePath } = deliveryPaths(root, task);
  const story = readJson(storyPath);
  const evidence = existsSync(evidencePath)
    ? readJson(evidencePath)
    : { cycles: [] };
  const tests = selectedTests(story, task);
  const testId = requestedTestId ?? tests.find((id) => {
    const cycle = evidence.cycles.find((item) => item.test_id === id);
    return nextPhase(cycle) !== 'DONE';
  });
  if (!testId) return { test_id: null, next_phase: 'DONE', ready: true, blocker: null };
  const cycle = evidence.cycles.find((item) => item.test_id === testId);
  const phase = nextPhase(cycle);
  const sourceDigest = productionDigest(root, manifest);
  let blocker = phase === 'RED'
    ? redBlocker(evidence.cycles, sourceDigest)
    : digestBlocker(root, manifest, task.task.id, testId, cycle, phase, sourceDigest);
  if (phase === 'RED') {
    try { findTestTag(root, manifest, task.task.id, testId); } catch { blocker = 'TEST_NOT_FOUND'; }
  }
  return { test_id: testId, next_phase: phase, ready: blocker === null, blocker };
}

export function formatTddStatus(status) {
  return `${status.test_id ?? '-'} | next=${status.next_phase} | ready=${status.ready}`
    + ` | blocker=${status.blocker ?? 'none'}`;
}
