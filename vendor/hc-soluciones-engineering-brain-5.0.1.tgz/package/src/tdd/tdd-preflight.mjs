import { effectiveRefactor } from './evidence-state.mjs';
import { blocked } from './tdd-outcome.mjs';

const sameArgs = (left, right) => JSON.stringify(left) === JSON.stringify(right);

function expectedInvocation(phase, cycle, plan) {
  if (!plan) return cycle?.red;
  return phase === 'refactor' ? plan.regression : plan;
}

function previousCycleBlock(evidence, sourceDigest) {
  const previous = evidence.cycles.at(-1);
  if (!previous) return null;
  if (!previous.refactor) {
    return blocked(
      'PREVIOUS_REFACTOR_REQUIRED', `${previous.test_id} must record REFACTOR before the next RED`,
      'Complete the previous cycle',
    );
  }
  if (effectiveRefactor(previous).source_digest !== sourceDigest) {
    return blocked(
      'SOURCE_CHANGED_AFTER_REFACTOR', 'production changed before next RED',
      `Run hc tdd rebaseline ${previous.test_id} --reason "..."`,
    );
  }
  return null;
}

export function tddPreflight(input) {
  const {
    phase, testId, cycle, evidence, sourceDigest, tagDigest,
    check, args, expectedReason, plan,
  } = input;
  const expected = expectedInvocation(phase, cycle, plan);
  if (expected && (expected.check !== check || !sameArgs(expected.args, args))) {
    return blocked('PLANNED_COMMAND_MISMATCH', `${testId} does not match its planned command`, 'Use hc tdd with only the TEST id');
  }
  if (phase === 'red') {
    if (cycle?.red) {
      return blocked('RED_ALREADY_RECORDED', `${testId} already has RED evidence`, 'Continue with GREEN');
    }
    const previous = previousCycleBlock(evidence, sourceDigest);
    if (previous) return previous;
    if (!expectedReason) {
      return blocked('RED_EXPECTATION_REQUIRED', 'RED requires an expected failure', 'Provide --expect');
    }
    if (plan && expectedReason !== plan.expected_failure) {
      return blocked('PLANNED_RED_MISMATCH', `${testId} does not match its planned RED reason`, 'Use the planned expected failure');
    }
    return null;
  }
  if (!cycle?.red) {
    return blocked('RED_REQUIRED', `${testId} has no RED evidence`, 'Record RED first');
  }
  if (phase === 'green' && cycle.green) {
    return blocked('GREEN_ALREADY_RECORDED', `${testId} already has GREEN evidence`, 'Continue with REFACTOR');
  }
  if (phase === 'refactor' && !cycle.green) {
    return blocked('GREEN_REQUIRED', `${testId} has no GREEN evidence`, 'Record GREEN first');
  }
  if (phase === 'refactor' && cycle.refactor) {
    return blocked('REFACTOR_ALREADY_RECORDED', `${testId} already has REFACTOR evidence`, 'Start the next RED or use rebaseline');
  }
  if (!plan && (cycle.red.check !== check || !sameArgs(cycle.red.args, args))) {
    return blocked('COMMAND_MISMATCH', `${testId} must use the RED command and args`, 'Reuse the RED check and args');
  }
  if (phase === 'green' && cycle.red.test_digest !== tagDigest) {
    return blocked('TEST_CHANGED_AFTER_RED', `${testId} changed between RED and GREEN`, 'Restore the RED test');
  }
  if (phase === 'refactor' && cycle.green.test_digest !== tagDigest) {
    return blocked('TEST_CHANGED_DURING_REFACTOR', `${testId} changed during REFACTOR`, 'Restore the GREEN test');
  }
  if (phase === 'green' && cycle.red.source_digest === sourceDigest) {
    return blocked('NO_PRODUCTION_CHANGE', `${testId} has no production change`, 'Verify the edit result and inspect the diff');
  }
  return null;
}
