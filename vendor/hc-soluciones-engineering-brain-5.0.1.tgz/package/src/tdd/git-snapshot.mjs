import { runDeclaredCommand } from '../verification/command-runner.mjs';

function changedPath(line) {
  if (line.startsWith('? ')) return line.slice(2);
  const fields = line.split(' ');
  const start = line.startsWith('1 ') ? 8 : line.startsWith('2 ') ? 9 : 10;
  return fields.slice(start).join(' ').split('\t')[0];
}

export async function gitSnapshot(root, execute = runDeclaredCommand) {
  const command = { argv: ['git', 'status', '--porcelain=v2', '--branch'], timeout_seconds: 30 };
  const result = await execute(root, command);
  if (result.exitCode !== 0) throw new Error('project is not a readable Git worktree');
  const lines = result.output.trim().split('\n');
  const head = lines.find((line) => line.startsWith('# branch.oid '))?.slice(13);
  const branch = lines.find((line) => line.startsWith('# branch.head '))?.slice(14);
  if (!head || head === '(initial)' || !branch) throw new Error('Git requires an initial commit and branch');
  const changed = lines.filter((line) => line && !line.startsWith('# '));
  return {
    head, branch, dirty: changed.length > 0,
    changed_files: [...new Set(changed.map(changedPath))].filter(Boolean).sort(),
  };
}
