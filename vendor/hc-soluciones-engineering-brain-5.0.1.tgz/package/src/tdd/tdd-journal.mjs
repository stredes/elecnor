import { digestText } from '../shared/digest.mjs';

const phaseTypes = {
  red: 'RED_RECORDED',
  green: 'GREEN_RECORDED',
  refactor: 'REFACTOR_RECORDED',
};

const cleanGit = (git) => ({ head: git.head, branch: git.branch, dirty: git.dirty });

export function appendEvent(document, input) {
  document.events ??= [];
  const previous = document.events.at(-1)?.event_digest ?? null;
  const event = {
    sequence: document.events.length + 1,
    type: input.type,
    test_id: input.testId,
    reason: input.reason,
    executed: input.executed,
    changed_files: [...new Set(input.git.changed_files ?? [])].sort(),
    recorded_at: input.recordedAt ?? new Date().toISOString(),
    git: cleanGit(input.git),
    previous_event_digest: previous,
  };
  if (input.code) event.code = input.code;
  if (input.observation) event.observation = input.observation;
  event.event_digest = digestText(JSON.stringify(event));
  document.events.push(event);
  return event;
}

export function ensureJournal(document) {
  if (document.events) return document;
  document.events = [];
  const phases = document.cycles.flatMap((cycle) => ['red', 'green', 'refactor']
    .filter((phase) => cycle[phase])
    .map((phase) => ({ cycle, phase, observation: cycle[phase] })))
    .sort((left, right) => left.observation.recorded_at.localeCompare(right.observation.recorded_at));
  for (const item of phases) {
    appendEvent(document, {
      type: phaseTypes[item.phase], testId: item.cycle.test_id, executed: true,
      reason: item.observation.expected_reason ?? `Imported ${item.phase.toUpperCase()} evidence`,
      git: item.observation.git, recordedAt: item.observation.recorded_at,
      observation: item.observation,
    });
  }
  return document;
}

export function validateEventChain(events) {
  const errors = [];
  let previous = null;
  for (const [index, event] of events.entries()) {
    const { event_digest: digest, ...body } = event;
    if (event.sequence !== index + 1) errors.push(`event ${index + 1} has invalid sequence`);
    if (event.previous_event_digest !== previous) errors.push(`event ${index + 1} breaks the digest chain`);
    if (digestText(JSON.stringify(body)) !== digest) errors.push(`event ${index + 1} has invalid digest`);
    previous = digest;
  }
  return errors;
}

export const recordedEventType = (phase) => phaseTypes[phase];
