import { blockedErrors } from './tdd-outcome.mjs';

export async function scopePreflight(root, task, inspectScope) {
  const errors = await inspectScope(root, task);
  return errors.length
    ? blockedErrors('TASK_SCOPE_VIOLATION', errors, 'Restore scope or obtain explicit authority')
    : null;
}
