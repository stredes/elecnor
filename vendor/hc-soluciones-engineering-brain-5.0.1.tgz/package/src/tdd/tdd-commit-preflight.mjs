import { isValidCommitMessage } from '../gates/git-delivery.mjs';
import { runDeclaredCommand } from '../verification/command-runner.mjs';
import { effectiveRefactor } from './evidence-state.mjs';
import { blocked } from './tdd-outcome.mjs';

const normalized = (path) => path.replaceAll('\\', '/').replace(/^\.\//, '').replace(/\/$/, '');

function productionChanges(git, manifest) {
  const roots = manifest.quality.source_roots.map(normalized);
  return (git.changed_files ?? []).filter((path) => {
    const candidate = normalized(path);
    return roots.some((root) => root === '.' || candidate === root || candidate.startsWith(`${root}/`));
  });
}

export async function readHeadCommitSubject(root, execute = runDeclaredCommand) {
  const result = await execute(root, {
    argv: ['git', 'log', '-1', '--format=%s'], timeout_seconds: 30,
  });
  if (result.exitCode !== 0 || !result.output.trim()) throw new Error('HEAD commit subject is unavailable');
  return result.output.trim();
}

export async function tddCommitPreflight(root, input, inspect = readHeadCommitSubject) {
  const { phase, evidence, git, manifest } = input;
  const previous = evidence.cycles.at(-1);
  if (phase !== 'red' || !previous) return null;
  const changed = productionChanges(git, manifest);
  if (changed.length) {
    return blocked(
      'PRODUCTION_NOT_COMMITTED', `production files remain uncommitted: ${changed.join(', ')}`,
      'Commit the completed cycle before the next RED',
    );
  }
  if (effectiveRefactor(previous).git.head === git.head) {
    return blocked(
      'PREVIOUS_CYCLE_NOT_COMMITTED', `${previous.test_id} has no commit after REFACTOR`,
      'Commit the completed cycle using [TYPE]: Imperative, scoped message',
    );
  }
  let subject;
  try { subject = git.commit_subject ?? await inspect(root); } catch (error) {
    return blocked(
      'COMMIT_METADATA_UNAVAILABLE', error.message,
      'Restore readable Git commit metadata',
    );
  }
  if (!isValidCommitMessage(subject)) {
    return blocked(
      'COMMIT_POLICY_VIOLATION', `invalid HC commit message: ${subject}`,
      'Use [TYPE]: Imperative, scoped message',
    );
  }
  return null;
}
