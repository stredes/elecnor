import { existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { readJson } from '../shared/fs.mjs';
import { validateRiskClosure } from './risk-closure.mjs';
import { validateStory } from './story.mjs';
import { validateTestPlan } from './test-plan.mjs';

export function deliveryPaths(root, task) {
  const storyPath = resolve(root, task.task.story_path);
  const evidencePath = join(root, `.hc/evidence/${task.task.id}.json`);
  return { storyPath, evidencePath };
}

export function validateDelivery(root, task, options = {}) {
  const { storyPath } = deliveryPaths(root, task);
  if (!existsSync(storyPath)) return [`missing story ${task.task.story_path}`];
  const errors = validateStory(storyPath, options);
  if (errors.length) return errors;
  const story = readJson(storyPath).story;
  const expectedId = task.task.id.replace(/^HOTFIX-/, '');
  if (story.id !== expectedId) errors.push(`task ${task.task.id} does not match story ${story.id}`);
  const knownAc = new Set(story.acceptance_criteria.map((item) => item.id));
  for (const id of task.task.acceptance_criteria) if (!knownAc.has(id)) errors.push(`task references unknown ${id}`);
  const coveredRisks = new Set(story.non_functional_requirements.flatMap((item) => item.risk_tags));
  for (const risk of task.task.risk_tags) if (!coveredRisks.has(risk)) errors.push(`risk ${risk} has no NFR control`);
  errors.push(...validateRiskClosure(task.task, story));
  errors.push(...validateTestPlan(task.task, story));
  return errors;
}
