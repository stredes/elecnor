import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { brainRoot } from '../config/brain-paths.mjs';
import { failed } from '../shared/result.mjs';
import { validateIntegrity } from './integrity.mjs';
import { validateProject } from './project.mjs';
import { validateSkills } from './skills.mjs';
import { loadTask, validateTask } from './task.mjs';
import { validateDelivery } from './delivery.mjs';

export function validateAll(projectRoot) {
  const projectErrors = validateProject(projectRoot);
  const results = [failed('project manifest', projectErrors)];
  if (projectErrors.length) return results;
  const taskPath = join(projectRoot, '.hc/task.json');
  if (existsSync(taskPath)) {
    const taskErrors = validateTask(projectRoot);
    results.push(failed('task manifest', taskErrors));
    if (!taskErrors.length) results.push(failed('task/story contract', validateDelivery(projectRoot, loadTask(taskPath))));
  }
  if (projectRoot === brainRoot) {
    results.push(failed('skills', validateSkills(brainRoot)));
    results.push(failed('Brain integrity', validateIntegrity(brainRoot)));
  }
  return results;
}
