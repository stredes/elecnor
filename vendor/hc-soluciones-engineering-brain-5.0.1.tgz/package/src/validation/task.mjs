import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { readJson } from '../shared/fs.mjs';
import { validateSchema } from './schema.mjs';

export function validateTask(root, explicitPath) {
  const path = explicitPath ?? join(root, '.hc/task.json');
  if (!existsSync(path)) return [];
  let document;
  try { document = readJson(path); } catch (error) { return [`invalid task JSON: ${error.message}`]; }
  if (document.schema_version === '1.0') return ['schema v1 requires hc migrate --to 2'];
  return validateSchema('task', document);
}

export const loadTask = (path) => readJson(path);
