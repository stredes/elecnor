import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { readJson, readText } from '../shared/fs.mjs';

const lockNames = ['package-lock.json', 'npm-shrinkwrap.json', 'pnpm-lock.yaml', 'yarn.lock'];
const clean = (value) => value?.trim().replace(/^['"]|['"]$/g, '');
const local = (value) => /^(?:file|link|workspace):/.test(value ?? '');

function npmState(path, packageName) {
  const lock = readJson(path);
  const root = lock.packages?.[''] ?? {};
  const installed = lock.packages?.[`node_modules/${packageName}`] ?? {};
  return {
    specifier: root.devDependencies?.[packageName] ?? root.dependencies?.[packageName],
    version: installed.version,
    resolved: installed.resolved,
    integrity: installed.integrity,
    local: local(installed.resolved) || local(installed.version),
  };
}

function pnpmState(path, packageName) {
  const lines = readText(path).split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const match = lines[index].match(/^(\s*)(.+):\s*$/);
    if (!match || clean(match[2]) !== packageName) continue;
    const indent = match[1].length;
    const state = {};
    for (let cursor = index + 1; cursor < lines.length; cursor += 1) {
      const nested = lines[cursor].match(/^(\s*)(.*)$/);
      if (nested[2] && nested[1].length <= indent) break;
      const field = nested[2].match(/^(specifier|version):\s*(.+)$/);
      if (field) state[field[1]] = clean(field[2]);
    }
    if (state.specifier) {
      state.version = state.version?.split('(')[0];
      if (!local(state.version)) return { ...state, local: false };
      for (let entry = 0; entry < lines.length; entry += 1) {
        const key = clean(lines[entry].trim().replace(/:$/, ''));
        if (!key.startsWith(`${packageName}@`) || !local(key.slice(packageName.length + 1))) continue;
        const block = lines.slice(entry + 1, entry + 8).join('\n');
        const integrity = clean(block.match(/integrity:\s*([^,}\s]+)/)?.[1]);
        const resolved = clean(block.match(/tarball:\s*([^,}\s]+)/)?.[1]);
        const version = clean(block.match(/^\s*version:\s*(.+)$/m)?.[1]);
        return { ...state, version, resolved, integrity, local: true };
      }
      return { ...state, local: true };
    }
  }
  return {};
}

function yarnState(path, packageName) {
  const lines = readText(path).split(/\r?\n/);
  const entry = lines.findIndex((line) => clean(line.replace(/:$/, '')).startsWith(`${packageName}@`));
  if (entry < 0) return {};
  const key = clean(lines[entry].replace(/:$/, ''));
  const specifier = key.slice(key.lastIndexOf('@') + 1);
  const block = lines.slice(entry + 1, entry + 8).join('\n');
  const version = clean(block.match(/^\s*version\s+(.+)$/m)?.[1]);
  const resolved = clean(block.match(/^\s*resolved\s+(.+)$/m)?.[1]);
  const integrity = clean(block.match(/^\s*integrity\s+(.+)$/m)?.[1]);
  return { specifier, version, resolved, integrity, local: local(specifier) || local(resolved) };
}

export function inspectBrainLock(root, packageName) {
  const present = lockNames.filter((name) => existsSync(join(root, name)));
  const errors = [];
  if (present.length > 1) errors.push(`multiple lockfiles found: ${present.join(', ')}`);
  if (present.length === 0) return { errors, state: {} };
  const name = present[0];
  const path = join(root, name);
  let state;
  if (name === 'pnpm-lock.yaml') state = pnpmState(path, packageName);
  else if (name === 'yarn.lock') state = yarnState(path, packageName);
  else state = npmState(path, packageName);
  return { errors, state };
}
