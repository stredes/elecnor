import { digestText } from '../shared/digest.mjs';
import { effectiveRefactor } from '../tdd/evidence-state.mjs';

export function sequenceRecoveryFingerprint(recovery) {
  const fields = ['previous_test_id', 'test_id', 'reason', 'previous_refactor_digest', 'next_red_digest', 'review_id', 'recorded_at'];
  const payload = Object.fromEntries(fields.map((key) => [key, recovery[key]]));
  payload.git = { head: recovery.git.head, branch: recovery.git.branch, dirty: recovery.git.dirty };
  return digestText(JSON.stringify(payload));
}

export function validateSequenceRecoveries(document, taskId) {
  const errors = [];
  const approvedPairs = new Set();
  const positions = new Map(document.cycles.map((cycle, index) => [cycle.test_id, index]));
  const recovered = new Set();
  for (const recovery of document.sequence_recoveries ?? []) {
    const pair = `${recovery.previous_test_id}->${recovery.test_id}`;
    const prior = positions.get(recovery.previous_test_id);
    const next = document.cycles[positions.get(recovery.test_id)];
    const previous = document.cycles[prior];
    const fail = (message) => errors.push(`sequence recovery ${pair} ${message}`);
    if (recovered.has(pair)) { fail('is duplicated'); continue; }
    recovered.add(pair);
    if (!previous || !next || positions.get(recovery.test_id) !== prior + 1) { fail('must reference adjacent cycles'); continue; }
    if (!previous.refactor || !next.red) { fail('requires previous REFACTOR and next RED'); continue; }
    if (digestText(JSON.stringify(previous.refactor)) !== recovery.previous_refactor_digest
      || digestText(JSON.stringify(next.red)) !== recovery.next_red_digest) fail('phase digest does not match');
    const review = document.reviews.find((item) => item.id === recovery.review_id);
    if (!review || review.status !== 'accepted' || review.fingerprint !== recovery.fingerprint
      || !review.attestation?.commit) fail('requires its matching accepted signed review');
    if (sequenceRecoveryFingerprint(recovery) !== recovery.fingerprint) fail('fingerprint is invalid');
    if (recovery.git.branch !== taskId) fail(`must be recorded on ${taskId}`);
    if (Date.parse(recovery.recorded_at) < Date.parse(previous.refactor.recorded_at)
      || Date.parse(recovery.recorded_at) < Date.parse(next.red.recorded_at)) fail('timestamp predates an observed phase');
    const sourceChanged = effectiveRefactor(previous).source_digest !== next.red.source_digest;
    const redPredates = Date.parse(next.red.recorded_at) < Date.parse(previous.refactor.recorded_at);
    if (!sourceChanged || !redPredates) fail('does not match both sequence anomalies');
    if (!errors.some((error) => error.startsWith(`sequence recovery ${pair} `))) approvedPairs.add(pair);
  }
  return { approvedPairs, errors };
}
