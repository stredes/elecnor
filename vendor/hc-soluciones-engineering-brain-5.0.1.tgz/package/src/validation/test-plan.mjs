function selectedTests(task, story) {
  const selectedAc = new Set(task.acceptance_criteria);
  return new Set(story.acceptance_criteria
    .filter((criterion) => selectedAc.has(criterion.id))
    .flatMap((criterion) => criterion.test_ids));
}

function repeated(values) {
  const seen = new Set();
  return values.filter((value) => {
    if (seen.has(value)) return true;
    seen.add(value);
    return false;
  });
}

export function validateTestPlan(task, story) {
  const plan = task.test_plan;
  if (!plan) return [];
  const errors = [];
  const selected = selectedTests(task, story);
  const planned = new Set(plan.map((item) => item.test_id));
  for (const id of selected) if (!planned.has(id)) errors.push(`test plan missing ${id}`);
  for (const id of planned) if (!selected.has(id)) errors.push(`test plan includes unselected ${id}`);
  for (const id of repeated(plan.map((item) => item.test_id))) errors.push(`test plan repeats ${id}`);
  for (const order of repeated(plan.map((item) => item.order))) errors.push(`test plan repeats order ${order}`);
  const actual = [...new Set(plan.map((item) => item.order))].sort((a, b) => a - b);
  const expected = Array.from({ length: plan.length }, (_, index) => index + 1);
  if (JSON.stringify(actual) !== JSON.stringify(expected)) errors.push('test plan order must be contiguous from 1');
  return errors;
}
