import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { readJson, readText } from '../shared/fs.mjs';
import { validateSchema } from './schema.mjs';

const stacks = {
  'backend-nest': ['typescript', 'nestjs', 'hexagonal'],
  'web-next': ['typescript', 'nextjs', 'hexagonal'],
  'mobile-expo': ['typescript', 'expo', 'hexagonal'],
  'desktop-electron': ['typescript', 'electron', 'hexagonal'],
  'vr-unity': ['csharp', 'unity', 'hexagonal'],
  brain: ['javascript', 'node', 'modular-tooling'],
};

function semanticErrors(document, root, options) {
  const errors = [];
  const project = document.project;
  const expected = stacks[project.profile];
  const actual = [project.language, project.framework, project.architecture];
  if (expected?.join('|') !== actual.join('|')) errors.push(`profile ${project.profile} has an incoherent stack`);
  if (project.language === 'typescript' && !document.quality.tsconfig) errors.push('quality.tsconfig is required for TypeScript');
  if (document.quality.tsconfig && !existsSync(join(root, document.quality.tsconfig))) errors.push('quality.tsconfig is missing');
  const overlap = document.quality.source_roots.filter((path) => document.quality.test_roots.includes(path));
  if (overlap.length) errors.push(`source_roots and test_roots overlap: ${overlap.join(', ')}`);
  for (const path of document.quality.generated_roots) {
    if (!/(^|\/)(generated|migrations)(\/|$)/i.test(path)) errors.push(`generated root is not explicit: ${path}`);
  }
  if (project.profile !== 'brain' && options.requireBootstrap !== false) {
    const agentsPath = join(root, 'AGENTS.md');
    if (!existsSync(agentsPath)) errors.push('missing AGENTS.md agent bootstrap');
    else {
      const bootstrap = readText(agentsPath);
      for (const marker of ['story_path', 'hc context', 'hc verify']) {
        if (!bootstrap.includes(marker)) errors.push(`AGENTS.md bootstrap must mention ${marker}`);
      }
    }
  }
  return errors;
}

export function validateProjectDocument(document, root, options = {}) {
  const structural = validateSchema('project', document);
  return structural.length ? structural : semanticErrors(document, root, options);
}

export function validateProject(root) {
  const path = join(root, '.hc/project.json');
  if (!existsSync(path)) return ['missing .hc/project.json'];
  let document;
  try { document = readJson(path); } catch (error) { return [`invalid project JSON: ${error.message}`]; }
  if (document.schema_version === '1.0') return ['schema v1 requires hc migrate --to 2'];
  return validateProjectDocument(document, root);
}

export const loadProject = (root) => readJson(join(root, '.hc/project.json'));
