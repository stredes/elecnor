import { existsSync } from 'node:fs';
import { basename, dirname, join, resolve } from 'node:path';
import { walkFiles, readText, relativeUnix } from '../shared/fs.mjs';

const namePattern = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

function parseFrontmatter(text) {
  const match = text.match(/^---\n([\s\S]*?)\n---\n/);
  if (!match) return null;
  const values = {};
  let section;
  for (const line of match[1].split('\n')) {
    const nested = line.match(/^\s{2}([^:]+):\s*["']?(.+?)["']?$/);
    if (nested && section) values[`${section}.${nested[1]}`] = nested[2];
    const top = line.match(/^([^\s:]+):\s*(.*)$/);
    if (top) {
      section = top[2] ? undefined : top[1];
      if (top[2]) values[top[1]] = top[2].replace(/^['"]|['"]$/g, '');
    }
  }
  return values;
}

export function validateSkills(root) {
  const skillRoot = join(root, 'skills');
  const errors = [];
  for (const path of walkFiles(skillRoot).filter((file) => basename(file) === 'SKILL.md')) {
    const content = readText(path);
    const values = parseFrontmatter(content);
    const location = relativeUnix(root, path);
    if (!values) {
      errors.push(`${location}: missing frontmatter`);
      continue;
    }
    const folder = basename(dirname(path));
    if (!namePattern.test(values.name ?? '') || values.name !== folder) errors.push(`${location}: invalid or mismatched name`);
    if ((values.description ?? '').length < 8) errors.push(`${location}: description is too short`);
    for (const field of ['hc/applies-to', 'hc/load-when', 'hc/context-budget']) {
      if (!values[`metadata.${field}`]) errors.push(`${location}: missing metadata.${field}`);
    }
    for (const match of content.matchAll(/\]\(([^)]+)\)/g)) {
      const target = match[1].split('#')[0];
      if (!target.startsWith('http') && !existsSync(resolve(dirname(path), target))) {
        errors.push(`${location}: missing linked reference ${target}`);
      }
    }
  }
  return errors;
}
