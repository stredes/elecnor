import { readJson } from '../shared/fs.mjs';
import { validateSchema } from './schema.mjs';

const duplicates = (items) => items.filter((item, index) => items.indexOf(item) !== index);

function semanticErrors(document, options) {
  const errors = [];
  const story = document.story;
  const acIds = story.acceptance_criteria.map((item) => item.id);
  const testIds = story.acceptance_criteria.flatMap((item) => item.test_ids);
  const nfrIds = story.non_functional_requirements.map((item) => item.id);
  for (const id of new Set(duplicates(acIds))) errors.push(`duplicate acceptance criterion ${id}`);
  for (const id of new Set(duplicates(nfrIds))) errors.push(`duplicate non-functional requirement ${id}`);
  if (options.done) {
    for (const ac of story.acceptance_criteria) if (!ac.test_ids.length) errors.push(`${ac.id} has no test mapping for DONE`);
    if (!story.definition_of_ready.ready) errors.push('story is not Ready and cannot be DONE');
  }
  const knownTests = new Set(testIds);
  for (const nfr of story.non_functional_requirements) {
    for (const id of nfr.test_ids) if (!knownTests.has(id)) errors.push(`${nfr.id} references unknown ${id}`);
    if (!nfr.test_ids.length && !nfr.review_ids.length) errors.push(`${nfr.id} has no test or review evidence`);
  }
  return errors;
}

export function validateStory(path, options = {}) {
  let document;
  try { document = readJson(path); } catch (error) { return [`invalid story JSON: ${error.message}`]; }
  const structural = validateSchema('user-story', document);
  return structural.length ? structural : semanticErrors(document, options);
}
