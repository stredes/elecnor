const semanticRisks = [
  {
    risk: 'concurrency',
    detect: (contract) => concurrencyOperation.test(contract)
      || (collisionLanguage.test(contract) && collisionTarget.test(contract)),
  },
  {
    risk: 'persistence',
    pattern: /\b(?:persist\w*|repository|repositories|database|storage|almacen\w*|repositorio|base de datos)\b/iu,
  },
  {
    risk: 'credentials',
    pattern: /\b(?:passwords?|passphrases?|credentials?|credenciales?|contraseñas?|secretos? de acceso)\b/iu,
  },
  {
    risk: 'identity',
    pattern: /\b(?:identity|identidad|accounts?|cuentas?|user registration|registro de usuario|registrar (?:un )?usuario)\b/iu,
  },
];

const concurrencyOperation = /\b(?:concurren\w*|simultan\w*|parallel\w*|race condition|idempoten\w*)\b/iu;
const collisionLanguage = /\b(?:unique|uniqueness|duplicate|duplicated|unicidad|duplicad[oa]s?|\u00fanic[oa]s?)\b/iu;
const collisionTarget = /\b(?:email|booking|reservation|payment|constraint|row|entity|solicitud|reserva|pago|fila|entidad)\b/iu;

function selectedTests(task, story) {
  const selectedAc = new Set(task.acceptance_criteria);
  return new Set(story.acceptance_criteria
    .filter((criterion) => selectedAc.has(criterion.id))
    .flatMap((criterion) => criterion.test_ids));
}

function relevantNfrRisks(task, story) {
  const tests = selectedTests(task, story);
  return new Set(story.non_functional_requirements
    .filter((requirement) => requirement.test_ids.length === 0
      || requirement.test_ids.some((testId) => tests.has(testId)))
    .flatMap((requirement) => requirement.risk_tags));
}

function semanticContract(task, story) {
  const selectedAc = new Set(task.acceptance_criteria);
  const criteria = story.acceptance_criteria.filter((criterion) => selectedAc.has(criterion.id));
  return [
    ...story.business_rules.map((rule) => rule.rule),
    ...criteria.flatMap((criterion) => [...criterion.given, ...criterion.when, ...criterion.then]),
  ].join('\n');
}

export function validateRiskClosure(task, story) {
  const errors = [];
  const declared = new Set(task.risk_tags);
  for (const risk of relevantNfrRisks(task, story)) {
    if (!declared.has(risk)) errors.push(`task omits NFR risk ${risk}`);
  }
  const contract = semanticContract(task, story);
  for (const { risk, pattern, detect } of semanticRisks) {
    if ((detect?.(contract) ?? pattern.test(contract)) && !declared.has(risk)) {
      errors.push(`story semantics require ${risk} risk`);
    }
  }
  return errors;
}
