import { existsSync } from 'node:fs';
import { readJson } from '../shared/fs.mjs';
import { validateSchema } from './schema.mjs';
import { productionDigest, testSuiteDigest } from '../tdd/snapshots.mjs';
import { findTestTag } from '../trace/trace-tags.mjs';
import { validateEventChain } from '../tdd/tdd-journal.mjs';
import { effectiveRefactor } from '../tdd/evidence-state.mjs';
import { validateSequenceRecoveries } from './sequence-recovery.mjs';

function validateSequence(cycles, taskId, approvedRecoveries) {
  const errors = [];
  for (const [index, cycle] of cycles.entries()) {
    const previous = cycles[index - 1];
    const recovered = approvedRecoveries.has(`${previous?.test_id}->${cycle.test_id}`);
    if (!recovered && previous?.refactor && effectiveRefactor(previous).source_digest !== cycle.red.source_digest) {
      errors.push(`${cycle.test_id} production changed before next RED`);
    }
    if (!recovered && previous?.refactor && Date.parse(cycle.red.recorded_at) < Date.parse(previous.refactor.recorded_at)) {
      errors.push(`${cycle.test_id} RED predates previous REFACTOR`);
    }
    if (!cycle.refactor) errors.push(`${cycle.test_id} has no REFACTOR evidence`);
    else {
      if (cycle.refactor.exit_code !== 0) errors.push(`${cycle.test_id} REFACTOR failed`);
      if (cycle.refactor.git.branch !== taskId) errors.push(`${cycle.test_id} REFACTOR was observed outside ${taskId}`);
      if (cycle.green && Date.parse(cycle.refactor.recorded_at) < Date.parse(cycle.green.recorded_at)) {
        errors.push(`${cycle.test_id} REFACTOR predates GREEN`);
      }
    }
  }
  return errors;
}

function validateFinal(document, root, manifest, taskId) {
  if (!document.final) return ['missing final source and test suite evidence'];
  const errors = [];
  if (document.final.git.branch !== taskId) errors.push(`final evidence was observed outside ${taskId}`);
  if (root && manifest) {
    if (document.final.source_digest !== productionDigest(root, manifest)) errors.push('source changed after final evidence');
    if (document.final.test_suite_digest !== testSuiteDigest(root, manifest)) errors.push('tests changed after final evidence');
  }
  return errors;
}

export function validateCurrentTests(root, manifest, taskId, cycles) {
  const errors = [];
  for (const cycle of cycles) {
    if (!cycle.refactor) continue;
    try {
      const current = findTestTag(root, manifest, taskId, cycle.test_id);
      if (current.digest !== effectiveRefactor(cycle).test_digest) {
        errors.push(`${cycle.test_id} changed after its own REFACTOR`);
      }
    } catch (error) {
      errors.push(error.message);
    }
  }
  return errors;
}

export function validateEvidence(path, task, story, options = {}) {
  if (!existsSync(path)) return options.required ? [`missing evidence ${path}`] : [];
  let document;
  try { document = readJson(path); } catch (error) { return [`invalid evidence JSON: ${error.message}`]; }
  const errors = validateSchema('evidence', document);
  if (errors.length) return errors;
  if (document.events) errors.push(...validateEventChain(document.events));
  if (document.task_id !== task.task.id) errors.push(`evidence task ${document.task_id} does not match ${task.task.id}`);
  const recoveries = validateSequenceRecoveries(document, task.task.id);
  errors.push(...recoveries.errors);
  const cycles = new Map(document.cycles.map((item) => [item.test_id, item]));
  for (const ac of story.story.acceptance_criteria.filter((item) => task.task.acceptance_criteria.includes(item.id))) {
    for (const id of ac.test_ids) if (!cycles.has(id)) errors.push(`${id} has no RED/GREEN evidence`);
  }
  for (const cycle of document.cycles) {
    if (cycle.red.exit_code === 0) errors.push(`${cycle.test_id} RED was green`);
    if (!cycle.green) {
      errors.push(`${cycle.test_id} has no GREEN evidence`);
      continue;
    }
    if (cycle.green.exit_code !== 0) errors.push(`${cycle.test_id} GREEN failed`);
    if (cycle.red.test_digest !== cycle.green.test_digest) errors.push(`${cycle.test_id} changed between RED and GREEN`);
    if (cycle.red.source_digest === cycle.green.source_digest) errors.push(`${cycle.test_id} has no production change`);
    if (cycle.red.git.branch !== task.task.id || cycle.green.git.branch !== task.task.id) errors.push(`${cycle.test_id} was observed outside branch ${task.task.id}`);
    if (Date.parse(cycle.green.recorded_at) < Date.parse(cycle.red.recorded_at)) errors.push(`${cycle.test_id} GREEN predates RED`);
  }
  if (options.required) errors.push(...validateSequence(document.cycles, task.task.id, recoveries.approvedPairs));
  if (options.required && options.root && options.manifest) {
    errors.push(...validateCurrentTests(options.root, options.manifest, task.task.id, document.cycles));
  }
  if (options.required) errors.push(...validateFinal(document, options.root, options.manifest, task.task.id));
  for (const review of document.reviews) if (review.status === 'open') errors.push(`${review.id} is unresolved`);
  return errors;
}
