import { existsSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
import { readJson, readText, walkFiles } from '../shared/fs.mjs';
import { brainVersion } from '../config/metadata.mjs';

const flattenContextPaths = (map) => [
  ...map.always,
  ...Object.values(map.profiles).flat(),
  ...Object.values(map.task_types).flat(),
  ...Object.values(map.change_areas).flat(),
  ...Object.values(map.risk_tags).flat(),
];

export function validateIntegrity(root) {
  const errors = [];
  if (readText(join(root, '.hc/brain.version')).trim() !== brainVersion) errors.push('.hc/brain.version does not match package.json');
  for (const file of walkFiles(join(root, '.hc/schemas')).filter((path) => path.endsWith('.json'))) {
    try {
      readJson(file);
    } catch (error) {
      errors.push(`${file}: invalid schema JSON: ${error.message}`);
    }
  }
  const map = readJson(join(root, 'router/context-map.json'));
  for (const path of new Set(flattenContextPaths(map))) {
    if (path === '.hc/project.json') continue;
    if (!existsSync(join(root, path))) errors.push(`context-map references missing ${path}`);
  }
  const profiles = Object.keys(map.profiles);
  for (const profile of profiles) {
    if (!existsSync(join(root, `gates/profiles/${profile}.json`))) errors.push(`missing gate config for ${profile}`);
    const descriptorPath = join(root, `profiles/${profile}/profile.json`);
    if (!existsSync(descriptorPath)) errors.push(`missing profile descriptor for ${profile}`);
    else if (readJson(descriptorPath).id !== profile) errors.push(`profile descriptor id mismatch for ${profile}`);
    if (profile !== 'brain') {
      for (const file of ['architecture.md', 'testing.md']) {
        if (!existsSync(join(root, `profiles/${profile}/${file}`))) errors.push(`missing ${file} for ${profile}`);
      }
      if (!existsSync(join(root, `skills/profiles/${profile}/SKILL.md`))) errors.push(`missing skill for ${profile}`);
    }
  }
  const skillNames = new Set(
    walkFiles(join(root, 'skills'))
      .filter((path) => basename(path) === 'SKILL.md')
      .map((path) => basename(dirname(path))),
  );
  const catalog = readJson(join(root, 'rules/catalog.json'));
  for (const rule of catalog.rules) {
    if (!existsSync(join(root, rule.source))) errors.push(`${rule.id}: missing source ${rule.source}`);
    for (const skill of rule.skills) if (!skillNames.has(skill)) errors.push(`${rule.id}: missing skill ${skill}`);
  }
  const canonicalPr = readText(join(root, 'templates/pull-request/pull_request_template.md'));
  const generatedPr = readText(join(root, '.github/PULL_REQUEST_TEMPLATE.md')).replace(/^<!--.*-->\n/, '');
  if (canonicalPr !== generatedPr) errors.push('GitHub PR template drifted from canonical template');
  return errors;
}
