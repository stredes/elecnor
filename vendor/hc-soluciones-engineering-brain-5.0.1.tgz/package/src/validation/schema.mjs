import Ajv2020 from 'ajv/dist/2020.js';
import { fromBrain } from '../config/brain-paths.mjs';
import { readJson } from '../shared/fs.mjs';

const ajv = new Ajv2020({ allErrors: true, strict: true });
const validators = new Map();

function validatorFor(name) {
  if (!validators.has(name)) {
    const schema = readJson(fromBrain(`.hc/schemas/${name}.schema.json`));
    validators.set(name, ajv.compile(schema));
  }
  return validators.get(name);
}

function describe(error) {
  const location = error.instancePath || '/';
  if (error.keyword === 'additionalProperties') {
    return `${location}: unexpected property ${error.params.additionalProperty}`;
  }
  return `${location}: ${error.message}`;
}

export function validateSchema(name, document) {
  const validate = validatorFor(name);
  return validate(document) ? [] : validate.errors.map(describe);
}
