import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { readJson } from '../shared/fs.mjs';
import { loadProject } from './project.mjs';
import { brainVersion, packageName } from '../config/metadata.mjs';
import { inspectBrainLock } from './package-lock.mjs';

function typescriptVersion(root) {
  try {
    const require = createRequire(join(root, 'package.json'));
    return require('typescript/package.json').version;
  } catch {
    return null;
  }
}

const localTarball = (value) => /^file:.+\.tgz$/i.test(value ?? '');

function tarballErrors(root, specifier, state) {
  const path = resolve(root, specifier.slice('file:'.length));
  if (!existsSync(path)) return [`local Brain tarball is missing: ${specifier}`];
  if (!/^sha512-[A-Za-z0-9+/]+={0,2}$/.test(state.integrity ?? '')) {
    return ['local Brain tarball lockfile integrity is missing or invalid'];
  }
  const actual = `sha512-${createHash('sha512').update(readFileSync(path)).digest('base64')}`;
  return actual === state.integrity ? [] : ['local Brain tarball integrity does not match lockfile'];
}

export function checkDoctor(root) {
  const manifest = loadProject(root);
  const errors = [];
  if (manifest.brain_version !== brainVersion) errors.push(`running Brain ${brainVersion}, project pins ${manifest.brain_version}`);
  if (manifest.project.profile !== 'brain') {
    const projectPackage = existsSync(join(root, 'package.json')) ? readJson(join(root, 'package.json')) : {};
    const declared = projectPackage.devDependencies?.[packageName];
    const declaredTarball = localTarball(declared);
    if (declared !== manifest.brain_version && !declaredTarball) {
      errors.push(`${packageName} must pin ${manifest.brain_version} or a local .tgz`);
    }
    const lock = inspectBrainLock(root, packageName);
    errors.push(...lock.errors);
    if (lock.state.specifier !== declared) errors.push(`lockfile specifier for Brain is ${lock.state.specifier ?? '(missing)'}, expected ${declared ?? '(missing)'}`);
    if (lock.state.version !== manifest.brain_version) errors.push(`lockfile resolves Brain ${lock.state.version ?? '(missing)'}`);
    if (lock.state.local && !declaredTarball) errors.push('undeclared local Brain resolution in lockfile');
    if (declaredTarball && !lock.state.local) errors.push('local Brain tarball is not resolved locally by the lockfile');
    if (declaredTarball && lock.state.local) errors.push(...tarballErrors(root, declared, lock.state));
  }
  if (manifest.project.language === 'typescript') {
    const version = typescriptVersion(root);
    if (!version || !/^(?:5\.(?:[7-9]|\d{2,})|6|7)\./.test(version)) errors.push(`unsupported project TypeScript ${version ?? '(missing)'}`);
  }
  return errors;
}
