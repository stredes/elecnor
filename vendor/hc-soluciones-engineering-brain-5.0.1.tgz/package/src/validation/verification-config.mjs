import { existsSync } from 'node:fs';
import { basename, join } from 'node:path';
import { readJson } from '../shared/fs.mjs';

const backendBase = ['lint', 'format_check', 'typecheck', 'unit', 'dependency_audit', 'build'];
const brainBase = ['unit', 'dependency_audit', 'build'];
const clientBase = ['lint', 'typecheck', 'unit', 'dependency_audit', 'build'];
const vrBase = ['build', 'editmode'];
const unsafeExecutables = new Set(['sh', 'bash', 'zsh', 'fish', 'dash', 'ksh', 'cmd', 'cmd.exe', 'powershell', 'pwsh']);
const executableName = (value) => basename(value.replaceAll('\\', '/')).toLowerCase();
const excludesDev = /(?:^|\s)(?:--omit(?:=|\s+)dev|--only(?:=|\s+)prod(?:uction)?|--prod(?:uction)?(?:=true)?)(?:\s|$)/;

function requiredChecks(manifest, task) {
  if (manifest.project.profile === 'brain') return brainBase;
  if (['web-next', 'mobile-expo', 'desktop-electron'].includes(manifest.project.profile)) {
    const checks = [...clientBase];
    const areas = new Set(task?.task.change_areas ?? []);
    const risks = new Set(task?.task.risk_tags ?? []);
    if (areas.has('infrastructure')) checks.push('integration');
    if (areas.has('presentation') || risks.has('public-api') || risks.has('external-input')) checks.push('e2e');
    if (manifest.project.profile === 'desktop-electron') checks.push('package_app');
    return checks;
  }
  if (manifest.project.profile === 'vr-unity') {
    const checks = [...vrBase];
    const areas = new Set(task?.task.change_areas ?? []);
    if (areas.has('infrastructure') || areas.has('presentation')) checks.push('playmode');
    if (areas.has('presentation')) checks.push('device', 'performance');
    return checks;
  }
  if (manifest.project.profile !== 'backend-nest') return [];
  const checks = [...backendBase];
  const risks = new Set(task?.task.risk_tags ?? []);
  const areas = new Set(task?.task.change_areas ?? []);
  if (areas.has('presentation') || risks.has('public-api') || risks.has('external-input')) checks.push('e2e');
  if (['persistence', 'concurrency', 'transaction', 'migration'].some((risk) => risks.has(risk))) checks.push('integration');
  return checks;
}

function resolvedCommand(root, command) {
  const [executable, action, script] = command.argv;
  if (!['npm', 'npm.cmd'].includes(executable) || action !== 'run' || !script) return command.argv.join(' ');
  const path = join(root, 'package.json');
  if (!existsSync(path)) return command.argv.join(' ');
  return `${readJson(path).scripts?.[script] ?? ''} ${command.argv.slice(3).join(' ')}`;
}

export function checkVerificationConfig(root, manifest, task) {
  const errors = [];
  const commands = manifest.verification.commands;
  for (const check of requiredChecks(manifest, task)) if (!commands[check]) errors.push(`missing required verification command ${check}`);
  for (const [name, command] of Object.entries(commands)) {
    const resolved = resolvedCommand(root, command);
    if (unsafeExecutables.has(executableName(command.argv[0]))) errors.push(`${name} cannot execute through a shell`);
    if (['lint', 'format_check'].includes(name) && /(?:^|\s)(?:--(?:fix|write)(?:=|\s|$)|-w(?:\s|$))/.test(resolved)) {
      errors.push(`${name} must be non-mutating`);
    }
    if (name === 'lint' && /(?:^|\s)eslint(?:\.cmd)?(?:\s|$)/.test(resolved)
      && !/--max-warnings(?:=|\s+)0(?:\s|$)/.test(resolved)) {
      errors.push('lint must use --max-warnings=0 so warnings cannot pass');
    }
    if (name === 'dependency_audit' && excludesDev.test(resolved)
      && (manifest.verification.dependency_audit_justification?.trim().length ?? 0) < 12) {
      errors.push('dependency_audit excludes development dependencies without justification');
    }
  }
  return errors;
}
