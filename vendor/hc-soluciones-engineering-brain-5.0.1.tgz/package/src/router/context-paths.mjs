import { existsSync, readFileSync, statSync } from 'node:fs';
import { dirname, isAbsolute, relative, resolve } from 'node:path';
import { brainRoot } from '../config/brain-paths.mjs';

const linkPattern = /\[[^\]]*\]\(([^)\s]+)(?:\s+[^)]*)?\)/g;
const unix = (value) => value.replaceAll('\\', '/');

function isInside(path, root) {
  const child = relative(root, path);
  return child === '' || (!child.startsWith('..') && !isAbsolute(child));
}

function localReferences(path, roots) {
  if (!path.endsWith('.md')) return [];
  const content = readFileSync(path, 'utf8');
  return [...content.matchAll(linkPattern)].flatMap((match) => {
    const target = match[1].replace(/^<|>$/g, '').split('#')[0];
    if (!target || /^[a-z]+:/i.test(target)) return [];
    const candidate = resolve(dirname(path), target);
    const allowed = roots.some((root) => isInside(candidate, root));
    return allowed && existsSync(candidate) && statSync(candidate).isFile() ? [candidate] : [];
  });
}

export function expandContextFiles(initial, projectRoot) {
  const roots = [resolve(projectRoot), brainRoot];
  const files = [...new Set(initial.map((path) => resolve(path)))]
    .filter((path) => existsSync(path) && statSync(path).isFile());
  for (let index = 0; index < files.length; index += 1) {
    for (const reference of localReferences(files[index], roots)) {
      if (!files.includes(reference)) files.push(reference);
    }
  }
  return files;
}

export function contextAlias(path, projectRoot) {
  if (isInside(path, projectRoot)) return `project:${unix(relative(projectRoot, path))}`;
  if (isInside(path, brainRoot)) return `brain:${unix(relative(brainRoot, path))}`;
  throw new Error(`context path is outside declared roots: ${path}`);
}
