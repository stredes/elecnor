import { existsSync } from 'node:fs';
import { isAbsolute, join, resolve } from 'node:path';
import { brainRoot, fromBrain } from '../config/brain-paths.mjs';
import { readJson } from '../shared/fs.mjs';
import { loadProject } from '../validation/project.mjs';
import { withContextBudget } from './context-budget.mjs';
import { contextAlias, expandContextFiles } from './context-paths.mjs';
import { createContextCapsule } from './context-capsule.mjs';

const selected = (record, key) => record[key] ?? [];

export function selectContext(projectRoot, taskPath, testId) {
  const manifest = loadProject(projectRoot);
  const map = readJson(fromBrain('router/context-map.json'));
  const defaultTask = join(projectRoot, '.hc/task.json');
  const resolvedTask = taskPath ? resolve(taskPath) : defaultTask;
  const taskDocument = existsSync(resolvedTask) ? readJson(resolvedTask) : null;
  const task = taskDocument?.task ?? null;
  const files = map.always.map((path) => path === '.hc/project.json' ? join(projectRoot, path) : fromBrain(path));
  const memoryPath = join(projectRoot, '.hc/project-memory.md');
  if (existsSync(memoryPath)) files.push(memoryPath);
  files.push(...selected(map.profiles, manifest.project.profile).map((path) => fromBrain(path)));
  if (task) {
    const plan = task.test_plan?.find((item) => item.test_id === testId);
    if (!testId) {
      files.push(resolvedTask);
      files.push(resolve(projectRoot, task.story_path));
      files.push(...selected(map.task_types, task.type).map((path) => fromBrain(path)));
      for (const area of task.change_areas ?? []) {
        files.push(...selected(map.change_areas, area).map((path) => fromBrain(path)));
      }
    } else {
      const workflow = selected(map.task_types, task.type)
        .filter((path) => path.startsWith('workflows/') || path.includes('definition-of-done'));
      files.push(...workflow.map((path) => fromBrain(path)));
      files.push(...(plan?.context ?? []).map((path) => fromBrain(path)));
    }
    for (const risk of task.risk_tags ?? []) {
      files.push(...selected(map.risk_tags, risk).map((path) => fromBrain(path)));
    }
  }
  const initial = [...new Set(files)].map((path) => isAbsolute(path) ? path : resolve(brainRoot, path));
  const absoluteFiles = expandContextFiles(initial, projectRoot);
  const core = {
    profile: manifest.project.profile,
    task: task?.id ?? null,
    workflow: task?.type ?? 'discovery',
    roots: { project: resolve(projectRoot), brain: brainRoot },
    files: absoluteFiles.map((path) => contextAlias(path, projectRoot)),
    ...(testId ? {
      capsule: createContextCapsule(
        taskDocument, readJson(resolve(projectRoot, task.story_path)), testId,
      ),
    } : {}),
  };
  return withContextBudget(core, absoluteFiles);
}
