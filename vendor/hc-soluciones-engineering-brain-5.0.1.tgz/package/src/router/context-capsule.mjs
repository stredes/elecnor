function relevantRequirements(story, testId) {
  return story.non_functional_requirements.filter((requirement) =>
    requirement.test_ids.length === 0 || requirement.test_ids.includes(testId));
}

export function createContextCapsule(taskDocument, storyDocument, testId) {
  const task = taskDocument.task;
  const story = storyDocument.story;
  const criteria = story.acceptance_criteria.filter((criterion) =>
    task.acceptance_criteria.includes(criterion.id) && criterion.test_ids.includes(testId));
  if (!criteria.length) throw new Error(`${testId} is not selected by the active task`);
  return {
    test_id: testId,
    story_id: story.id,
    canonical: {
      task: 'project:.hc/task.json',
      story: `project:${task.story_path}`,
    },
    preconditions: story.preconditions,
    acceptance_criteria: criteria,
    business_rules: story.business_rules,
    edge_cases: story.edge_cases,
    dependencies: story.dependencies,
    non_functional_requirements: relevantRequirements(story, testId),
    scope: taskDocument.scope,
    constraints: taskDocument.constraints ?? [],
    authority: taskDocument.authority,
    plan: task.test_plan?.find((item) => item.test_id === testId) ?? null,
  };
}
