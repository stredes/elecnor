import { readFileSync } from 'node:fs';

const limitTokens = 7_000;

function nextBudget(context, contentBytes) {
  const payloadBytes = Buffer.byteLength(JSON.stringify(context));
  const utf8Bytes = contentBytes + payloadBytes;
  const estimatedTokens = Math.ceil(utf8Bytes / 4);
  return {
    file_count: context.files.length,
    content_bytes: contentBytes,
    payload_bytes: payloadBytes,
    utf8_bytes: utf8Bytes,
    estimated_tokens: estimatedTokens,
    estimator: 'ceil((content_bytes+payload_bytes)/4)',
    limit_tokens: limitTokens,
    within_limit: estimatedTokens <= limitTokens,
    blocker: estimatedTokens <= limitTokens ? null : 'CONTEXT_BUDGET_EXCEEDED',
  };
}

export function withContextBudget(core, absoluteFiles) {
  const contentBytes = absoluteFiles.reduce(
    (total, path) => total + readFileSync(path).byteLength, 0,
  );
  let context = { ...core, budget: {} };
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const budget = nextBudget(context, contentBytes);
    if (JSON.stringify(budget) === JSON.stringify(context.budget)) return context;
    context = { ...core, budget };
  }
  return context;
}
