import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const brainRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
export const fromBrain = (...parts) => resolve(brainRoot, ...parts);
