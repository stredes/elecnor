import { fromBrain } from './brain-paths.mjs';
import { readJson } from '../shared/fs.mjs';

const metadata = readJson(fromBrain('package.json'));

export const packageName = metadata.name;
export const brainVersion = metadata.version;
