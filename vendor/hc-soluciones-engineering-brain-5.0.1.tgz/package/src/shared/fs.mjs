import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { extname, join, relative } from 'node:path';

export const readText = (path) => readFileSync(path, 'utf8');
export const readJson = (path) => JSON.parse(readText(path));

export function walkFiles(root, excluded = new Set()) {
  if (!existsSync(root)) return [];
  const found = [];
  const visit = (directory) => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      if (entry.isSymbolicLink() || excluded.has(entry.name)) continue;
      const path = join(directory, entry.name);
      if (entry.isDirectory()) visit(path);
      if (entry.isFile()) found.push(path);
    }
  };
  visit(root);
  return found;
}

export const physicalLines = (text) => {
  if (text.length === 0) return 0;
  const lines = text.split(/\r?\n/);
  return lines.at(-1) === '' ? lines.length - 1 : lines.length;
};

export const relativeUnix = (root, path) => relative(root, path).replaceAll('\\', '/');
export const hasExtension = (path, extensions) => extensions.includes(extname(path));
