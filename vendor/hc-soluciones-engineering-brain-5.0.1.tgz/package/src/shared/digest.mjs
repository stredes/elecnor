import { createHash } from 'node:crypto';
import { relative } from 'node:path';
import { readText } from './fs.mjs';

export const digestText = (value) => createHash('sha256').update(value).digest('hex');

export function digestFiles(root, files) {
  const content = [...files]
    .sort()
    .map((path) => `${relative(root, path)}\0${readText(path)}`)
    .join('\0');
  return digestText(content);
}
