export const ok = (label) => ({ label, errors: [] });
export const failed = (label, errors, reviews = []) => ({ label, errors, reviews });

export function printResults(results) {
  for (const result of results) {
    if (result.errors.length === 0 && !(result.reviews?.length)) {
      console.log(`PASS ${result.label}`);
      continue;
    }
    if (result.errors.length) {
      console.error(`FAIL ${result.label}`);
      for (const error of result.errors) console.error(`  - ${error}`);
    }
    if (result.reviews?.length) {
      console.warn(`REVIEW ${result.label}`);
      for (const review of result.reviews) console.warn(`  - ${review}`);
    }
  }
}

export const hasFailures = (results) => results.some((result) => result.errors.length > 0);
export const hasReviews = (results) => results.some((result) => result.reviews?.length > 0);
