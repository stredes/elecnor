import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fromBrain } from '../config/brain-paths.mjs';
import { brainVersion } from '../config/metadata.mjs';
import { readJson, readText } from '../shared/fs.mjs';

const agentBootstrap = `# Project agent bootstrap

Use the exact \`@hc-soluciones/engineering-brain\` version pinned by \`.hc/project.json\`.
Commit policy: \`[TYPE]: Imperative, scoped message\`. Treat the initial commit as an unmanaged baseline;
commit every completed cycle after REFACTOR and before the next RED.

1. Run \`hc context\` before work; it validates project, task and its \`story_path\`.
2. Load every returned path once, then inspect only target files and direct dependencies.
3. Use \`hc tdd\` for observable behaviour and \`hc verify\` before DONE.
4. State an intention once, then call the tool; do not narrate the same action twice.
5. After every write, confirm success and inspect the diff or readback before reasoning about it.
6. Retry a failed tool call once with corrected input, then report its concrete blocker.
7. Continue all authorized work without asking the user to continue.
8. Stop only for a blocker that requires human authority or an unavailable external system.

\`hc gates\` is a baseline only. Never weaken a valid test, acceptance criterion or gate.
Every model follows the same Brain rules; capability changes slice size, not quality.
Do not emit repetitive operational self-talk; report only state, action result and blocker.
`;

export function ensureAgentBootstrap(target) {
  const agentsPath = join(target, 'AGENTS.md');
  if (!existsSync(agentsPath)) writeFileSync(agentsPath, agentBootstrap);
}

export function initProject(profileInput, name, targetInput) {
  const catalog = readJson(fromBrain('templates/projects/catalog.json'));
  const profile = catalog.aliases[profileInput] ?? profileInput;
  const template = catalog.profiles[profile];
  if (!template) throw new Error(`unsupported profile: ${profileInput}`);
  if (!/^[a-z0-9][a-z0-9-]{1,62}$/.test(name)) throw new Error('name must be kebab-case');
  const target = resolve(targetInput ?? name);
  const manifestPath = join(target, '.hc/project.json');
  if (existsSync(manifestPath)) throw new Error(`refusing to overwrite ${manifestPath}`);
  for (const folder of ['.hc', ...template.folders]) mkdirSync(join(target, folder), { recursive: true });
  const manifest = {
    schema_version: '2.0', brain_version: brainVersion,
    project: {
      name, profile, language: template.language, framework: template.framework,
      architecture: 'hexagonal', methodology: 'tdd',
    },
    quality: {
      source_roots: template.source_roots, test_roots: template.test_roots,
      generated_roots: template.generated_roots,
      ...(template.language === 'typescript' ? { tsconfig: 'tsconfig.json' } : {}),
    },
    verification: { commands: {} },
  };
  writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
  if (template.language === 'typescript' && !existsSync(join(target, 'tsconfig.json'))) {
    const tsconfig = { compilerOptions: { strict: true, noEmit: true }, include: [...template.source_roots, ...template.test_roots] };
    writeFileSync(join(target, 'tsconfig.json'), `${JSON.stringify(tsconfig, null, 2)}\n`);
  }
  writeFileSync(join(target, '.hc/project-memory.md'), readText(fromBrain('templates/project/project-memory.md')));
  ensureAgentBootstrap(target);
  return target;
}
