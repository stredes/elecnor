import { hasFailures, printResults } from '../shared/result.mjs';
import { brainVersion } from '../config/metadata.mjs';

const findings = (results) => results.flatMap((result) => [
  ...result.errors.map((message) => ({ level: 'error', ruleId: result.label, message })),
  ...(result.reviews ?? []).map((message) => ({ level: 'warning', ruleId: result.label, message })),
]);

function sarif(results) {
  const items = findings(results);
  return {
    version: '2.1.0',
    $schema: 'https://json.schemastore.org/sarif-2.1.0.json',
    runs: [{
      tool: { driver: { name: 'HC Engineering Brain', version: brainVersion } },
      results: items.map((item) => ({
        ruleId: item.ruleId,
        level: item.level,
        message: { text: item.message },
      })),
    }],
  };
}

export function reportResults(results, format = 'human') {
  if (format === 'human') printResults(results);
  else if (format === 'json') console.log(JSON.stringify({ ok: !hasFailures(results), results }, null, 2));
  else if (format === 'sarif') console.log(JSON.stringify(sarif(results), null, 2));
  else throw new Error(`unsupported format: ${format}`);
  return hasFailures(results) ? 1 : 0;
}
