import { failed, hasFailures } from '../shared/result.mjs';
import { brainVersion } from '../config/metadata.mjs';
import { runGates } from '../gates/run-gates.mjs';
import { initProject } from '../init/init-project.mjs';
import { selectContext } from '../router/select-context.mjs';
import { validateAll } from '../validation/all.mjs';
import { validateStory } from '../validation/story.mjs';
import { checkDoctor } from '../validation/doctor.mjs';
import { reportResults } from '../reporting/report.mjs';
import { formatOption, option, positionalValue, projectRootOption } from './options.mjs';
import { runVerify } from '../verification/run-verify.mjs';
import { runPlannedTddOutcome, runTddOutcome } from '../tdd/run-tdd.mjs';
import { rebaselineTddCycle, restartTddCycle } from '../tdd/manage-cycle.mjs';
import { formatTddStatus, tddStatus } from '../tdd/tdd-status.mjs';
import { migrateV2 } from '../migration/migrate-v2.mjs';
import { formatTddOutcome } from './tdd-output.mjs';
import { runBenchmarkCommand } from './benchmark-command.mjs';

const report = (results, args) => reportResults(results, formatOption(args));

export async function runCommand(args) {
  const [command, subcommand, value] = args;
  if (command === 'brain' && subcommand === 'info') {
    console.log(`HC Engineering Brain v${brainVersion}`);
    return 0;
  }
  if (command === 'validate') return report(validateAll(projectRootOption(args)), args);
  if (command === 'doctor') return report([failed('Brain pin and toolchain', checkDoctor(projectRootOption(args)))], args);
  if (command === 'gates') return report(await runGates(projectRootOption(args)), args);
  if (command === 'verify') return report(await runVerify(projectRootOption(args)), args);
  if (command === 'benchmark' && subcommand && value) {
    const result = runBenchmarkCommand(projectRootOption(args), subcommand, value, args);
    if (result) {
      console.log(JSON.stringify(result.output));
      return result.status;
    }
  }
  if (command === 'tdd' && ['red', 'green', 'refactor'].includes(subcommand) && value) {
    const separator = args.indexOf('--');
    const extraArgs = separator >= 0 ? args.slice(separator + 1) : [];
    const root = projectRootOption(args);
    const check = option(args, '--check');
    const outcome = check
      ? await runTddOutcome(root, subcommand, value, check, extraArgs, option(args, '--expect'))
      : await runPlannedTddOutcome(root, subcommand, value);
    const label = `TDD ${subcommand.toUpperCase()} ${value}`;
    if (formatOption(args) === 'sarif') return report([failed(label, outcome.errors)], args);
    console.log(formatTddOutcome(label, outcome, formatOption(args)));
    return outcome.ok ? 0 : 1;
  }
  if (command === 'tdd' && subcommand === 'restart' && value) {
    const outcome = await restartTddCycle(projectRootOption(args), value, option(args, '--reason'));
    return report([failed(`TDD RESTART ${value}`, outcome.errors)], args);
  }
  if (command === 'tdd' && subcommand === 'rebaseline' && value) {
    const outcome = await rebaselineTddCycle(projectRootOption(args), value, option(args, '--reason'));
    return report([failed(`TDD REBASELINE ${value}`, outcome.errors)], args);
  }
  if (command === 'next' || (command === 'tdd' && subcommand === 'status')) {
    const status = tddStatus(projectRootOption(args), command === 'tdd' ? positionalValue(value) : undefined);
    console.log(formatOption(args) === 'json' ? JSON.stringify(status) : formatTddStatus(status));
    return 0;
  }
  if (command === 'migrate' && option(args, '--to') === '2') {
    const mode = args.includes('--apply') ? 'apply' : args.includes('--prepare') ? 'prepare' : 'dry-run';
    const outcome = await migrateV2(projectRootOption(args), mode);
    return report([failed('migration v1 to v2', outcome.errors, outcome.notes)], args);
  }
  if (command === 'story' && subcommand === 'validate' && value) {
    return report([failed(`story ${value}`, validateStory(value, { done: args.includes('--done') }))], args);
  }
  if (command === 'context') {
    const root = projectRootOption(args);
    const validation = validateAll(root);
    if (hasFailures(validation)) return report(validation, args);
    const context = selectContext(root, option(args, '--task'), option(args, '--test'));
    console.log(JSON.stringify(context, null, 2));
    return context.budget.within_limit ? 0 : 1;
  }
  if (command === 'init' && subcommand && value) {
    const target = initProject(subcommand, value, option(args, '--target'));
    console.log(`Initialized ${value} at ${target}`);
    return 0;
  }
  return null;
}
