import { appendBenchmarkEvent } from '../benchmark/benchmark-events.mjs';
import { finishBenchmark } from '../benchmark/finish-benchmark.mjs';
import { readBenchmark } from '../benchmark/benchmark-store.mjs';
import { startBenchmark } from '../benchmark/start-benchmark.mjs';
import { option } from './options.mjs';

const integerOption = (args, name) => {
  const value = option(args, name);
  return value === undefined ? undefined : Number(value);
};

const success = (code, fields) => ({ status: 0, output: { ok: true, code, ...fields } });
const failure = (error) => ({
  status: 1,
  output: { ok: false, code: error.code ?? 'BENCHMARK_ERROR', error: error.message },
});

export function runBenchmarkCommand(root, subcommand, runId, args) {
  try {
    if (subcommand === 'start') {
      const run = startBenchmark(root, {
        runId, model: option(args, '--model'), modelVersion: option(args, '--model-version'),
        testId: option(args, '--test'),
      });
      return success('BENCHMARK_STARTED', {
        run_id: runId, status: run.status, context_tokens: run.context.budget.estimated_tokens,
      });
    }
    if (subcommand === 'event') {
      const run = appendBenchmarkEvent(root, runId, {
        type: option(args, '--type'), detail: option(args, '--detail'), testId: option(args, '--test'),
        inputCharacters: integerOption(args, '--input-characters'),
        outputCharacters: integerOption(args, '--output-characters'),
      });
      return success('BENCHMARK_EVENT_RECORDED', {
        run_id: runId, sequence: run.events.at(-1).sequence,
      });
    }
    if (subcommand === 'finish') {
      const run = finishBenchmark(root, runId, option(args, '--result'));
      return success('BENCHMARK_FINISHED', { run_id: runId, status: run.status, metrics: run.metrics });
    }
    if (subcommand === 'report') {
      return success('BENCHMARK_REPORT', { run_id: runId, run: readBenchmark(root, runId) });
    }
    return null;
  } catch (error) {
    return failure(error);
  }
}
