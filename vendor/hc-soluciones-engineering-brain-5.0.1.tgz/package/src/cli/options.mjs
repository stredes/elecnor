import { resolve } from 'node:path';

export function option(args, name) {
  const index = args.indexOf(name);
  return index >= 0 ? args[index + 1] : undefined;
}

export const projectRootOption = (args) => resolve(option(args, '--project') ?? process.cwd());
export const formatOption = (args) => option(args, '--format') ?? 'human';
export const positionalValue = (value) => value && !value.startsWith('--') ? value : undefined;
