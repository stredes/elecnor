export function formatTddOutcome(label, outcome, format = 'human') {
  if (format === 'json') return JSON.stringify(outcome);
  if (format !== 'human') throw new Error(`unsupported TDD format: ${format}`);
  const lines = [`${outcome.ok ? 'PASS' : 'FAIL'} ${label} [${outcome.code}]`];
  lines.push(...outcome.errors.map((error) => `  - ${error}`));
  if (outcome.next_action) lines.push(`NEXT ${outcome.next_action}`);
  return lines.join('\n');
}
