import { readJson } from '../shared/fs.mjs';
import { collectTestTags } from './trace-tags.mjs';

const sorted = (items) => [...items].sort().join(',');

export function validateTrace(root, manifest, task, storyPath) {
  const story = readJson(storyPath).story;
  const selected = story.acceptance_criteria.filter((ac) => task.task.acceptance_criteria.includes(ac.id));
  const expected = new Map();
  for (const ac of selected) {
    for (const testId of ac.test_ids) {
      const acIds = expected.get(testId) ?? [];
      expected.set(testId, [...acIds, ac.id]);
    }
  }
  const tags = collectTestTags(root, manifest).filter((item) => item.taskId === task.task.id);
  const errors = [];
  for (const [testId, acIds] of expected) {
    const found = tags.filter((tag) => tag.testId === testId);
    if (found.length !== 1) errors.push(`${testId} expected one tag, found ${found.length}`);
    else if (sorted(found[0].acIds) !== sorted(acIds)) errors.push(`${testId} maps ${sorted(found[0].acIds)}, expected ${sorted(acIds)}`);
  }
  for (const tag of tags) if (!expected.has(tag.testId)) errors.push(`stale test tag ${tag.tag}`);
  return errors;
}
