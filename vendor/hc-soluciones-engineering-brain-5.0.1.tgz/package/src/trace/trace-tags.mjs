import { join } from 'node:path';
import { walkFiles, readText, hasExtension } from '../shared/fs.mjs';
import { digestText } from '../shared/digest.mjs';

const extensions = ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.cs'];
const tagPattern = /(?:NP|HOTFIX-NP)-\d{4}\/AC-\d{2}(?:,AC-\d{2})*\/TEST-\d{2}/g;

export function parseTestTag(tag) {
  const [taskId, acPart, testId] = tag.split('/');
  return { taskId, acIds: acPart.split(','), testId };
}

export function collectTestTags(root, manifest) {
  const matches = [];
  for (const relativeRoot of manifest.quality.test_roots) {
    for (const path of walkFiles(join(root, relativeRoot))) {
      if (!hasExtension(path, extensions)) continue;
      const content = readText(path);
      for (const match of content.matchAll(tagPattern)) {
        matches.push({ ...parseTestTag(match[0]), tag: match[0], path, content });
      }
    }
  }
  return matches;
}

export function findTestTag(root, manifest, taskId, testId) {
  const items = collectTestTags(root, manifest).filter((item) => item.taskId === taskId && item.testId === testId);
  if (items.length !== 1) throw new Error(`${testId} must have exactly one test tag; found ${items.length}`);
  return { ...items[0], digest: digestText(items[0].content.replace(/\s+/g, ' ').trim()) };
}
