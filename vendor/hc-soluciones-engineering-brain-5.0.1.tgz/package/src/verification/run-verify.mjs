import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { runGates } from '../gates/run-gates.mjs';
import { digestText } from '../shared/digest.mjs';
import { failed, hasFailures } from '../shared/result.mjs';
import { validateTrace } from '../trace/validate-trace.mjs';
import { checkDoctor } from '../validation/doctor.mjs';
import { deliveryPaths } from '../validation/delivery.mjs';
import { validateEvidence } from '../validation/evidence.mjs';
import { loadProject } from '../validation/project.mjs';
import { loadTask } from '../validation/task.mjs';
import { readJson } from '../shared/fs.mjs';
import { runDeclaredCommand } from './command-runner.mjs';
import { validateRiskEvidence } from './risk-evidence.mjs';
import { checkReviewAttestations } from './review-attestation.mjs';

const order = ['lint', 'format_check', 'typecheck', 'unit', 'integration', 'e2e', 'dependency_audit', 'build'];

function unresolvedReviews(gates, evidence) {
  const accepted = new Set(evidence?.reviews.filter((item) => item.status === 'accepted').map((item) => item.fingerprint) ?? []);
  return gates.flatMap((result) => result.reviews ?? []).filter((message) => !accepted.has(digestText(message)));
}

function commandErrors(execution) {
  if (execution.exitCode === 0) return [];
  const detail = execution.output.trim().split('\n').slice(-20).join('\n');
  return [`exit code ${execution.exitCode}`, ...(detail ? [detail] : [])];
}

export async function runVerify(root) {
  const results = await runGates(root);
  if (hasFailures(results)) return results;
  const manifest = loadProject(root);
  results.push(failed('Brain pin and toolchain', checkDoctor(root)));
  const taskPath = join(root, '.hc/task.json');
  let evidence;
  if (existsSync(taskPath)) {
    const task = loadTask(taskPath);
    const { storyPath, evidencePath } = deliveryPaths(root, task);
    const story = readJson(storyPath);
    results.push(failed('AC to test trace', validateTrace(root, manifest, task, storyPath)));
    const evidenceErrors = validateEvidence(evidencePath, task, story, { required: true, root, manifest });
    results.push(failed('TDD evidence', evidenceErrors));
    if (!evidenceErrors.length) {
      evidence = readJson(evidencePath);
      results.push(failed('review provenance', await checkReviewAttestations(root, evidence)));
      results.push(failed('risk evidence levels', validateRiskEvidence(root, manifest, task, storyPath, evidencePath)));
    }
  }
  results.push(failed('review signals', unresolvedReviews(results, evidence)));
  if (hasFailures(results)) return results;
  for (const name of order) {
    const command = manifest.verification.commands[name];
    if (!command) continue;
    const execution = await runDeclaredCommand(root, command);
    results.push(failed(`command ${name}`, commandErrors(execution)));
  }
  return results;
}
