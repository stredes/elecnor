import { runDeclaredCommand } from './command-runner.mjs';

const command = (argv) => ({ argv, timeout_seconds: 30 });

function signedMetadata(output) {
  const [email = '', ...message] = output.trim().split('\n');
  return { email: email.trim().toLowerCase(), message: message.join('\n') };
}

export async function checkReviewAttestations(root, evidence, execute = runDeclaredCommand) {
  const errors = [];
  for (const review of evidence.reviews.filter((item) => item.status === 'accepted')) {
    const commit = review.attestation?.commit;
    if (!commit) {
      errors.push(`${review.id} accepted review has no signed commit attestation`);
      continue;
    }
    const signature = await execute(root, command(['git', 'verify-commit', commit]));
    if (signature.exitCode !== 0) {
      errors.push(`${review.id} attestation commit has no valid signature`);
      continue;
    }
    const ancestor = await execute(root, command(['git', 'merge-base', '--is-ancestor', commit, 'HEAD']));
    if (ancestor.exitCode !== 0) errors.push(`${review.id} attestation commit is not reachable from HEAD`);
    const shown = await execute(root, command(['git', 'show', '-s', '--format=%ae%n%B', commit]));
    if (shown.exitCode !== 0) {
      errors.push(`${review.id} attestation commit metadata is unavailable`);
      continue;
    }
    const metadata = signedMetadata(shown.output);
    if (metadata.email !== review.approved_by.toLowerCase()) {
      errors.push(`${review.id} approved_by does not match signed commit email`);
    }
    if (!metadata.message.includes(`HC-Task: ${evidence.task_id}`)) errors.push(`${review.id} signed commit is not bound to ${evidence.task_id}`);
    if (!metadata.message.includes(`HC-Review: ${review.fingerprint}`)) errors.push(`${review.id} signed commit is not bound to its fingerprint`);
  }
  return errors;
}
