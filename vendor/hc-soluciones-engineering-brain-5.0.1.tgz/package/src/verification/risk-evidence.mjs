import { readJson } from '../shared/fs.mjs';
import { collectTestTags } from '../trace/trace-tags.mjs';
import { validateBackendRiskSubstance } from './backend-risk-substance.mjs';

const integrationRisks = new Set(['persistence', 'concurrency', 'transaction', 'migration']);
const e2eRisks = new Set(['external-input', 'public-api']);
const sensitiveRisks = new Set([
  'identity', 'authorization', 'credentials', 'personal-data', 'concurrency', 'release',
]);
const httpMarker = /\b(?:HTTP|status(?:\s+code)?|c[oó]digo\s+de\s+estado|response\s+(?:status|body)|respuesta\s+HTTP)\b/iu;
const httpOutcome = /\b(?:returns?|responds?|devuelve|responde)\b[^.\n]{0,100}\b(?:[1-5]\d\d|created|conflict|bad request|unauthorized|forbidden|not found|no content)\b/iu;

function level(path) {
  if (/(?:^|\/)(?:integration)(?:\/|\.)/i.test(path)) return 'integration';
  if (/(?:^|\/)(?:e2e)(?:\/|\.|-)/i.test(path)) return 'e2e';
  return 'unit';
}

export function validateSensitiveReviews(taskDocument, storyDocument, evidence) {
  const risks = taskDocument.task.risk_tags.filter((risk) => sensitiveRisks.has(risk));
  const nfrs = storyDocument.story.non_functional_requirements;
  const reviews = new Map(evidence.reviews.map((review) => [review.id, review]));
  const errors = [];
  for (const risk of risks) {
    const ids = nfrs.filter((nfr) => nfr.risk_tags.includes(risk)).flatMap((nfr) => nfr.review_ids);
    if (!ids.length) {
      errors.push(`${risk} requires accepted human review evidence`);
      continue;
    }
    for (const id of new Set(ids)) {
      const review = reviews.get(id);
      if (review?.status !== 'accepted' || !review.approved_by) errors.push(`${id} for ${risk} is not accepted by a human reviewer`);
    }
  }
  return errors;
}

export function validateHttpAcEvidence(task, story, byTest, profile = 'backend-nest') {
  if (profile !== 'backend-nest') return [];
  const errors = [];
  const selected = new Set(task.acceptance_criteria);
  for (const criterion of story.acceptance_criteria.filter((item) => selected.has(item.id))) {
    const contract = [...criterion.given, ...criterion.when, ...criterion.then].join('\n');
    if (!httpMarker.test(contract) && !httpOutcome.test(contract)) continue;
    if (!criterion.test_ids.some((testId) => byTest.get(testId) === 'e2e')) {
      errors.push(`${criterion.id} promises an HTTP outcome and requires its own e2e TEST`);
    }
  }
  return errors;
}

export function validateRiskEvidence(root, manifest, task, storyPath, evidencePath) {
  const story = readJson(storyPath).story;
  const evidence = readJson(evidencePath);
  const tags = collectTestTags(root, manifest).filter((item) => item.taskId === task.task.id);
  const byTest = new Map(tags.map((item) => [item.testId, level(item.path)]));
  const reviewIds = new Set(evidence.reviews.filter((item) => item.status !== 'open').map((item) => item.id));
  const errors = validateSensitiveReviews(task, { story }, evidence);
  errors.push(...validateHttpAcEvidence(task.task, story, byTest, manifest.project.profile));
  for (const nfr of story.non_functional_requirements) {
    if (!nfr.risk_tags.some((risk) => task.task.risk_tags.includes(risk))) continue;
    const levels = nfr.test_ids.map((id) => byTest.get(id));
    const hasIntegratedEvidence = levels.some((item) => item === 'integration' || item === 'e2e');
    if (nfr.risk_tags.some((risk) => integrationRisks.has(risk)) && !hasIntegratedEvidence) {
      errors.push(`${nfr.id} requires integration evidence`);
    }
    if (nfr.risk_tags.some((risk) => e2eRisks.has(risk)) && !levels.includes('e2e')) {
      errors.push(`${nfr.id} requires e2e evidence`);
    }
    for (const id of nfr.review_ids) if (!reviewIds.has(id)) errors.push(`${nfr.id} references unresolved ${id}`);
    errors.push(...validateBackendRiskSubstance(root, manifest, nfr, tags));
  }
  return errors;
}
