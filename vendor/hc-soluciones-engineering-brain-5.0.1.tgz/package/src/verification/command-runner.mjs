import { spawn } from 'node:child_process';
import { closeSync, mkdtempSync, openSync, readFileSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

export function runDeclaredCommand(root, command, extraArgs = []) {
  const [executable, ...baseArgs] = command.argv;
  return new Promise((resolve) => {
    const limit = 10 * 1024 * 1024;
    const temporary = mkdtempSync(join(tmpdir(), 'hc-command-'));
    const outputPath = join(temporary, 'output.log');
    const descriptor = openSync(outputPath, 'w');
    const child = spawn(executable, [...baseArgs, ...extraArgs], {
      cwd: root, shell: false, stdio: ['ignore', descriptor, descriptor],
    });
    closeSync(descriptor);
    let settled = false, timedOut = false, timer;
    const finish = (exitCode, fallback = '') => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      const size = statSync(outputPath).size;
      let output = readFileSync(outputPath, 'utf8').slice(0, limit);
      if (size > limit) output += '\noutput truncated at 10 MiB';
      if (fallback) output += `${output ? '\n' : ''}${fallback}`;
      rmSync(temporary, { recursive: true, force: true });
      resolve({ exitCode, output });
    };
    child.on('error', (error) => finish(127, error.message));
    child.on('close', (code) => finish(timedOut ? 124 : code ?? 1, timedOut ? 'command timed out' : ''));
    timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGKILL');
    }, command.timeout_seconds * 1000);
  });
}
