import { resolve } from 'node:path';
import { readText, walkFiles } from '../shared/fs.mjs';

const persistenceImport = /(?:from\s+|require\s*\(\s*)['"](?:typeorm|pg|postgres|@prisma\/client|drizzle-orm|knex|sequelize|mongoose|mongodb)(?:['"/])/;
const overlappingExecution = /\b(?:Promise\.all(?:Settled)?|concurrent(?:ly)?|parallel|simult[áa]ne[oa]s?|race)\b/iu;
const integratedPath = /(?:^|\/)(?:integration|e2e)(?:\/|\.|-)/i;

function productionContents(root, manifest) {
  return manifest.quality.source_roots.flatMap((sourceRoot) =>
    walkFiles(resolve(root, sourceRoot))
      .filter((path) => /\.[cm]?[jt]sx?$/.test(path))
      .map((path) => readText(path)),
  );
}

function integrationTests(nfr, tags) {
  const ids = new Set(nfr.test_ids);
  return tags.filter((tag) => ids.has(tag.testId) && integratedPath.test(tag.path));
}

export function validateBackendRiskSubstance(root, manifest, nfr, tags) {
  if (manifest.project.profile !== 'backend-nest') return [];
  const risks = new Set(nfr.risk_tags);
  const integration = integrationTests(nfr, tags);
  const errors = [];
  if (risks.has('persistence')) {
    const realAdapter = productionContents(root, manifest).some((content) =>
      persistenceImport.test(content),
    );
    if (!realAdapter) errors.push(`${nfr.id} requires real backend persistence evidence`);
  }
  if (risks.has('concurrency')) {
    const overlaps = integration.some((tag) => overlappingExecution.test(tag.content));
    if (!overlaps) errors.push(`${nfr.id} concurrency evidence must exercise overlapping operations`);
  }
  return errors;
}
