import { digestText } from '../shared/digest.mjs';
import { readBenchmark, writeBenchmark } from './benchmark-store.mjs';
import { benchmarkError } from './benchmark-error.mjs';

export { finishBenchmark } from './finish-benchmark.mjs';

const eventTypes = new Set(['TOOL_CALL', 'EDIT_FAILED', 'HUMAN_INTERVENTION']);

function characters(value, label) {
  const number = value ?? 0;
  if (!Number.isInteger(number) || number < 0) {
    throw benchmarkError('INVALID_BENCHMARK_EVENT', `${label} must be a non-negative integer`);
  }
  return number;
}

export function appendBenchmarkEvent(root, runId, input, now = () => new Date().toISOString()) {
  const run = readBenchmark(root, runId);
  if (run.status !== 'RUNNING') {
    throw benchmarkError('BENCHMARK_ALREADY_FINISHED', `benchmark ${runId} is already finished`);
  }
  if (!eventTypes.has(input.type)) {
    throw benchmarkError('INVALID_BENCHMARK_EVENT', `invalid benchmark event type ${input.type}`);
  }
  if (!input.detail?.trim() || input.detail.trim().length > 160) {
    throw benchmarkError('INVALID_BENCHMARK_EVENT', 'benchmark event detail must contain 1-160 characters');
  }
  const inputCharacters = characters(input.inputCharacters, 'input characters');
  const outputCharacters = characters(input.outputCharacters, 'output characters');
  const event = {
    sequence: run.events.length + 1,
    type: input.type,
    detail: input.detail.trim(),
    ...(input.testId ? { test_id: input.testId } : {}),
    input_characters: inputCharacters,
    output_characters: outputCharacters,
    estimated_tokens: Math.ceil((inputCharacters + outputCharacters) / 4),
    recorded_at: now(),
    previous_event_digest: run.events.at(-1)?.event_digest ?? null,
  };
  event.event_digest = digestText(JSON.stringify(event));
  run.events.push(event);
  return writeBenchmark(root, run);
}

export function validateBenchmarkEventChain(events) {
  const errors = [];
  let previous = null;
  for (const [index, event] of events.entries()) {
    const { event_digest: digest, ...body } = event;
    if (event.sequence !== index + 1) errors.push(`event ${index + 1} has invalid sequence`);
    if (event.previous_event_digest !== previous) errors.push(`event ${index + 1} breaks the digest chain`);
    if (digestText(JSON.stringify(body)) !== digest) errors.push(`event ${index + 1} has invalid digest`);
    previous = digest;
  }
  return errors;
}
