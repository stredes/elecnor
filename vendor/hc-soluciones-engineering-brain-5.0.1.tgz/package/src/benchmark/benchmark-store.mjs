import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { benchmarkError } from './benchmark-error.mjs';

const runPattern = /^BENCH-[A-Z0-9][A-Z0-9-]{2,63}$/;

export function benchmarkPath(root, runId) {
  if (!runPattern.test(runId ?? '')) {
    throw benchmarkError('INVALID_BENCHMARK_RUN_ID', 'benchmark run id must match BENCH-[A-Z0-9-]');
  }
  return join(root, '.hc', 'benchmarks', `${runId}.json`);
}

export function createBenchmark(root, document) {
  const path = benchmarkPath(root, document.run_id);
  mkdirSync(dirname(path), { recursive: true });
  const normalized = JSON.parse(JSON.stringify(document));
  try {
    writeFileSync(path, `${JSON.stringify(normalized, null, 2)}\n`, { flag: 'wx' });
  } catch (error) {
    if (error.code === 'EEXIST') {
      throw benchmarkError('BENCHMARK_ALREADY_EXISTS', `benchmark ${document.run_id} already exists`);
    }
    throw error;
  }
  return normalized;
}

export function readBenchmark(root, runId) {
  return JSON.parse(readFileSync(benchmarkPath(root, runId), 'utf8'));
}

export function writeBenchmark(root, document) {
  const path = benchmarkPath(root, document.run_id);
  const temporary = `${path}.${process.pid}.tmp`;
  const normalized = JSON.parse(JSON.stringify(document));
  writeFileSync(temporary, `${JSON.stringify(normalized, null, 2)}\n`);
  renameSync(temporary, path);
  return normalized;
}
