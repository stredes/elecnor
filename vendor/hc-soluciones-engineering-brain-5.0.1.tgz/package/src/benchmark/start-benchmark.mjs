import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { brainVersion } from '../config/metadata.mjs';
import { selectContext } from '../router/select-context.mjs';
import { digestText } from '../shared/digest.mjs';
import { readJson } from '../shared/fs.mjs';
import { loadTask } from '../validation/task.mjs';
import { benchmarkError } from './benchmark-error.mjs';
import { benchmarkPath, createBenchmark } from './benchmark-store.mjs';

function required(value, label) {
  if (!value?.trim()) throw benchmarkError('BENCHMARK_ARGUMENT_REQUIRED', `${label} is required`);
  return value.trim();
}

function evidenceCursor(root, taskId) {
  const path = join(root, '.hc', 'evidence', `${taskId}.json`);
  if (!existsSync(path)) return 0;
  return readJson(path).events?.at(-1)?.sequence ?? 0;
}

function contextSnapshot(selected, testId) {
  const context = {
    test_id: testId,
    profile: selected.profile,
    files: selected.files,
    capsule: selected.capsule,
    budget: selected.budget,
  };
  return { ...context, payload_digest: digestText(JSON.stringify(context)) };
}

export function startBenchmark(root, input, now = () => new Date().toISOString()) {
  benchmarkPath(root, input.runId);
  const model = required(input.model, 'model');
  const version = required(input.modelVersion, 'model version');
  const testId = required(input.testId, 'test id');
  const task = loadTask(join(root, '.hc', 'task.json'));
  const selected = selectContext(root, undefined, testId);
  if (!selected.budget.within_limit) {
    throw benchmarkError(selected.budget.blocker, 'benchmark context exceeds its token budget');
  }
  return createBenchmark(root, {
    schema_version: '2.0',
    run_id: input.runId,
    status: 'RUNNING',
    model: { name: model, version },
    brain_version: brainVersion,
    task_id: task.task.id,
    started_at: now(),
    context: contextSnapshot(selected, testId),
    evidence_start_sequence: evidenceCursor(root, task.task.id),
    events: [],
  });
}
