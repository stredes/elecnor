import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { readJson } from '../shared/fs.mjs';
import { validateEventChain } from '../tdd/tdd-journal.mjs';
import { readBenchmark, writeBenchmark } from './benchmark-store.mjs';
import { benchmarkError } from './benchmark-error.mjs';

const finalStatuses = new Set(['COMPLETED', 'STALLED', 'FAILED']);
const phaseNames = {
  RED_RECORDED: 'RED', GREEN_RECORDED: 'GREEN',
  REFACTOR_RECORDED: 'REFACTOR', REBASELINED: 'REBASELINE',
};

function evidenceEvents(root, run) {
  const path = join(root, '.hc', 'evidence', `${run.task_id}.json`);
  if (!existsSync(path)) return [];
  const events = readJson(path).events ?? [];
  const errors = validateEventChain(events);
  if (errors.length) throw new Error(`invalid TDD event chain: ${errors.join('; ')}`);
  return events.filter((event) => event.sequence > run.evidence_start_sequence);
}

function cycleSummaries(events) {
  const cycles = new Map();
  for (const event of events) {
    const cycle = cycles.get(event.test_id) ?? {
      test_id: event.test_id, outcome: 'IN_PROGRESS', phases: [], attempts_failed: 0,
    };
    const phase = phaseNames[event.type];
    if (phase && !cycle.phases.includes(phase)) cycle.phases.push(phase);
    if (event.type === 'ATTEMPT_FAILED') {
      cycle.attempts_failed += 1;
      cycle.outcome = event.code ?? 'FAILED';
    }
    if (['REFACTOR_RECORDED', 'REBASELINED'].includes(event.type)) cycle.outcome = 'PASSED';
    cycles.set(event.test_id, cycle);
  }
  return [...cycles.values()];
}

function metrics(run, finishedAt) {
  const eventTokens = run.events.reduce((total, event) => total + event.estimated_tokens, 0);
  const count = (type) => run.events.filter((event) => event.type === type).length;
  const duration = Date.parse(finishedAt) - Date.parse(run.started_at);
  if (!Number.isFinite(duration) || duration < 0) throw new Error('benchmark finish time predates start');
  return {
    duration_ms: duration,
    context_tokens: run.context.budget.estimated_tokens,
    event_tokens: eventTokens,
    estimated_tokens: run.context.budget.estimated_tokens + eventTokens,
    tool_calls: count('TOOL_CALL'),
    failed_edits: count('EDIT_FAILED'),
    human_interventions: count('HUMAN_INTERVENTION'),
  };
}

export function finishBenchmark(root, runId, status, now = () => new Date().toISOString()) {
  const run = readBenchmark(root, runId);
  if (run.status !== 'RUNNING') {
    throw benchmarkError('BENCHMARK_ALREADY_FINISHED', `benchmark ${runId} is already finished`);
  }
  if (!finalStatuses.has(status)) {
    throw benchmarkError('INVALID_BENCHMARK_RESULT', `invalid benchmark result ${status}`);
  }
  const finishedAt = now();
  return writeBenchmark(root, {
    ...run, status, finished_at: finishedAt,
    metrics: metrics(run, finishedAt),
    cycles: cycleSummaries(evidenceEvents(root, run)),
  });
}
