# ADR-000 — Decision title

- Status: proposed
- Date: YYYY-MM-DD
- Owners: Architecture authority

## Context

What forces a decision and which constraints matter?

## Decision

What is chosen?

## Rationale

Why this option over credible alternatives?

## Consequences

Positive, negative, migration and review consequences.
