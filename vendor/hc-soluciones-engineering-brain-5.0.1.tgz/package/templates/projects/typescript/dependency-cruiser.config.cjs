module.exports = {
  forbidden: [
    {
      name: 'no-circular',
      severity: 'error',
      from: {},
      to: { circular: true },
    },
    {
      name: 'domain-points-inward',
      severity: 'error',
      from: { path: '[/]domain[/]' },
      to: { path: '[/](application|infrastructure|ui)[/]' },
    },
    {
      name: 'application-does-not-use-adapters',
      severity: 'error',
      from: { path: '[/]application[/]' },
      to: { path: '[/](infrastructure|ui)[/]' },
    },
  ],
  options: { doNotFollow: { path: 'node_modules' }, tsPreCompilationDeps: true },
};
