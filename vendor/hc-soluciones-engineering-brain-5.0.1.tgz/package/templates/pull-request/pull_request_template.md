## NP / User Story

- NP: NP-XXXX
- HU: link or path

## Behaviour and traceability

| AC | Tests | Result |
| --- | --- | --- |
| AC-01 | NP-XXXX/AC-01/TEST-01 | `hc tdd` RED → GREEN |

## Change

- Scope implemented:
- Architecture/ADR:
- Contracts or migrations:
- Risks and rollback:

## Evidence

- [ ] `.hc/evidence` contains observed RED/GREEN
- [ ] `hc verify` passes with all review signals resolved
- [ ] Source and tests typecheck; integration/e2e match declared risks
- [ ] Security/integration/e2e when applicable
- [ ] Documentation/contracts updated
- [ ] No gate, valid test or AC weakened
