# Project memory

## Architecture and stack

- Profile:
- Relevant ADR:

## Current state and milestone

- State:
- Next milestone:

## Constraints and risks

- Constraint:
- Technical risk:

## Last verification

- Brain version:
- `hc verify` result/evidence:
