# Release vX.Y.Z

- Release PR: `Development → main`
- Included NP:
- Changelog:
- Compatibility notes:
- Migrations and execution order:
- Security/operational risks:
- Rollback trigger and procedure:
- Evidence from profile gates:
- Post-release verification:
