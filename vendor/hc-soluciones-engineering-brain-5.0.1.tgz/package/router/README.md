# Brain Router

El mapa declarativo selecciona: contexto universal + profile + task type + layer. `hc context` añade el
task manifest si existe, deduplica paths y advierte si falta. No inspecciona todo el repo ni elige
modelos. El agente puede cargar después una referencia puntual si un símbolo o ADR lo exige.

Sin task manifest, retorna sólo el core y profile: es seguro para discovery pero insuficiente para
implementar una HU. Crear `.hc/task.json` reduce inferencia y espacio de decisión.
