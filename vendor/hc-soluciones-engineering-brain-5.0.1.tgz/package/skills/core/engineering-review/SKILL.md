---
name: engineering-review
description: Review a scoped change for behaviour, security, architecture, tests, SOLID, smells, and delivery readiness.
metadata:
  hc/applies-to: "all changes"
  hc/load-when: "PR review or self-validation"
  hc/context-budget: "medium"
---

# Engineering review

Review in priority order: correctness/AC, security, boundaries, test quality, SRP/design, maintainability,
simplicity and performance requirements. Read diff and directly affected contracts; expand only on a
concrete dependency.

Classify findings by impact and cite file/evidence. Distinguish hard gate failure, warning and human
review signal. Check scope creep, missing regression, architecture change without ADR, gate weakening,
99-line evasion and documentation source drift.

Do not demand speculative abstractions or style churn. A review passes only when required evidence is
green; absence of a finding is not proof a gate ran.
