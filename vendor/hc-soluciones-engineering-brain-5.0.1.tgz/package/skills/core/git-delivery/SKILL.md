---
name: git-delivery
description: Prepare HC branches, logical commits, pull requests, hotfixes, and releases with traceable evidence.
metadata:
  hc/applies-to: "git delivery"
  hc/load-when: "commit, PR, hotfix, or release preparation"
  hc/context-budget: "small"
---

# Git delivery

Read the [Git workflow](../../../standards/git/workflow.md),
[commit standard](../../../standards/git/commits.md) and selected delivery workflow. Confirm correct base,
`NP-XXXX` identity and target. Group changes into logical, verifiable commits using an allowed category.

For PR, complete AC→test evidence, architecture/contracts, migrations, risk and gates. For release,
choose SemVer from compatibility and prepare rollback. For hotfix, require RED regression and immediate
Development synchronization.

Do not work directly on main/Development, commit secrets, hide unrelated changes in squash, or promote
without cross-repo compatibility evidence.
