---
name: clean-code
description: Improve implementation readability and maintainability while preserving explicit business intent.
metadata:
  hc/applies-to: "all code"
  hc/load-when: "implementation, GREEN refactor, or code review"
  hc/context-budget: "small"
---

# Clean Code

Use names that expose domain intent and units. Keep functions focused, side effects explicit, nesting
shallow, parameter lists small and dependencies visible. Replace magic values with named domain or
configuration concepts. Remove duplication, dead code, stale comments and misleading abstractions.

Comments explain rationale or constraints that code cannot; they do not narrate syntax. Prefer early
returns and typed parameter objects when they clarify meaning. A helper needs a semantic responsibility,
not merely lines moved out.

After editing, read the code as its next maintainer, run relevant tests, and inspect 99-line/complexity
signals. Never trade clarity for clever terseness or change behaviour during cleanup.
