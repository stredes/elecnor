---
name: token-economy
description: Select the minimum sufficient repository and Brain context for an engineering task without losing decision-critical facts.
metadata:
  hc/applies-to: "all agent work"
  hc/load-when: "task startup or context expansion"
  hc/context-budget: "tiny"
---

# Token economy

Run or emulate the Brain Router. Load Constitution, manifests, selected profile/workflow/skills, then
inspect repository tree, search symbols, exact files and their direct dependencies. Expand only when an
unanswered decision needs it.

Default to Big Pickle or a basic GPT-class model for bounded implementation with explicit AC, paths and
commands. Escalate a slice to a frontier model only for unresolved architecture/security trade-offs,
cross-system ambiguity or failed deterministic recovery; return the decision, not the whole transcript,
to the economical implementer. Split broad work until the cheaper model has one observable outcome and
one verification loop. Model names never weaken gates or change authority.

Prefer canonical links and current project memory over copied summaries. Compact findings into facts,
constraints, decisions and open risks; do not retain terminal noise or stale history.

Never optimize tokens by omitting security, acceptance criteria, relevant ADR or verification evidence.
The router's provider-independent estimate is directional, not billing data. Minimum sufficient context
is a correctness constraint.
