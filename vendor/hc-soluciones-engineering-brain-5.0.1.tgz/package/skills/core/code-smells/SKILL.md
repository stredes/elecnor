---
name: code-smells
description: Detect and prioritize design smells during GREEN refactor or engineering review without mechanical fragmentation.
metadata:
  hc/applies-to: "all code"
  hc/load-when: "REFACTOR or quality review"
  hc/context-budget: "small"
---

# Code smell review

Inspect changed code and neighbours for Long Method, Large Class, God Object, Feature Envy, Primitive
Obsession, Shotgun Surgery, Divergent Change, Data Clumps, Boolean Blindness, excessive parameters,
deep nesting, duplication, hidden/temporal coupling, inappropriate intimacy and cycles.

Also detect speculative generality, abstractions without purpose and anemic models only when behaviour
is misplaced. For each smell, cite evidence, impact and the smallest semantic refactor. Prioritize
correctness/security and high-change paths; not every smell requires immediate work.

Do not split solely for line count, invent patterns, or label simple data transport as anemic domain.
