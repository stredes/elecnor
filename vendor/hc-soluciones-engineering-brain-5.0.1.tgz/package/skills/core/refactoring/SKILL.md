---
name: refactoring
description: Improve code structure without changing observable behaviour, protected by tests and quality gates.
metadata:
  hc/applies-to: "all code"
  hc/load-when: "dedicated refactor or GREEN phase"
  hc/context-budget: "small"
---

# Refactoring

Read the [refactor workflow](../../../workflows/refactor/WORKFLOW.md). Establish green tests and the observable contract. If protection
is weak, add characterization tests before structural change.

Name the smell, choose one bounded transformation, keep dependency direction inward, and run focused
tests after each meaningful step. Extract only cohesive responsibilities. Confirm public API, persistence
semantics and side effects remain unchanged; run gates at the end.

Do not mix feature work, mass rename unrelated code, fragment files artificially, or rewrite tests to
match changed behaviour.
