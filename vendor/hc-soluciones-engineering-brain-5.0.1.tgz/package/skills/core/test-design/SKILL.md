---
name: test-design
description: Translate acceptance criteria, risks, and edge cases into meaningful behaviour tests and traceability.
metadata:
  hc/applies-to: "all productive profiles"
  hc/load-when: "AC mapping or test planning"
  hc/context-budget: "small"
---

# Test design

Map each AC to observable outcomes and choose the lowest test level that proves it without coupling to
implementation. Cover representative happy path, boundary, rejection and risk-driven cases; do not
multiply equivalent examples.

Use deterministic clocks/IDs through real ports. Mock external boundaries, not the unit under test.
Assert outcomes and meaningful collaboration, not private calls. Concurrency, DB constraints, routing,
native devices and framework wiring require their appropriate integration level.

Output an AC→TEST matrix with test level, reason and required fixture. Flag ambiguous or untestable AC
before coding; do not silently invent business rules.
