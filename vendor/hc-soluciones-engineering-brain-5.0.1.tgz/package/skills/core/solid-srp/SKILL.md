---
name: solid-srp
description: Apply SOLID with emphasis on SRP when designing, implementing, or reviewing cohesive code units.
metadata:
  hc/applies-to: "all code"
  hc/load-when: "design, implementation, refactor, or review"
  hc/context-budget: "tiny"
---

# SOLID and SRP

For each changed unit, state its responsibility and reason to change. Separate behaviour only when the
new unit gains a semantic name, cohesive inputs and a stable dependency direction.

Prefer composition, explicit dependencies and narrow contracts. Check whether a module changes for
business policy, orchestration, transport, persistence or presentation; mixed reasons indicate a split.
Apply OCP/LSP/ISP/DIP to actual variation and substitutability, not ceremony.

Reject god services, generic managers, hidden globals, feature internals shared by shortcut, and
`part-1` fragmentation. Verify extracted units improve cohesion and remain within 99 lines.
