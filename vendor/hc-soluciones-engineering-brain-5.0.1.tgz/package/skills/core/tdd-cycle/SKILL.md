---
name: tdd-cycle
description: Implement one feature or bug behaviour through strict RED, minimum GREEN, REFACTOR, and regression evidence.
metadata:
  hc/applies-to: "features and bugfixes"
  hc/load-when: "writing or changing observable behaviour"
  hc/context-budget: "small"
---

# TDD cycle

Read the selected workflow and [testing strategy](../../../standards/testing/testing-strategy.md).

1. Select one AC behaviour and assign `TEST-XX`.
2. Write the smallest tagged test; use `hc tdd red` with the expected failure text.
3. If born green, investigate before production changes.
4. Implement only enough for GREEN; avoid adjacent scope.
5. While green, apply Clean Code, SOLID and smell review.
6. Record GREEN/REFACTOR without changing that TEST afterward; finish with `hc verify`.

Evidence stores command and digests, not raw logs. Never delete/skip/weaken a valid test, change an AC,
or add future behaviour to save a later cycle.
