---
name: hexagonal-design
description: Design or change domain, application, ports, adapters, or module boundaries in an HC productive project.
metadata:
  hc/applies-to: "productive profiles"
  hc/load-when: "architecture or boundary decisions"
  hc/context-budget: "small"
---

# Hexagonal design

Read the [architecture standard](../../../standards/architecture/hexagonal-vertical.md) and
[ports standard](../../../standards/architecture/ports-adapters.md). Then read only the active profile.

1. Name the business behaviour and owning feature.
2. Place invariants and deterministic rules in domain.
3. Place orchestration in a small application use case.
4. Introduce an application port only for a real external/replaced boundary.
5. Implement translation and technology in an adapter; wire at the framework edge.
6. Check inward imports, cross-feature contracts and testability without runtime.

Output the responsibility of each new unit and any gate/test needed. Do not create empty layer folders,
one-implementation interfaces by reflex, framework imports inward, or architecture changes without ADR
authority.
