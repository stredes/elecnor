---
name: requirements-traceability
description: Prepare or validate an HC user story and maintain lightweight NP, AC, test, PR, and release traceability.
metadata:
  hc/applies-to: "user stories and delivery"
  hc/load-when: "requirements shaping or traceability review"
  hc/context-budget: "small"
---

# Requirements and traceability

Read the [story standard](../../../standards/requirements/user-story.md) and
[traceability standard](../../../standards/requirements/traceability.md). Validate the schema, unique IDs,
business value, boundaries and testable outcomes. Convert examples to Given/When/Then where useful,
without inventing policy.

Check DoR before implementation. Build exact `NP/AC/TEST` tags and carry them through evidence and PR.
At DONE, `hc verify` must connect task, story, tags and RED/GREEN evidence; deferred work stays explicit.

Do not make documentation perfect for its own sake, encode implementation as AC, or change requirement
meaning without Product/human authority.
