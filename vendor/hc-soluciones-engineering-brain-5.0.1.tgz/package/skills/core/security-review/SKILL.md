---
name: security-review
description: Threat-model and review a scoped change for trust boundaries, authorization, secrets, input, and sensitive data risks.
metadata:
  hc/applies-to: "all productive profiles"
  hc/load-when: "external input, identity, data, dependency, or release risk"
  hc/context-budget: "small"
---

# Security review

Read the [security standard](../../../standards/security/security-standard.md) plus the active profile. Identify assets, actors, entry
points, trust boundaries and likely abuse. Trace authentication and object/action authorization at the
trusted boundary. Check validation, injection, logs, error leakage, secrets, transport, storage,
dependencies, least privilege, replay/race and client trust.

Comprueba que alta de cuentas y material secreto declaren riesgos sensibles aunque el agente haya
omitido sus tags. Unicidad concurrente requiere review y evidencia solapada sobre storage real.

Return findings ordered critical/high/medium/low with evidence, exploit condition and concrete control.
Add behaviour tests for security invariants where feasible. Never put server secrets or authority in
web/mobile/Quest clients, log sensitive payloads, or dismiss a risk because UI hides the action. If a
finding is accepted, bind its fingerprint and task to a reachable signed commit; do not self-assert an
approver identity.
