---
name: web-next
description: Implement or review an HC Next.js App Router feature with explicit server, client, application, and UI boundaries.
metadata:
  hc/applies-to: "web-next"
  hc/load-when: "Next App Router task"
  hc/context-budget: "small"
---

# Web Next profile

Read the [architecture](../../../profiles/web-next/architecture.md) and
[testing guide](../../../profiles/web-next/testing.md). Use the canonical app/application/core/domain/
infrastructure/presentation split. Keep domain/application portable and presentation independent from
concrete adapters. Default to Server Components and introduce the smallest client boundary.

Keep authenticated browser traffic behind the dashboard BFF and session in secure httpOnly cookies.
Use TanStack Query for remote state and Zustand only for UI state with an allowlisted persisted slice.
Centralize env, HTTP, query keys and successful invalidation. Run HC gates, lint, strict typecheck,
behaviour tests, e2e when required and production build.

Do not place rules in components/actions, expose backend tokens to client code, import server-only APIs
from client modules, persist remote entities, or trust hidden UI for authorization.
