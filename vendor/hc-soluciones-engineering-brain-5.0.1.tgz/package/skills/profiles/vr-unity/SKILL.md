---
name: vr-unity
description: Implement or review an HC Unity 6 Quest feature separating training behaviour from MonoBehaviour and XR adapters.
metadata:
  hc/applies-to: "vr-unity"
  hc/load-when: "Unity VR task"
  hc/context-budget: "small"
---

# VR Unity profile

Read the [architecture](../../../profiles/vr-unity/architecture.md) and
[testing guide](../../../profiles/vr-unity/testing.md). Model scenario state, rules, scoring,
progress and safety without UnityEngine types. Application owns platform ports; MonoBehaviours, OpenXR,
XRIT, Quest, scenes, persistence and telemetry remain adapters. Give Domain/Application separate asmdefs
with No Engine References and compose only in Bootstrap.

Make lifecycle cancellation, permission/error paths and device performance budgets explicit. Use
RED/GREEN for behaviour, EditMode for inner layers, PlayMode for composition/adapters, then recorded
device metrics and human comfort validation on Quest. Run architecture, build, EditMode, PlayMode,
device and performance gates required by the changed layer.

Do not leak Vector3/GameObject through ports, calculate business rules in Update, put I/O in
Presentation, infer device performance from Editor, or treat sensory approval as automatable.
