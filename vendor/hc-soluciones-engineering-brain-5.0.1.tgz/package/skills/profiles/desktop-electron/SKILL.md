---
name: desktop-electron
description: Implement or review an HC Electron desktop feature while inheriting dashboard layers and isolating native capabilities.
metadata:
  hc/applies-to: "desktop-electron"
  hc/load-when: "Electron desktop task"
  hc/context-budget: "small"
---

# Desktop Electron profile

Read the inherited [dashboard architecture](../../../profiles/web-next/architecture.md), the
[desktop delta](../../../profiles/desktop-electron/architecture.md) and its
[testing guide](../../../profiles/desktop-electron/testing.md). Keep renderer code inside dashboard
boundaries and expose only typed, allowlisted capabilities through preload.

Compose ports in main/preload, validate IPC sender/channel/payload and return serializable results.
Preserve context isolation, sandbox, CSP, navigation denial, lifecycle cleanup and least privilege. Run HC gates, lint,
typecheck, tests and packaging verification.

Do not expose Electron/Node primitives to the renderer, put business rules in IPC handlers, accept
arbitrary channels/URLs/paths, or infer packaged behaviour from the dev server.
