---
name: mobile-expo
description: Implement or review an HC React Native Expo feature through platform ports and secure client boundaries.
metadata:
  hc/applies-to: "mobile-expo"
  hc/load-when: "Expo mobile task"
  hc/context-budget: "small"
---

# Mobile Expo profile

Read the [architecture](../../../profiles/mobile-expo/architecture.md) and
[testing guide](../../../profiles/mobile-expo/testing.md). Keep Expo Router in `app/`, shared composition
in `src/core`, and each capability in `src/features/<feature>`. Domain/application stay portable;
presentation never imports infrastructure; native APIs implement explicit ports.

Use TanStack Query for remote state, Zustand for UI only, SecureStore for session material and
AsyncStorage only for allowlisted non-sensitive preferences. Model permission, offline, lifecycle,
cleanup and OS-specific failure explicitly. Test pure behaviour, UI states, adapter contracts and then
device flows; run HC gates, lint, strict typecheck, tests and platform build/config.

Do not make the client authority for sensitive rules, route directly to adapters, persist remote/session
state in UI stores, or infer native success from mocked SDK calls.
