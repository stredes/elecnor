---
name: backend-nest
description: Implement or review an HC NestJS backend feature with pure inner layers and PostgreSQL adapters.
metadata:
  hc/applies-to: "backend-nest"
  hc/load-when: "backend task"
  hc/context-budget: "small"
---

# Backend Nest profile

Read the [architecture](../../../profiles/backend-nest/architecture.md) and
[testing guide](../../../profiles/backend-nest/testing.md). Keep each capability in
domain/application/infrastructure. Define outbound ports in application and compose concrete adapters
through Nest providers; keep use cases independently constructible and controllers thin.

For HTTP work, create bounded validated input DTOs, explicit response DTOs and OpenAPI tags,
operations, success/error schemas. Reuse one app configuration function from main and e2e. For TypeORM,
ship and load migrations, force `synchronize: false`, and use real PostgreSQL evidence for schema,
constraints, races and transactions.

Declare areas/risks, run `hc verify`, and fix implementation rather than gates. Do not inject
repositories into domain, return ORM entities as contracts, put error/business branches in controllers,
or treat mocked/sequential persistence as concurrency proof.
