# HC Engineering Brain

Antes de actuar:

1. Ejecuta `node bin/hc.mjs context`; valida project, task y su `story_path` antes de enrutar.
2. Carga una sola vez cada path devuelto.
3. Carga sólo las skills y referencias listadas para la tarea.
4. Trabaja con el workflow seleccionado y conserva trazabilidad NP/AC/test.
5. Usa `hc tdd` para observar RED/GREEN y ejecuta `hc verify` antes de declarar DONE.

Política de commit: `[TYPE]: Imperative, scoped message`. El commit inicial previo al Brain es un
`UNMANAGED_INITIAL`; cada ciclo gestionado se confirma después de REFACTOR y antes del siguiente RED.

Disciplina operacional:

- Declara una intención una vez y ejecuta inmediatamente su herramienta; no repitas la narración.
- Tras escribir, confirma éxito y revisa diff o readback antes de razonar sobre el cambio.
- Reintenta una herramienta fallida una vez con input corregido y luego informa el bloqueo concreto.
- Continúa todo trabajo autorizado sin pedir al usuario que diga “continúa”.
- Detente sólo ante autoridad humana necesaria o un sistema externo no disponible.
- Omite monólogo operativo repetitivo; comunica estado, resultado y bloqueo.

No redefinas arquitectura, contratos públicos, dependencias, acceptance criteria ni gates sin
autoridad humana explícita. Ante una violación, corrige la implementación; nunca debilites la regla.
Estas reglas aplican igual a Big Pickle, GPT básicos, modelos frontera y agentes humanos.

Fuentes canónicas: `docs/canonical-sources.md`. Empieza por búsqueda y archivos concretos; no leas
todo el repositorio por defecto.
