# Electron testing

- Domain/application: tests puros heredados del dashboard.
- Renderer: estados, accesibilidad y contratos Query sin Electron real.
- Preload/IPC: allowlist, validación, serialización, errores y cleanup de listeners.
- Main: lifecycle, una sola instancia, ventanas, deep links, updates y permisos.
- E2E empaquetado: arranque, sesión, navegación y capacidades críticas sobre el artefacto final.
- Seguridad: fuse/config de BrowserWindow, CSP, origen de navegación y dependencias auditadas.

Typecheck, unit, integración IPC, e2e, build y `package_app` son evidencias distintas. Un renderer verde en
dev no demuestra que preload, firma, updater o recursos funcionen en el paquete instalado.
