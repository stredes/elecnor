# Desktop — Electron sobre la arquitectura dashboard

Desktop hereda `web-next`: domain y application son puros; infrastructure implementa adapters;
presentation sólo representa estado y eventos; core concentra entorno, HTTP, Query y estado UI. El
renderer conserva el flujo del dashboard y no duplica reglas de negocio del backend.

```text
src/
  main/                    # lifecycle, ventanas, menú, updates e IPC handlers
  preload/                 # único bridge tipado y allowlisted
  renderer/
    app/                   # routing/composición de pantalla
    domain/ application/ core/ infrastructure/ presentation/
```

El renderer es una web no confiable: nunca importa `electron`, Node, main ni preload. `BrowserWindow`
usa `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true` y no debilita web security.
Preload expone capacidades mínimas con `contextBridge`; jamás entrega `ipcRenderer`, filesystem,
shell o procesos completos. Channels e inputs se allowlistean y validan antes del use case.
Main valida también `event.sender`/origen; ninguna capability acepta canales dinámicos del renderer.

Main posee capacidades de sistema operativo y lifecycle. Los handlers adaptan IPC a application
ports; no contienen reglas de negocio. Navegación externa, archivos, updates y notificaciones pasan
por adapters con autorización y rutas/orígenes validados. Una ventana cerrada cancela listeners y
trabajo asociado.

Contenido remoto usa HTTPS, CSP restrictiva y permissions explícitos; navegación y nuevas ventanas se
deniegan por defecto. `shell.openExternal`, custom protocols y filesystem aceptan sólo destinos
allowlisted. Fuses, firma y updater se verifican sobre el artefacto empaquetado.

TanStack Query conserva server state; Zustand sólo UI local. Material de sesión permanece fuera del
renderer cuando sea posible y nunca se persiste en stores UI. Los contratos compartidos del bridge
son datos serializables y versionados, no objetos Electron.
