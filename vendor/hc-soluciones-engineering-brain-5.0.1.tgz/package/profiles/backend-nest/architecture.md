# Backend — NestJS + PostgreSQL

La unidad de cambio es una capacidad de negocio, como en `hc-backend`:

```text
src/<capability>/
  domain/                         # modelo, invariantes, eventos y errores puros
  application/{use-cases,ports}/  # orquestación y contratos hacia afuera
  infrastructure/
    http/{controllers,dto,mappers,docs}/
    persistence/typeorm/
src/common/{config,database,http,swagger}/
```

Se crean sólo carpetas con responsabilidad actual. Domain no importa application, Nest, TypeORM ni
SDKs. Application importa domain y define ports con tipos internos; no conoce HTTP, ORM ni adapters.
Infrastructure traduce contratos y el composition root conecta tokens, factories y adapters. Un
controller valida y mapea una operación; no consulta repositories, ramifica reglas ni devuelve ORM
entities. Los casos de uso siguen siendo construibles sin el contenedor Nest.

## Contrato HTTP y bootstrap

Todo endpoint público tiene DTO de entrada con validación acotada, DTO de respuesta propio y metadata
OpenAPI: tag, operación, éxito tipado y errores relevantes. `setupSwagger(app)` genera el documento
desde el runtime. `applyAppConfig(app)` centraliza prefix, `ValidationPipe`, filters, CORS y seguridad;
main y e2e llaman la misma función. Main valida env antes de escuchar, habilita shutdown hooks y no
contiene configuración divergente.

## Persistencia y operación

Migrations versionadas son la única autoridad del esquema; TypeORM carga migrations explícitamente y
`synchronize` resuelve siempre a `false`, incluso en desarrollo y tests. Constraints/transactions
protegen invariantes concurrentes; el adapter traduce errores tecnológicos. Configuración tipada y
validada separa secretos, URLs, CORS y defaults seguros. Health, logging con correlation id y cierre
ordenado pertenecen a common/infrastructure, nunca al dominio.

Riesgos persistence/concurrency/transaction/migration exigen integración PostgreSQL real. Riesgos
public-api/external-input y todo AC HTTP exigen e2e con el bootstrap productivo compartido.
