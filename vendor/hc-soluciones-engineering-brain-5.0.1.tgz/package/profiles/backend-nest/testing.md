# Backend testing

- Domain: reglas, values, estados y bordes mediante tests puros.
- Application: use cases con fakes de ports; outcomes, autorización e interacciones relevantes.
- HTTP: DTO validation, OpenAPI generado, status/error mapping, auth y respuesta pública.
- Persistence: PostgreSQL real para migrations, constraints, transacciones, locking y rollback.
- E2E: app creada con `applyAppConfig`, journeys críticos y compatibilidad del contrato público.

No mockees el objeto bajo prueba ni el ORM para afirmar comportamiento real de DB. La carpeta
`integration/` no basta: se requiere un adapter productivo real y, para concurrencia, operaciones
solapadas contra el constraint. Una migration se prueba desde esquema vacío y desde la versión anterior
que declara soportar; `synchronize` no prepara el harness.

Los checks mínimos son lint sin warnings, format check no mutante, strict typecheck de source/tests,
unit, dependency audit y build. Se agregan integration por riesgo de datos y e2e por boundary HTTP.
El documento OpenAPI se genera en test para detectar DTOs o endpoints sin contrato.
