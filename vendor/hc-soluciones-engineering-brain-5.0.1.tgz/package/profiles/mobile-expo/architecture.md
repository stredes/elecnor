# Mobile — React Native + Expo

La forma canónica de `hc-app` usa Expo Router sólo como adapter y vertical slices por capacidad:

```text
app/                                      # rutas, layouts y composición de pantalla
src/core/{composition,config,http,query,store,theme}/
src/features/<feature>/
  domain/ application/ infrastructure/ presentation/
src/shared/                               # UI/utilidades realmente transversales
```

Domain y application no importan React, React Native, Expo, Query, Zustand ni SDKs. Application define
ports para HTTP, clock, conectividad, storage, notifications, camera, GPS, biometrics y filesystem.
Infrastructure adapta esas capacidades y normaliza permisos, ausencia, cancelación, timeout y errores.
Presentation traduce interacción/estado y consume casos de uso o hooks compuestos; no importa adapters.
`app/` enlaza rutas con presentation y no salta a infrastructure.

## Datos, sesión y lifecycle

TanStack Query posee estado remoto, caché/retry y revalidación al recuperar conexión o foreground.
Zustand contiene sólo UI local; una persistencia allowlisted puede usar AsyncStorage para preferencias
no sensibles. Tokens, refresh material y credenciales usan SecureStore y nunca pasan a stores UI.
El backend conserva autoridad sobre identidad, autorización, precios y resultados sensibles.

APIs nativas se modelan como capacidades falibles. Adapters observan AppState, permisos y diferencias
iOS/Android; liberan subscriptions y recursos. Deep links y notifications se validan antes de navegar.
Configuración Expo y env se validan sin secretos embebidos. Offline, retries e idempotencia son decisiones
explícitas del caso de uso, no efectos accidentales del componente.
