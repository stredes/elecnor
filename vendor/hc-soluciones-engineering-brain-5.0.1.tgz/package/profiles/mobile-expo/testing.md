# Expo testing

- Domain/application: tests puros con ports falsos para clock, network y device capabilities.
- Presentation: interacción, accesibilidad y estados loading/offline/error/permission denied.
- Adapters: serialización, SecureStore/AsyncStorage, permisos, cleanup y API con integración apropiada.
- Routing: parámetros/deep links válidos y rutas protegidas sin importar infrastructure.
- Device: cámara, biometría, notifications, deep links, background/foreground y builds por OS.

Lint, strict typecheck, unit, dependency audit y build/config son mínimos; boundaries visibles o públicos
añaden e2e. Tests arquitectónicos bloquean SDKs en capas internas, presentation→infrastructure,
credenciales en AsyncStorage y server state persistido en Zustand. No conviertas mocks del SDK en
evidencia nativa: registra dispositivo, OS/build y resultado para journeys sensibles.
