# Brain tooling profile

El Brain usa módulos pequeños y scripts deterministas; no fuerza Hexagonal porque no modela un producto
con adapters reemplazables. Separar parsing, validación, routing y gates por responsabilidad sí aplica.
No se agregan dependencias mientras Node estándar cubra el caso con claridad.
