# Unity / VR testing

Las señales son separadas y ninguna sustituye a otra:

- Compile/build: assemblies, platform defines, stripping, scenes y artefacto objetivo.
- EditMode: domain/application puros; scoring, orden, acciones inválidas, progreso y safety.
- PlayMode: composition, lifecycle, scene transitions, adapters, physics y XR interaction simulable.
- Device: tracking/controllers, permissions, pause/resume, haptics, audio y artefacto instalado.
- Performance: frame timing CPU/GPU, dropped frames, memory/GC, thermal y carga representativa.
- Humana: ergonomía, confort, legibilidad, alcance, inmersión y percepción en Quest.

Presentation requiere build, EditMode, PlayMode, device y performance declarados. Registra dispositivo,
OS/runtime, commit/build, escenario, duración, presupuesto y p95/peor tramo; una captura del Editor o un
promedio sin condiciones no cierra el gate. Usa OVR Metrics Tool o Performance Analyzer en dispositivo:
[Meta metrics](https://developers.meta.com/horizon/documentation/unity/ts-ovrmetricstool/) y
[Meta Performance Analyzer](https://developers.meta.com/horizon/documentation/unity/ts-mqdh-logs-metrics/).

Una checklist humana no reemplaza tests de negocio; automatización no certifica confort sensorial.
