# VR — Unity 6 + OpenXR

Arquitectura profesional hexagonal por capacidad, sin depender de una referencia HC previa:

```text
Assets/HC/Core/                         # primitives/ports compartidos realmente puros
Assets/HC/Training/<Scenario>/
  Domain/                              # state, reglas, scoring, progreso y eventos
  Application/                         # comandos/use cases y ports de plataforma
  Infrastructure/                      # Unity/OpenXR/XRIT, persistence y telemetry adapters
  Presentation/                        # MonoBehaviours, presenters, views y bindings de scene
Assets/HC/Bootstrap/                    # composition roots por scene
Assets/HC/Tests/{EditMode,PlayMode}/
```

Domain usa valores propios, no `Vector3`, GameObject ni XR types. Application orquesta domain y ports
para clock, input/pose, scene loading, haptics, audio, persistence, network y telemetry. Infrastructure
traduce Unity/OpenXR/XR Interaction Toolkit/Quest a esos contratos. Presentation representa feedback
y eventos; no accede a filesystem, HTTP o PlayerPrefs. MonoBehaviour y ScriptableObject son adapters o
configuración, nunca dueños de reglas.

## Assemblies y composición

Cada capa/capacidad tiene `.asmdef`. Domain y Application activan `noEngineReferences: true`; Domain
referencia como máximo Core puro y Application sólo Core/Domain. Infrastructure/Presentation apuntan
hacia dentro, nunca entre escenarios mediante internals. Bootstrap es el único lugar que conecta scene
objects, lifecycle y adapters. Ningún tipo de engine cruza un port interno.

## Runtime, seguridad y rendimiento

Update/FixedUpdate capturan señales y delegan; no calculan scoring ni transiciones. Clock, aleatoriedad,
input, scene changes y App pause/resume pasan por ports deterministas. Subscriptions, coroutines y async
work se cancelan al deshabilitar/cambiar scene. El backend conserva autoridad sobre identidad,
autorización y resultados sensibles.

Cada dispositivo objetivo declara presupuesto de frame, CPU/GPU, memoria y draw calls. Quest se perfila
en hardware y bajo carga representativa; una media del Editor no es evidencia. La referencia mínima de
apps interactivas Quest es 72 FPS, pero el proyecto puede exigir más. Rendering, physics y allocations
se optimizan a partir de métricas, no de supuestos.

Base técnica: [Unity asmdefs](https://docs.unity.cn/Manual/ScriptCompilationAssemblyDefinitionFiles.html),
[Unity Test Framework](https://docs.unity.cn/Packages/com.unity.test-framework%402.0/manual/edit-mode-vs-play-mode-tests.html),
[XR Interaction Toolkit](https://docs.unity3d.com/ja/6000.0/Manual/com.unity.xr.interaction.toolkit.html) y
[Meta Quest performance](https://developers.meta.com/horizon/documentation/unity/unity-perf/).
