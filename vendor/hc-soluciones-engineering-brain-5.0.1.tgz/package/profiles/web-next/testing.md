# Next testing

- Domain/application: unitarios puros, sin render ni runtime Next.
- Presentation: comportamiento, accesibilidad, loading/empty/error y mutations; evita snapshots masivos.
- Server adapters: sesión, serialización, error mapping, cache keys e invalidación.
- BFF route handlers: input, auth/authorization, cookie segura y contrato backend.
- E2E: journeys, navegación y aislamiento server/client críticos sobre production build.

Lint, strict typecheck, unit, dependency audit y build son mínimos; presentation/public boundaries
añaden e2e. El build detecta imports server/client, variables privadas y serialización que unit puede
omitir. Tests de arquitectura bloquean imports presentation→infrastructure, APIs server-only en client,
sesión en estado persistido y route handlers sin boundary de sesión.
