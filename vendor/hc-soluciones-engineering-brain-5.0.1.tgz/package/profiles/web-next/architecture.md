# Dashboard — Next.js App Router

La forma canónica de `hc_dashboard` separa capas y agrupa capacidades dentro de ellas:

```text
src/app/             # routing, layouts, Server Components y BFF route handlers
src/domain/          # reglas, values y contratos puros por capacidad
src/application/     # use cases y ports
src/infrastructure/  # adapters backend/session y mappers
src/presentation/    # views, components, hooks y queries
src/core/            # composición transversal: env, HTTP, Query, store y logging
```

Las dependencias van presentation/infrastructure → application → domain. `app` y `core` componen; no
alojan reglas de negocio. Presentation consume application o contratos inyectados, no adapters. Domain
y application no importan React, Next, Query, Zustand ni fuentes no deterministas sin port.

## Server, client y BFF

Server Components son default. `use client` marca el boundary interactivo mínimo y jamás importa
`next/headers`, secretos, Node, adapters backend o material de sesión. Sólo datos serializables y
filtrados cruzan al renderer. Route handlers, actions y Server Functions son entradas no confiables:
validan input, sesión y autorización antes de delegar.

El BFF `app/api/dashboard` es el único proxy browser→backend para operaciones autenticadas. La sesión
vive en cookie `httpOnly`, `secure` y `sameSite` gestionada en servidor; tokens no entran a props,
localStorage ni Zustand. Un wrapper común agrega sesión, correlation y traducción segura de errores.

## Estado y configuración

TanStack Query posee server state, caché y reintentos; mutations invalidan keys centralizadas sólo tras
éxito. Zustand conserva estado UI local y su persistencia usa allowlist sin sesión ni entidades remotas.
Env se valida con schema y separa variables públicas/privadas. HTTP, query keys, invalidación y logging
se centralizan; componentes no construyen URLs ni políticas de caché.
