# Commits y PR

Formato compatible conservado:

```text
[TYPE]: Imperative, scoped message
```

Tipos: `[FEATURE]`, `[FIX]`, `[REFACTOR]`, `[TEST]`, `[DOCS]`, `[CONFIG]`, `[CI/CD]`, `[CHORE]`.
Un commit es una unidad lógica verificable, no un checkbox. Se prefieren mensajes en inglés; `AC-XX`
se añade cuando mejora trazabilidad: `[TEST]: Cover booking overlap AC-01`.

Evita `update`, `changes`, `stuff`, WIP final y commits que mezclen refactor, feature y configuración
sin una razón atómica. El PR hacia `Development` usa `NP-XXXX - título` y el template oficial.
Squash sólo limpia historial experimental; nunca oculta decisiones o evidencia necesaria.
