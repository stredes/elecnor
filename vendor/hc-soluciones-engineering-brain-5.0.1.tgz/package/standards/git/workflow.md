# HC Git Workflow v2.0

`main` es estable/producción; `Development` integra. Una HU nace de `Development` en `NP-XXXX`, mismo
ID en todos los repos, y abre PR a `Development`. No se desarrolla directo en ramas principales.
Los gates comprueban rama, existencia/ascendencia de la base y formato de los commits ya creados.

`Development → main` ocurre por Release PR con versión SemVer cuando el producto se versiona, changelog,
migraciones, compatibilidad, riesgo y rollback. Feature incompatible incrementa major; capacidad
compatible minor; corrección compatible patch.

Hotfix: `main → HOTFIX-NP-XXXX → RED regression → fix → GREEN → gates → PR main → patch release`.
Inmediatamente después, merge/cherry-pick coordinado hacia `Development` y resolución explícita de
divergencias. No se crea una familia extra de ramas permanentes.

PR multi-repo conserva NP y ordena despliegue por compatibilidad contractual: primero cambios aditivos,
luego consumidores, finalmente retiro de contratos antiguos.
