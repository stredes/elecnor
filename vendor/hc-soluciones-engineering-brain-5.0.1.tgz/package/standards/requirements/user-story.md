# HC User Story Specification

El contrato oficial es `.hc/schemas/user-story.schema.json` y el ejemplo canónico está en
`templates/user-story/NP-0000.json`.

Una HU declara ID, título, actor, necesidad, valor, contexto, precondiciones, AC identificados,
business rules, edge cases, out of scope, dependencias, NFR, DoR y DoD. `AC-XX` usa Given/When/Then
cuando expresa un escenario; cada AC lista uno o más `TEST-XX` antes de DONE.

DoR exige claridad suficiente para escribir tests significativos: comportamiento, beneficiario,
valor, AC, exclusiones, dependencias y forma de verificación. No exige diseño perfecto.

Cambiar un AC durante implementación requiere decisión de Product/autoridad humana y registro en HU;
un agente implementador no lo adapta a su código.
