# Trazabilidad ligera

Cadena objetivo:

```text
NP-0142 → AC-01 → TEST-01 → implementation → commit → PR → release
```

- HU mantiene AC y `test_ids`.
- Nombre o metadata del test incluye `NP-XXXX/AC-XX/TEST-XX`; varios AC se ordenan separados por coma.
- `.hc/evidence/NP-XXXX.json` conserva timestamp, metadata Git y digests de RED/GREEN/REFACTOR,
  nunca logs sensibles.
- Cada AC que promete status o body HTTP incluye al menos un TEST etiquetado en una ruta e2e.
- Commits nombran NP por contexto de rama/PR y mencionan AC cuando implementan uno específico.
- PR lista AC→tests y evidencias; no enumera cada fichero sin valor.
- Release PR lista NP incluidas y compatibilidad/migraciones.

`hc verify` cruza story, task, tags y evidencia. No se decora producción; PR e historial conectan la
implementación y la release conecta PR con versión.
