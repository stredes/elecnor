# Security standard v1

- Nunca versionar secrets ni fallbacks conocidos; configuración sensible ausente impide arrancar.
- Autentica identidad y autoriza cada acción/objeto en el boundary confiable.
- Trata input, archivos y eventos externos como no confiables; valida forma, rango y tamaño.
- DTOs externos fijan límites máximos para strings sensibles; una URL con usuario/password embebidos
  es un secreto aunque apunte a localhost.
- Usa consultas parametrizadas, encoding contextual y allowlists contra injection.
- No registres tokens, passwords, PII innecesaria ni payloads sensibles; conserva correlación segura.
- Usa TLS, least privilege, separación de ambientes y dependencias fijadas/auditadas.
- En móvil, secretos de sesión van a almacenamiento seguro; AsyncStorage no guarda credenciales.
- Web client, app móvil y Quest son clientes no confiables; no contienen secretos de servidor ni son
  autoridad sobre pagos, permisos, progreso o scoring oficial.
- Maneja errores sin filtrar internals. Rate limits, idempotencia y auditoría se aplican según riesgo.

Toda tarea declara `risk_tags`; cada riesgo se conecta a NFR con test o review. Identidad, autorización,
credenciales, datos personales, concurrencia y release requieren review `accepted`. La aceptación se ata al email,
fingerprint y task mediante un commit firmado y alcanzable desde HEAD; escribir un nombre no prueba
intervención humana. Hallazgos críticos y señales sin resolver bloquean `hc verify`.
