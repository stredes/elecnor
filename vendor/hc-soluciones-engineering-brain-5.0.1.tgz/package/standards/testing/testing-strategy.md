# Estrategia de testing y TDD

El flujo completo parte del comportamiento: necesidad → HU → DoR → AC/ejemplos → diseño de test →
RED → mínimo GREEN → REFACTOR → regresión → gates → review.

En RED confirma que el test falla por la razón esperada. Si nace verde, investiga implementación
previa, assertion, mock o falso positivo. En GREEN implementa sólo el comportamiento actual. En
REFACTOR revisa SRP, nombres, duplicación, dependencias, smells y complejidad, y vuelve a ejecutar.

Cada comportamiento cierra RED → GREEN → REFACTOR antes del siguiente RED. Producción no cambia entre
ese REFACTOR y el RED siguiente. La evidencia final fija digest de fuente y suite; cualquier cambio
posterior exige volver a ejecutar el último REFACTOR. Además, el digest actual de cada TEST debe
coincidir con su propio REFACTOR: un snapshot global no blanquea una assertion modificada.
Screenshots aislados no prueban continuidad.

Un bug reproducible recibe primero regression test cuando es razonable. Un refactor empieza verde y,
si falta protección, añade characterization tests. Nunca borres, skips o debilites un test válido.

Behaviour coverage precede line coverage. Domain, dinero, permisos, seguridad y transiciones críticas
requieren cobertura especialmente alta. Adapters se cubren por riesgo; UI prueba comportamiento, no
detalles internos. VR sensorial requiere validación humana además de EditMode/PlayMode cuando aplican.
