# Métricas y señales

| Señal | Valor inicial | Clase |
| --- | --- | --- |
| Fichero authored | ≤ 99 líneas físicas | HARD GATE |
| Dependencia arquitectónica prohibida | 0 | HARD GATE |
| Test/lint/typecheck/build requerido fallando | 0 | HARD GATE |
| Ciclo entre módulos | 0 | HARD GATE |
| Complejidad ciclomática por función | > 10 | QUALITY WARNING |
| Nesting | > 3 niveles | QUALITY WARNING |
| Parámetros | > 4 | QUALITY WARNING |
| Función | > 20 líneas | QUALITY WARNING |
| Dependencias directas de unidad | > 7 | HUMAN REVIEW SIGNAL |
| Duplicación | > 3% o bloque repetido relevante | HUMAN REVIEW SIGNAL |

Warnings exigen inspección, no extracción mecánica. Excepciones de lenguaje o algoritmo se justifican
en review; no apagan hard gates. El límite cuenta código authored y excluye sólo generated/vendor,
lockfiles, snapshots, assets, metadata externa, migrations generadas y datasets declarados.

Dividir es válido cuando cada unidad obtiene nombre y responsabilidad propios. Archivos `part-1` o
wrappers vacíos creados sólo para pasar son violación.
