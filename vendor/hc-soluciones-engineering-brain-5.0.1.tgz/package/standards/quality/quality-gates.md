# Quality Gates

## Core gates

`hc gates` valida schemas, manifests, integridad, scope/authority del diff, workflow Git, ≤99 líneas,
imports/ciclos, TypeScript source+tests, convenciones de profile y secrets. Produce hard failures y
review signals; nunca declara DONE. `hc verify` añade pin+lock, AC→TEST, RED/GREEN/REFACTOR continuo,
digest actual por TEST, snapshot final, niveles de riesgo, attestation de reviews y comandos declarados.

## Profile gates

- Nest: strict TS, DTO/ValidationPipe, OpenAPI tipado, migrations/synchronize false, bootstrap compartido,
  crypto asíncrono, integración sustantiva por riesgo y e2e por AC HTTP.
- Next: capas dashboard, server/client/BFF/session boundaries, estado Query/UI y production build.
- Expo: feature boundaries, storage seguro, platform adapters, config/build y QA de dispositivo por riesgo.
- Electron: herencia Next, aislamiento main/preload/renderer, IPC allowlisted y artefacto empaquetado.
- Unity: asmdef/No Engine References, build, EditMode, PlayMode, Quest performance y validación humana.

Los otros profiles conservan una base portable que no suplanta tooling nativo. Métricas AST
como complejidad, nesting, parámetros, dead code y duplicación son warnings/review signals configurados
en el linter/analyzer del proyecto. Una herramienta no convierte señales heurísticas en verdad.

`generated_roots` nombra sólo directorios explícitos `generated`/`migrations` revisados y nunca un root
completo de source. No existen waivers authored para 99 líneas. Cambiar manifest, config o CI
para ocultar una infracción es gate weakening y requiere rechazo del PR.
