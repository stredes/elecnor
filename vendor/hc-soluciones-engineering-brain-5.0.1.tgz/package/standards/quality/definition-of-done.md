# Definition of Done

Una tarea está DONE cuando, según riesgo y scope:

- todos los AC aplicables están mapeados a tags `NP/AC/TEST` únicos y satisfechos;
- `hc tdd` observó RED, GREEN y REFACTOR; cada TEST conserva el digest de su REFACTOR;
- arquitectura, SOLID/SRP y smells críticos fueron revisados;
- ningún código authored supera 99 líneas ni se fragmentó artificialmente;
- `hc verify` pasa lint, format-check, typecheck de source+tests, tests, build y gates;
- integration/e2e por AC, seguridad, migraciones y rollback se verificaron cuando aplican;
- toda review accepted tiene attestation verificable, no sólo una identidad escrita;
- contratos, ADR y documentación canónica se actualizaron cuando cambiaron;
- no se añadieron TODO injustificados, dead code ni exclusiones de calidad;
- el PR declara riesgos y evidencia; no contiene scope ajeno.

`hc gates` o compilar son evidencia parcial, nunca DONE.
