# Rule, Skill y Gate

- **Rule** define permitido, prohibido o requerido. Vive en Constitution, standard o profile.
- **Skill** guía el razonamiento y la ejecución de un agente. No redefine la rule.
- **Gate** produce evidencia automática y falla cuando puede verificar una rule.

Ejemplo: Rule `domain` no depende de infrastructure; skill `hexagonal-design` explica dónde crear el
port; gate de arquitectura inspecciona imports. Lo no automatizable se registra como review signal,
no como falsa garantía.

Catálogo trazable: `rules/catalog.json`. Un cambio a un hard gate requiere decisión humana explícita,
ADR cuando afecta arquitectura y actualización coordinada de rule, skill y gate.
