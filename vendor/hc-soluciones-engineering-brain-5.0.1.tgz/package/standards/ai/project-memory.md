# Project memory

`.hc/project-memory.md` conserva únicamente arquitectura/stack, decisiones vigentes, estado actual,
restricciones, milestones, riesgos y ADR relevantes. Cada punto debe cambiar decisiones futuras.

No es diario, chat transcript, backlog, changelog ni duplicado de README. Al actualizar, elimina hechos
caducos y enlaza la fuente canónica. Mantén una página breve; si una decisión necesita rationale y
consecuencias, crea ADR y deja sólo el enlace.
