# Roles y autoridad

Roles son capacidades, no modelos: Architect decide diseño/ADR/contracts; Implementer entrega scope
aprobado; Tester diseña AC/RED/regresión; Reviewer evalúa arquitectura/calidad/seguridad; Refactorer
mejora diseño sin comportamiento; Documenter actualiza fuentes canónicas.

Implementer puede añadir tests, implementar scope, refactorizar localmente, crear abstracciones
privadas justificadas, mejorar nombres y quitar duplicación local.

Requiere autoridad humana/Architect para cambiar arquitectura, DB, dependencia, API pública, CI/gates,
AC, test válido o scope sustancial. Puede proponerlo con trade-offs y ADR draft, nunca hacerlo en
silencio.

El manifest de task limita paths y autoridad de forma ejecutable. Dependencias, persistencia estructural,
gates y CI requieren tanto scope como autoridad/risk tag adecuados; una instrucción narrativa no los
autoriza implícitamente.

Tiers orientativos: high-reasoning puede comparar trade-offs; implementation recibe HU y boundaries;
mechanical recibe un comportamiento, archivos permitidos y comando de verificación. Cuanto menor la
capacidad, menor el task slice y las decisiones abiertas.

El tier no altera Constitución, arquitectura, TDD, seguridad ni gates. Todos los modelos cumplen el
mismo estándar; un modelo económico escala la decisión que excede su slice en vez de improvisarla.
