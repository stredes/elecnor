# Context y Brain Router

Minimum Sufficient Context significa el mínimo contexto suficiente para decidir correctamente, no el
mínimo absoluto.

Orden: Constitution → project manifest → task → standard arquitectónico/profile → skills/workflow
relevantes → archivos objetivo y dependencias directas. Inspecciona tree, busca símbolos, lee módulos
concretos y sólo después expande. No cargues stacks ajenos ni repitas fuentes canónicas.

`node bin/hc.mjs context` implementa el router declarativo de `router/context-map.json`. La salida es
una lista, no un permiso: si aparece una decisión arquitectónica, consulta ADR relevantes. Resúmenes
de sesión se promueven a memoria sólo si siguen siendo verdad y afectan decisiones futuras.
