# Ports y adapters

Un port existe cuando el caso de uso cruza un límite reemplazable o no determinista: persistencia,
clock, hashing, pagos, notificaciones, telemetría o plataforma. Los outbound ports viven en
`application/ports`; un inbound port sólo se nombra cuando ofrece un contrato real a varios adapters.

No crear una interface por clase ni por posibilidad hipotética. Una implementación privada y estable
puede seguir concreta. Crear el port cuando aísla tecnología, permite test determinista o expresa una
capacidad externa.

Adapters implementan ports y traducen errores/DTO. Nest modules, Next route/actions, Expo APIs y
MonoBehaviours son composition o adapters. Domain no conoce ORM entities, request objects, React,
`UnityEngine` ni SDK externos.
