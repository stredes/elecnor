# Arquitectura HC

## Regla

Todo producto usa Hexagonal Architecture + vertical slicing por dominio/feature. Dependencias:

```text
infrastructure / presentation → application → domain
```

`domain` contiene comportamiento de negocio puro. `application` orquesta casos de uso y define ports.
`infrastructure` adapta HTTP, DB, filesystem, mensajería, dispositivos y frameworks. La composición
concreta vive fuera de las capas internas.

Dentro de `modules/<feature>/` crea sólo carpetas que tengan responsabilidades actuales. Una feature
sin entidad no necesita `entities/`; una operación pura no necesita service, factory ni interface.

## Límites

- Domain no importa application, UI, frameworks ni infraestructura.
- Application no importa adapters ni tipos tecnológicos.
- Adapters traducen contratos; no deciden reglas de negocio.
- Cruces entre features usan contratos explícitos, no internals ajenos.
- Cambiar este grafo requiere ADR y autoridad de Architect.

Hexagonal es obligatoria; la complejidad accidental está prohibida.
