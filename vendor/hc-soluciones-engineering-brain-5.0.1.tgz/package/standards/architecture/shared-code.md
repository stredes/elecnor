# Shared / common

`shared` sólo admite abstracciones transversales con semántica estable y ownership claro. Reusar dos
veces no basta.

Antes de mover código, pregunta:

- ¿representa el mismo concepto en todos los consumidores?
- ¿su cambio transversal es coherente y no fuerza acoplamiento?
- ¿tiene nombre de dominio/plataforma preciso y tests propios?

Se prohíben cajones `utils.ts`, `helpers.ts`, `functions.ts` y `misc.ts`. Mantén comportamiento local
hasta demostrar una abstracción. Código contractual compartido debe publicarse por una API explícita;
los features no importan internals entre sí.
