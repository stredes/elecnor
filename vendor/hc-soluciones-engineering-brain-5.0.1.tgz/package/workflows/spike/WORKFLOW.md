# Spike

1. State question, timebox, decision owner and evidence sought.
2. Isolate experiment from production paths and data.
3. Relax architecture/testing only as explicitly declared.
4. Record result, limitations, security concerns and recommendation.
5. Discard prototype or create a production task.

Spike code does not automatically become production code. Promotion requires normal HU, TDD,
architecture, security and gates; copying the prototype is not proof of readiness.
