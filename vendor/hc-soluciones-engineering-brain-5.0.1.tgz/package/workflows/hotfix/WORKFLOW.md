# Hotfix

1. Branch `HOTFIX-NP-XXXX` from `main` with incident authority.
2. Reproduce and create RED regression test.
3. Apply minimum fix; confirm GREEN and relevant regression.
4. Run all release-critical profile gates.
5. PR to `main` with impact, rollback and verification.
6. Release compatible patch and verify production.
7. Synchronize immediately to `Development`; resolve divergence explicitly.
