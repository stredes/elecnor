# Bugfix TDD

1. Reproduce and describe observed vs expected behaviour.
2. Link existing AC or obtain authority to clarify the requirement.
3. Add the smallest meaningful regression test; confirm RED for the defect.
4. Implement the minimum fix and confirm GREEN.
5. Run neighbouring and full relevant regression suites.
6. Refactor only while tests remain green; run quality gates.
7. Record root cause, risk and regression test in PR.

If automation is technically unreasonable, document reproducible evidence and compensating validation.
