# Feature TDD

1. BUSINESS NEED / HU: validate story and NP.
2. READY: confirm scope, dependencies and verifiable AC.
3. TEST DESIGN: map one behaviour to `NP-XXXX/AC-XX/TEST-XX`.
4. RED: execute `hc tdd red` and confirm the expected failure.
5. GREEN: implement only that behaviour.
6. REFACTOR: inspect SOLID, smells, architecture and naming while green.
7. REGRESSION: run relevant suite and `hc tdd refactor` when applicable.
8. REVIEW / DONE: bind accepted reviews to signed commits and run `hc verify`.

Repeat steps 3–7 per coherent behaviour, not per implementation checkbox.
