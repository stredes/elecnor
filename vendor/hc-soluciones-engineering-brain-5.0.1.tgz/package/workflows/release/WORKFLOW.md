# Release

1. Freeze the candidate set of completed NP on `Development`.
2. Select SemVer impact and prepare release notes.
3. Verify cross-repo contract order, migrations, compatibility and rollback.
4. Run complete release gates in a production-like environment.
5. Open Release PR `Development → main`; no unrelated implementation.
6. Merge, tag, deploy and execute smoke/health verification.
7. Record outcome and follow rollback procedure on defined trigger.
