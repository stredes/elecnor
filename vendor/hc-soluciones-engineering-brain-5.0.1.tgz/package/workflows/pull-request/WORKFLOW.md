# Pull request

1. Verify branch target and NP identity.
2. Remove unrelated changes and explain logical commits.
3. Complete AC→test mapping, RED/GREEN evidence and quality commands.
4. Declare contracts, migrations, ADR, security, risk and rollback.
5. Reviewer checks behaviour first, then security, architecture, tests and maintainability.
6. Resolve findings in code; never mute the detecting gate.
7. Merge only with required review and green CI.
