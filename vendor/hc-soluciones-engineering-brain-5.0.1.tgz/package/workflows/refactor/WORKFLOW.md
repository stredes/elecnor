# Refactor

1. Confirm current observable behaviour and tests are GREEN.
2. Add characterization tests when protection is insufficient.
3. Define the design smell and bounded target; do not add feature scope.
4. Refactor in reversible increments.
5. Keep tests GREEN and verify no public contract changed.
6. Run architecture, source-size and profile gates.
7. PR explains design improvement and unchanged behaviour evidence.
